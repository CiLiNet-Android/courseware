package com.cdc.android.app.news;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.R;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class WenActivity extends NewsPaperBaseActivity {

	public class GridItemClick implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> adapter, View view, int index,
				long position) {
			// Toast.makeText(view.getContext(), ""+chList.get((int)position),
			// Toast.LENGTH_LONG).show();
			Intent intent = new Intent();
			intent.setClass(view.getContext(), OtherActivity.class);
			intent.putExtra("channelId", chList.get((int) position));
			intent.putExtra("ss", 1);
			intent.putExtra("imageNext", imagesNext[(int)position]);
			startActivity(intent);
		}
	}

	// 32 ,制度发文
	public class MenuClick implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.newsBtn:
				finish();
				break;
			case R.id.wenBtn:
				break;
			case R.id.infoBtn:
				finish();
				Intent infoIntent = new Intent(v.getContext(),
						InfoActivity.class);
				startActivity(infoIntent);
				break;
			case R.id.cdcBtn:
				NewsPaperBaseActivity.isExist =true;
				finish();
				break;
			case R.id.moreBtn:
				finish();
				Intent moreIntent = new Intent(v.getContext(),
						SetActivity.class);
				startActivity(moreIntent);
				break;
			default:
				break;
			}
		}

	}

	GridView gridView;
	Button newsBtn, wenBtn, infoBtn, cdcBtn, moreBtn;
	ArrayList<Integer> chList = null;
	int[] images = { R.drawable.wen1, R.drawable.wen2, R.drawable.wen3,
			R.drawable.wen4, R.drawable.wen5, R.drawable.wen6, R.drawable.wen7,
			R.drawable.wen8 };
	int[] fonts = { R.drawable.wen1a, R.drawable.wen2a, R.drawable.wen3a,
			R.drawable.wen4a, R.drawable.wen5a, R.drawable.wen6a,
			R.drawable.wen7a, R.drawable.wen8a };
	
	String[] text = {"综合管理","人力资源","财务管理","工程管理","营销管理","设计管理","通知","党工团"};
	
	int[] imagesNext = { R.drawable.wen1b, R.drawable.wen2b, R.drawable.wen3b,
			R.drawable.wen4b, R.drawable.wen5b, R.drawable.wen6b, R.drawable.wen7b,
			R.drawable.wen8b };

//	测试环境栏目id：
//    动态新闻<35>
//
//    制度发文<32> 
//(综合管理<33>，人力资源<34>，财务管理<37>，工程管理<38>，营销管理<39>，设计管理<40>，通知<41>，党工会<42>)
//    服务资讯<43> 
//(酒店合同<44>，优惠商家<45>，公司礼品<46>)

	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wen);
		gridView = (GridView) findViewById(R.id.gridView);
		GridAdapter adapter = new GridAdapter(this);
		chList = new ArrayList<Integer>();
		chList.add(33);// ,32,33,14,22
		chList.add(34);
		chList.add(37);
		chList.add(38);
		chList.add(39);
		chList.add(40);
		chList.add(41);
		chList.add(42);
		adapter.setList(chList);
		gridView.setAdapter(adapter);

		newsBtn = (Button) findViewById(R.id.newsBtn);
		wenBtn = (Button) findViewById(R.id.wenBtn);
		infoBtn = (Button) findViewById(R.id.infoBtn);
		cdcBtn = (Button) findViewById(R.id.cdcBtn);
		moreBtn = (Button) findViewById(R.id.moreBtn);
		MenuClick menuClick = new MenuClick();
		newsBtn.setOnClickListener(menuClick);
		wenBtn.setOnClickListener(menuClick);
		infoBtn.setOnClickListener(menuClick);
		cdcBtn.setOnClickListener(menuClick);
		moreBtn.setOnClickListener(menuClick);
		wenBtn.setBackgroundResource(R.drawable.menu02_click);
		Button back = (Button) findViewById(R.id.back);
		back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		gridView.setOnItemClickListener(new GridItemClick());
	}

	class GridAdapter extends BaseAdapter {

		private Context context;

		private List<Integer> list;
		private LayoutInflater mInflater;

		public GridAdapter(Context c) {
			super();
			this.context = c;
		}

		public void setList(List<Integer> list) {
			this.list = list;
			mInflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		}

		public int getCount() {
			return list == null ? 0 : list.size();
		}

		@Override
		public Object getItem(int index) {
			return list.get(index);
		}

		@Override
		public long getItemId(int index) {
			return index;
		}

		@Override
		public View getView(int index, View convertView, ViewGroup parent) {
			convertView = mInflater.inflate(R.layout.gridview_layout, null);
			ImageView item1 = (ImageView) convertView
					.findViewById(R.id.itemImage);
			TextView item2 = (TextView) convertView
					.findViewById(R.id.itemText);
			item1.setImageResource(images[index]);
			item2.setText(text[index]);
			return convertView;
		}
	}
}
