package com.cdc.android.app.news.webservice;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.cdc.android.app.news.DBHelper;
import com.cdc.android.app.news.MainActivity;
import com.suncco.chinacdc.R;

/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class MyService extends Service {

	public static final String ACTION_SERVICE = "com.cdc.android.app.news";
	public static final String ACTION_SERVICE_CANCEL = "com.cdc.android.app.news.cancel";
	public Executor pool;
	static boolean downLoad = true;
	int theNumber = 50;
	Object obj = new Object();
	boolean run = false;
	// 7,32,33,14,22,32,33,9,10,11
	ArrayList<Integer> chList = new ArrayList<Integer>();
	private NotificationManager mNM;

	@Override
	public void onCreate() {
		chList.add(35);
		chList.add(33);
		chList.add(34);
		chList.add(37);
		chList.add(38);
		chList.add(39);
		chList.add(40);
		chList.add(41);
		chList.add(42);
		chList.add(44);
		chList.add(45);
		chList.add(46);
		pool = Executors.newFixedThreadPool(1);
		mNM = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
	}

	@Override
	public void onDestroy() {
		downLoad = false;
		Log.i("data", "Service onDestroy");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.i("data", "Service onStartCommand");
		if (intent == null) {
			return START_NOT_STICKY;
		}
		handleCommand(intent);
		if (ACTION_SERVICE_CANCEL.equals(intent.getAction())) {
			boolean status = intent.getBooleanExtra("status", false);
			String msg = intent.getStringExtra("msg");
			if (msg != null && msg.length() > 0) {
				Toast.makeText(this, "" + msg, Toast.LENGTH_LONG).show();
			}
			if (!status) {
				// 停止
				Notification notification = new Notification(
						R.drawable.ic_launcher, this.getResources().getText(
								R.string.app_name)
								+ "离线下载停止", System.currentTimeMillis());
				PendingIntent contentIntent = PendingIntent.getActivity(this,
						0, new Intent(this, MainActivity.class), 0);
				int state = HttpHelper.isNetworkConnected(this);
				if (state == HttpHelper.isDisConn) {
					notification.setLatestEventInfo(this, this.getResources()
							.getText(R.string.app_name) + "网络异常下载中断", "",
							contentIntent);
				} else if (state == HttpHelper.is2g) {
					notification.setLatestEventInfo(this, this.getResources()
							.getText(R.string.app_name) + "2g网络下载中断", "",
							contentIntent);
				} else {
					notification.setLatestEventInfo(this, this.getResources()
							.getText(R.string.app_name) + "已取消下载", "",
							contentIntent);
				}
				notification.flags = Notification.FLAG_AUTO_CANCEL;
				mNM.notify(R.string.app_name, notification);
			} else {
				// 完成
				Notification notification = new Notification(
						R.drawable.ic_launcher, this.getResources().getText(
								R.string.app_name)
								+ "离线下载完成", System.currentTimeMillis());
				PendingIntent contentIntent = PendingIntent.getActivity(this,
						0, new Intent(this, MainActivity.class), 0);
				notification
						.setLatestEventInfo(this,
								this.getResources().getText(R.string.app_name)
										+ "下载完成", "", contentIntent);
				mNM.notify(R.string.app_name, notification);
				// mNM.cancel(R.string.app_name);
			}
			stopSelf();
		}
		return START_STICKY;
	}

	void handleCommand(Intent intent) {
		if (ACTION_SERVICE.equals(intent.getAction())) {
			boolean change = intent.getBooleanExtra("change", false);
			// Toast.makeText(this, "离线下线:" + change,
			// Toast.LENGTH_SHORT).show();
			if (!change) {
				downLoad = false;
				mNM.cancel(0);
				return;
			} else {
				downLoad = true;
			}
			synchronized (obj) {
				if (run) {
					return;
				}
				run = true;
				Notification notification = new Notification(
						R.drawable.ic_launcher, this.getResources().getText(
								R.string.app_name)
								+ "离线下载", System.currentTimeMillis());
				PendingIntent contentIntent = PendingIntent.getActivity(this,
						0, new Intent(this, MainActivity.class), 0);
				notification.setLatestEventInfo(this, this.getResources()
						.getText(R.string.app_name) + "正在下载...", "",
						contentIntent);
				mNM.notify(R.string.app_name, notification);
				serviceRun();
			}
		}
	}

	public static boolean stopDownLoad(Context mContext) {
		if (!downLoad) {
			return true;
		}
		int state = HttpHelper.isNetworkConnected(mContext);
		if (state == HttpHelper.isDisConn) {
			return true;
		}
		// if (state == HttpHelper.is2g) {
		// return true;
		// }
		return false;
	}

	public void serviceRun() {
		pool.execute(new Runnable() {
			@Override
			public void run() {
				// 清空
				JSONArray arr = new JSONArray();
				StringBuilder buffer = new StringBuilder();
				File jsonFile = new File(MainActivity.save_path
						+ File.separator + "savedata.txt");
				int jsonIndex = 0;
				for (int i = 0; i < chList.size(); i++) {
					int channelId = chList.get(i);

					if (!downLoad) {
						break;
					}

					// 拿到总共几条
					int total = 0;
					try {
						buffer = new StringBuilder();
						ArrayList<ArticleTitle> tList = Method
								.getArticleList(MainActivity.sessionId, 1, 1,
										channelId, buffer);
						tList.remove(0);
						if (tList.size() == 0) {
							total = 0;
						} else {
							total = tList.get(0).total;
						}
					} catch (Exception e) {
						downLoad = false;
						e.printStackTrace();
					}
					Log.i("myservice", "total :" + total);

					if (!downLoad) {
						break;
					}
					for (int page = 1; page <= total; page++) {
						try {
							buffer = new StringBuilder();
							ArrayList<ArticleTitle> artList = Method
									.getArticleList(MainActivity.sessionId,
											page, 1, channelId, buffer);
							ArticleTitle aTitle = artList.get(0);
							JSONObject jsonObject = new JSONObject();
							jsonObject.put(DBHelper.serviceId, aTitle.id);
							jsonObject.put(DBHelper.title, aTitle.title);
							jsonObject.put(DBHelper.content, " ");
							jsonObject.put(DBHelper.imgurl, aTitle.titleImg);
							jsonObject.put(DBHelper.thetime,aTitle.showTime);
							jsonObject.put(DBHelper.channelid, channelId);
							jsonObject.put(DBHelper.pid, 0);
							arr.put(jsonIndex++, jsonObject);
							if (!downLoad) {
								break;
							}

							buffer = new StringBuilder();
							ArticleContent aContent = Method.getArticleDetail(
									MainActivity.sessionId, aTitle.id, buffer);
							JSONObject jsonObject2 = new JSONObject();
							jsonObject2.put(DBHelper.serviceId, aContent.id);
							jsonObject2.put(DBHelper.title, aContent.title);
							jsonObject2.put(DBHelper.content, aContent.content);
							jsonObject2.put(DBHelper.imgurl, aContent.titleImg);
							jsonObject2.put(DBHelper.thetime, aContent.showTime);
							jsonObject2.put(DBHelper.channelid, channelId);
							jsonObject2.put(DBHelper.pid, aTitle.id);
							arr.put(jsonIndex++, jsonObject2);

							if (!downLoad) {
								break;
							}

						} catch (Exception e1) {
							Log.i("myservice", "" + e1.getMessage());
							downLoad = false;
							break;
						}
					}
				}
				boolean status = downLoad;
				Log.i("myservice", "" + downLoad);
				// 下载完成
				FileOutputStream outFile = null;
				BufferedWriter bufferedWriter = null;
				try {
					outFile = new FileOutputStream(jsonFile);
					bufferedWriter = new BufferedWriter(  
					        new OutputStreamWriter(outFile));  
					bufferedWriter.write(arr.toString()); 
					bufferedWriter.close();
					outFile.close();
				} catch (Exception e) {
					e.printStackTrace();
				}finally{
					if(outFile!=null){
						try {
							outFile.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					if(bufferedWriter!=null){
						try {
							bufferedWriter.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				Intent intent = new Intent(MyService.ACTION_SERVICE_CANCEL);
				intent.putExtra("status", status);
				intent.putExtra("msg", buffer.toString());
				intent.setClass(MyService.this, MyService.class);
				startService(intent);
				run = false;
			}
		});
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

}
