package com.cdc.android.app.news;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;
import android.widget.ImageView;

import com.cdc.android.app.news.webservice.HttpHelper;

/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class CacheImage implements Callback {

	private static final String LOADER_THREAD_NAME = "CacheImage";

	private static final int MESSAGE_REQUEST_LOADING = 1;

	private static final int MESSAGE_IMAGES_LOADED = 2;

	private static final String[] EMPTY_STRING_ARRAY = new String[0];

	private final String[] COLUMNS = new String[] { DBHelper.serviceId,
			DBHelper.imgurl, DBHelper.channelid };

	private final int mDefaultResourceId;

	private static class BitmapHolder {
		private static final int NEEDED = 0;
		private static final int LOADING = 1;
		private static final int LOADED = 2;

		int state;
		SoftReference<Bitmap> bitmapRef;
	}

	private final ConcurrentHashMap<Long, BitmapHolder> mBitmapCache = new ConcurrentHashMap<Long, BitmapHolder>();

	private final ConcurrentHashMap<ImageView, Long> mPendingRequests = new ConcurrentHashMap<ImageView, Long>();

	private final Handler mMainThreadHandler = new Handler(this);

	private LoaderThread mLoaderThread;

	private boolean mLoadingRequested;

	private boolean mPaused;

	private final Context mContext;

	public CacheImage(Context context, int defaultResourceId) {
		mDefaultResourceId = defaultResourceId;
		mContext = context;
	}

	public void loadImage(ImageView view, long imageId) {
		if (imageId == 0) {
			view.setImageResource(mDefaultResourceId);
			mPendingRequests.remove(view);
		} else {
			boolean loaded = loadCachedImage(view, imageId);
			if (loaded) {
				mPendingRequests.remove(view);
			} else {
				mPendingRequests.put(view, imageId);
				if (!mPaused) {
					requestLoading();
				}
			}
		}
	}

	public boolean loadCachedImage(ImageView view, long imageId) {
		BitmapHolder holder = mBitmapCache.get(imageId);
		if (holder == null) {
			holder = new BitmapHolder();
			mBitmapCache.put(imageId, holder);
		} else if (holder.state == BitmapHolder.LOADED) {
			if (holder.bitmapRef == null) {
				view.setImageResource(mDefaultResourceId);
				return true;
			}

			Bitmap bitmap = holder.bitmapRef.get();
			if (bitmap != null) {
				view.setImageBitmap(bitmap);
				return true;
			}

			holder.bitmapRef = null;
		}

		view.setImageResource(mDefaultResourceId);
		holder.state = BitmapHolder.NEEDED;
		return false;
	}

	public void stop() {
		pause();

		if (mLoaderThread != null) {
			mLoaderThread.quit();
			mLoaderThread = null;
		}

		mPendingRequests.clear();
		mBitmapCache.clear();
	}

	public void clear() {
		mPendingRequests.clear();
		mBitmapCache.clear();
	}

	public void pause() {
		mPaused = true;
	}

	public void resume() {
		mPaused = false;
		if (!mPendingRequests.isEmpty()) {
			requestLoading();
		}
	}

	private void requestLoading() {
		if (!mLoadingRequested) {
			mLoadingRequested = true;
			mMainThreadHandler.sendEmptyMessage(MESSAGE_REQUEST_LOADING);
		}
	}

	public boolean handleMessage(Message msg) {
		switch (msg.what) {
		case MESSAGE_REQUEST_LOADING: {
			mLoadingRequested = false;
			if (!mPaused) {
				if (mLoaderThread == null) {
					mLoaderThread = new LoaderThread(
							DBHelper.getReadSQLite(mContext));
					mLoaderThread.start();
				}

				mLoaderThread.requestLoading();
			}
			return true;
		}

		case MESSAGE_IMAGES_LOADED: {
			if (!mPaused) {
				processLoadedImages();
			}
			return true;
		}
		}
		return false;
	}

	private void processLoadedImages() {
		Iterator<ImageView> iterator = mPendingRequests.keySet().iterator();
		while (iterator.hasNext()) {
			ImageView view = iterator.next();
			long imageId = mPendingRequests.get(view);
			Log.i("view", "imageId " + imageId +" view "+(view==null));
			boolean loaded = loadCachedImage(view, imageId);
			if (loaded) {
				iterator.remove();
			}
		}
		mContext.sendBroadcast(new Intent(MainActivity.refresh));
		if (!mPendingRequests.isEmpty()) {
			requestLoading();
		}
	}

	private void cacheBitmap(long id, byte[] bytes, int scale) {
		if (mPaused) {
			return;
		}
		BitmapHolder holder = new BitmapHolder();
		holder.state = BitmapHolder.LOADED;
		if (bytes != null) {
			try {
				BitmapFactory.Options opts = new BitmapFactory.Options();
				opts.inSampleSize = scale;
				Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0,
						bytes.length, opts);
				holder.bitmapRef = new SoftReference<Bitmap>(bitmap);
			} catch (OutOfMemoryError e) {
			}
		}
		mBitmapCache.put(id, holder);
	}

	public void cacheBitmap(long id, Bitmap bitmap) {
		if (mPaused) {
			return;
		}
		BitmapHolder holder = new BitmapHolder();
		holder.state = BitmapHolder.LOADED;
		if (bitmap != null) {
			try {
				holder.bitmapRef = new SoftReference<Bitmap>(bitmap);
			} catch (OutOfMemoryError e) {
			}
		}
		mBitmapCache.put(id, holder);
	}

	private void obtainImageIdsToLoad(ArrayList<Long> imageIds,
			ArrayList<String> imageIdsAsStrings) {
		imageIds.clear();
		imageIdsAsStrings.clear();

		Iterator<Long> iterator = mPendingRequests.values().iterator();
		while (iterator.hasNext()) {
			Long id = iterator.next();
			BitmapHolder holder = mBitmapCache.get(id);
			if (holder != null && holder.state == BitmapHolder.NEEDED) {
				holder.state = BitmapHolder.LOADING;
				imageIds.add(id);
				imageIdsAsStrings.add(id.toString());
			}
		}
	}

	private class LoaderThread extends HandlerThread implements Callback {
		private SQLiteDatabase mRead;
		private final StringBuilder mStringBuilder = new StringBuilder();
		private final ArrayList<Long> mImageIds = CacheLists.newArrayList();
		private final ArrayList<String> mImageIdsAsStrings = CacheLists
				.newArrayList();
		private Handler mLoaderThreadHandler;

		public LoaderThread(SQLiteDatabase resolver) {
			super(LOADER_THREAD_NAME);
			mRead = resolver;
		}

		public void requestLoading() {
			if (mLoaderThreadHandler == null) {
				mLoaderThreadHandler = new Handler(getLooper(), this);
			}
			mLoaderThreadHandler.sendEmptyMessage(0);
		}

		public boolean handleMessage(Message msg) {
			loadImagesFromDatabase();
			mMainThreadHandler.sendEmptyMessage(MESSAGE_IMAGES_LOADED);
			return true;
		}

		private void loadImagesFromDatabase() {

			obtainImageIdsToLoad(mImageIds, mImageIdsAsStrings);

			int count = mImageIds.size();

			if (count == 0) {
				return;
			}
			if (!mRead.isOpen()) {
				mRead = DBHelper.getReadSQLite(mContext);
			}
			mStringBuilder.setLength(0);
			mStringBuilder.append(DBHelper.serviceId + " IN(");
			for (int i = 0; i < count; i++) {
				if (i != 0) {
					mStringBuilder.append(',');
				}
				mStringBuilder.append('?');
			}
			mStringBuilder.append(')');

			HashMap<Long, String> map = new HashMap<Long, String>();
			HashMap<Long, Long> ch_map = new HashMap<Long, Long>();

			Cursor cursor = null;
			try {
				cursor = mRead.query(DBHelper.news, COLUMNS,
						mStringBuilder.toString(),
						mImageIdsAsStrings.toArray(EMPTY_STRING_ARRAY), null,
						null, null);
				if (cursor != null) {
					while (cursor.moveToNext()) {
						Long id = cursor.getLong(0);
						String url = cursor.getString(1);
						Long channelid = cursor.getLong(2);
						map.put(id, url);
						ch_map.put(id, channelid);
					}
				}
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
			mRead.close();

			for (Map.Entry<Long, String> entry : map.entrySet()) {
				if (!mPaused) {
					Long key = entry.getKey();
					try {
						// 50 100
						boolean e = need(key);
						if (e) {
							continue;
						}
						down(key);
						byte[] bytes = HttpHelper.doGet(entry.getValue(),
								null, null);
						if(bytes==null){
							fail(key);
							cacheBitmap(key, null, 1);
							mImageIds.remove(key);
							continue;
						}
						Log.i("test", "bytes "+bytes);
						Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0,
								bytes.length);
						int scale = 1;
						if (bitmap.getHeight() > 58) {
							scale = bitmap.getHeight() / 58;
						}

						// File file = new File(MainActivity.save_path
						// + File.separator + DBHelper.news + "_"
						// + key + ".png");
						// if (file.isFile() && file.exists()) {
						// file.delete();
						// }
						// FileOutputStream outStream = new
						// FileOutputStream(file);
						// bitmap.compress(CompressFormat.PNG, 100, outStream);
						// outStream.close();
						// bitmap.recycle();

						BitmapFactory.Options opts = new BitmapFactory.Options();
						opts.inSampleSize = scale;
						Bitmap bitmapIcon = BitmapFactory.decodeByteArray(
								bytes, 0, bytes.length, opts);
						File fileIcon = new File(MainActivity.save_path
								+ File.separator + ch_map.get(key)
								+ "_" + DBHelper.news + "_icon_"
								+ key + ".png");
						if (fileIcon.isFile() && fileIcon.exists()) {
							fileIcon.delete();
						}
						FileOutputStream outStreamIcon = new FileOutputStream(
								fileIcon);
						bitmapIcon.compress(CompressFormat.PNG, 100,
								outStreamIcon);
						outStreamIcon.close();
						bitmapIcon.recycle();

						// finish(key, file.getAbsolutePath(),
						// fileIcon.getAbsolutePath());

						finish(key, "", fileIcon.getAbsolutePath());

						cacheBitmap(key, bytes, scale);
						mImageIds.remove(key);
					} catch (Exception e) {
						e.printStackTrace();
						fail(key);
						cacheBitmap(key, null, 1);
						mImageIds.remove(key);
					}
				}
			}
			count = mImageIds.size();
			for (int i = 0; i < count; i++) {
				cacheBitmap(mImageIds.get(i), null, 1);
			}
		}
	}

	public boolean need(long id) {
		SQLiteDatabase sqlite = DBHelper.getReadSQLite(mContext);
		Cursor cursor = sqlite.query(
				DBHelper.news,
				new String[] { DBHelper.serviceId },
				DBHelper.serviceId + " = ? and (" + DBHelper.status + " = ? or "
						+ DBHelper.status + " = ?)",
				new String[] { String.valueOf(id), String.valueOf(100),
						String.valueOf(50) }, null, null, null, null);
		boolean e = cursor != null && cursor.getCount() > 0;
		if (cursor != null) {
			cursor.close();
		}
		sqlite.close();
		return e;
	}

	public void finish(long id, String path, String iconPath) {
		SQLiteDatabase mResolver = DBHelper.getSQLite(mContext);
		ContentValues values = new ContentValues(4);
		values.put(DBHelper.serviceId, id);
		values.put(DBHelper.theimg, path);
		values.put(DBHelper.theimgicon, iconPath);
		values.put(DBHelper.status, 100);
		mResolver.update(DBHelper.news, values, DBHelper.serviceId + " = ?",
				new String[] { String.valueOf(id) });
		mResolver.close();
	}

	public void down(long id) {
		SQLiteDatabase mResolver = DBHelper.getSQLite(mContext);
		ContentValues values = new ContentValues(2);
		//values.put(DBHelper._id, id);
		values.put(DBHelper.status, 50);
		mResolver.update(DBHelper.news, values, DBHelper.serviceId + " = ?",
				new String[] { String.valueOf(id) });
		mResolver.close();
	}

	public void fail(long id) {
		Log.i("test", "fail " + id);
		SQLiteDatabase mResolver = DBHelper.getSQLite(mContext);
		ContentValues values = new ContentValues(2);
		//values.put(DBHelper._id, id);
		values.put(DBHelper.status, 1000);
		mResolver.update(DBHelper.news, values, DBHelper.serviceId + " = ?",
				new String[] { String.valueOf(id) });
		mResolver.close();
	}
}