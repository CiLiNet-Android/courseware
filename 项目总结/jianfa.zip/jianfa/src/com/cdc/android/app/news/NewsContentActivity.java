package com.cdc.android.app.news;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebSettings.TextSize;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cdc.android.app.news.webservice.ArticleContent;
import com.cdc.android.app.news.webservice.ArticleTitle;
import com.cdc.android.app.news.webservice.Method;
import com.suncco.chinacdc.R;

/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
@SuppressLint("SetJavaScriptEnabled")
public class NewsContentActivity extends NewsPaperBaseActivity {

	int index = 2;
	int curPos = 0;

	TextSize[] size = { TextSize.SMALLEST, TextSize.SMALLER, TextSize.NORMAL,
			TextSize.LARGER, TextSize.LARGEST };

	ArrayList<Integer> idsList = null;
	int findIdIndex = 0;

	public class NextPreClick implements OnClickListener {

		@Override
		public void onClick(View v) {
			// v.setEnabled(false);
			// v.setClickable(false);
			switch (v.getId()) {
			case R.id.next_btn:
				if (pos < list.size() - 1) {
					pos++;
					Intent intent = new Intent(NewsContentActivity.this,
							NewsContentActivity.class);
					intent.putExtra("newsId", list.get(pos).serviceId);
					intent.putExtra("sessionId", sessionId);
					intent.putExtra("channelId", channelId);
					intent.putExtra("list", list);
					intent.putExtra("channelCurPage", channelCurPage);
					intent.putExtra("searchChannelCurPage",
							searchChannelCurPage);
					intent.putExtra("page", page);
					intent.putExtra("pageSearch", pageSearch);
					intent.putExtra("titleSearch", titleSearch);
					intent.putExtra("pos", pos);
					finish();
					startActivity(intent);
				} else if (pos == (list.size() - 1)) {
					title_text.setEnabled(false);
					title_text.setClickable(false);
					title_text.setText("下一条：加载中...");
					new Thread(new Runnable() {
						@Override
						public void run() {
							getLast();
						}
					}).start();
				}
				break;
			case R.id.pre_btn:
				Log.i("pos", "" + pos);
				if (pos > 0) {
					pos--;
					Intent intent = new Intent(NewsContentActivity.this,
							NewsContentActivity.class);
					intent.putExtra("newsId", list.get(pos).serviceId);
					intent.putExtra("sessionId", sessionId);
					intent.putExtra("channelId", channelId);
					intent.putExtra("list", list);
					intent.putExtra("channelCurPage", channelCurPage);
					intent.putExtra("searchChannelCurPage",
							searchChannelCurPage);
					intent.putExtra("page", page);
					intent.putExtra("pageSearch", pageSearch);
					intent.putExtra("titleSearch", titleSearch);
					intent.putExtra("pos", pos);
					finish();
					startActivity(intent);
				} else if (pos == 0) {
					title_text.setText("上一条：无");
				}
				break;
			default:
				break;
			}
		}

	}
	
	public void getLast(){
		if (titleSearch == null
				|| titleSearch.length() == 0) {
			try {
				getNetData(sessionId, channelId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			 try {
				 getSearchNetData(sessionId, channelId);
			 } catch (Exception e) {
				 e.printStackTrace();
			 }
		}
	}
	
	

	public class ChangeClick implements OnClickListener {

		@Override
		public void onClick(View v) {
//			v.setEnabled(false);
//			v.setClickable(false);
			switch (v.getId()) {
			case R.id.back:
				finish();
				break;
			case R.id.big:
				if (index >= size.length - 1) {
					index = size.length - 1;
				} else {
					index++;
				}
				setTextSize(size[index]);
				break;
			case R.id.small:
				if (index <= 0) {
					index = 0;
				} else {
					index--;
				}
				setTextSize(size[index]);
				break;
			default:
				break;
			}
		}
	}

	public class MenuClick implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.newsBtn:
				finish();
				break;
			case R.id.wenBtn:
				finish();
				Intent wenIntent = new Intent(v.getContext(), WenActivity.class);
				startActivity(wenIntent);
				break;
			case R.id.infoBtn:
				finish();
				Intent infoIntent = new Intent(v.getContext(),
						InfoActivity.class);
				startActivity(infoIntent);
				break;
			case R.id.cdcBtn:
				NewsPaperBaseActivity.isExist =true;
				finish();
				break;
			case R.id.moreBtn:
				finish();
				Intent intent = new Intent(v.getContext(), SetActivity.class);
				startActivity(intent);
				break;
			default:
				break;
			}
		}

	}

	String html = "<html>"
			+ "<head>"
			+ "<title>&nbsp;</title>"
			+ "<style type=\"text/css\">body{font-family:\"黑体\";}"
			+ ".borderBottom{border-bottom:1px solid #d6d6d6;}"
			+ ".font24{font-size:20px;}"
			+ ".font12{font-size:12px;}"
			+ ".color33{color:#333;}"
			+ ".colorGreg{color:#999;}"
			+ ".p10{padding:10px 0 10px 0;}</style>"
			+ "</head>"
			+ "<body>"
			+ "<div style=\"margin-bottom:3px; margin-top: 2px;\" class=\"borderBottom\">"
			+ "<div align=\"center\" class=\"font24 color33\">?title</div>"
			+ "<div align=\"center\" class=\"font12 colorGreg p10\">?time</div>"
			+ "</div>" + "<div>?content</div></body>" + 
			"<script type=\"text/javascript\">function theclick(o) {window.method.lookImage(o.src);}</script></html>";

	WebView webView;
	MyHandler handler;
	Button newsBtn, wenBtn, infoBtn, cdcBtn, moreBtn;
	Button back, small, big;
	Button next_btn, pre_btn;
	TextView title_text;
	int newsId;
	int channelId;
	String sessionId;
	ArticleContent art;
	int channelCurPage;
	int searchChannelCurPage;
	int page;
	int pageSearch;
	String titleSearch;
	ArrayList<News> list;
	int pos;
	boolean netLast = false;
	boolean netLastBtnShow = false;

	final static Pattern imgPattern = Pattern.compile("<img [\\s\\S]*?/>",
			Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
	final static Pattern imgUrlPattern = Pattern.compile("http://[\\s\\S]*?\"",
			Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

	public static String right(String content) {
		Matcher imgMatcher = imgPattern.matcher(content);
		String value = content;
		while (imgMatcher.find()) {
			String findImg = imgMatcher.group();
			Matcher imgUrlMatcher = imgUrlPattern.matcher(findImg);
			if (imgUrlMatcher.find()) {
				String f = imgUrlMatcher.group();
				String findImgUrl = f.substring(0, f.length() - 1);
				String a = "<a href=\"?\">".replace("?", findImgUrl);
				String right = a + findImg + "</a>";
				value = value.replace(findImg, right);
			}
		}
		return value;
	}
	
	public void lookImage(String url){
		Intent intent = new Intent(this, TheImageActivity.class);
		intent.putExtra("url", url);
		startActivity(intent);
	}

	public static String right2(String content) {
		String value = content;
		Matcher imgMatcher = imgPattern.matcher(value);
		while (imgMatcher.find()) {
			value = value.replace(imgMatcher.group(), "");
		}
		return value;
	}

	static class MyHandler extends Handler {
		WeakReference<NewsContentActivity> mActivity;

		MyHandler(NewsContentActivity activity) {
			mActivity = new WeakReference<NewsContentActivity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {
			NewsContentActivity theActivity = mActivity.get();
			switch (msg.what) {
			case 0:
				ArticleContent art = (ArticleContent) msg.obj;
				if (art!=null&&art.title != null) {
					theActivity.html = theActivity.html.replace("?title",
							art.title);
				}else{
					theActivity.html = theActivity.html.replace("?title",
							theActivity.list.get(theActivity.pos).title);
				}
				if (art!=null&&art.showTime != null) {
					theActivity.html = theActivity.html.replace("?time",
							art.showTime);
				}else{
					theActivity.html = theActivity.html.replace("?time",
							theActivity.list.get(theActivity.pos).theTime);
				}
				if (art!=null&&art.content != null) {
					if (MainActivity.canDownImage) {
						String rc = art.content.replace("<img ", "<img onclick=\"theclick(this)\"");
						theActivity.html = theActivity.html.replace("?content", rc);
					} else {
						theActivity.html = theActivity.html.replace("?content",
								right2(art.content));
					}
				}else{
					theActivity.html = theActivity.html.replace("?content",
							"&nbsp;");
				}
				theActivity.webView.loadDataWithBaseURL("", theActivity.html,
						"text/html", "utf-8", null);
				break;
			case 1:
				break;
			case 4:
				Toast.makeText(theActivity, "" + msg.obj, Toast.LENGTH_SHORT)
						.show();
				break;
			case 5:
				if (theActivity.pos >= 0 && theActivity.pos < theActivity.list.size() - 1) {
					theActivity.title_text.setText("下一条：" + theActivity.list.get(theActivity.pos + 1).title);
				} else {
					theActivity.title_text.setText("下一条：无");
				}
				break;
			case 6:
				theActivity.title_text.setEnabled(true);
				theActivity.title_text.setClickable(true);
				theActivity.title_text.setText("下一条：无");
				break;
			default:
				break;
			}
		}
	};

	@SuppressWarnings("unchecked")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_news_content);
		init();

		Intent intent = this.getIntent();
		newsId = intent.getIntExtra("newsId", 0);
		sessionId = intent.getStringExtra("sessionId");
		channelCurPage = intent.getIntExtra("channelCurPage", 0);
		searchChannelCurPage = intent.getIntExtra("searchChannelCurPage", 0);
		page = intent.getIntExtra("page", 0);
		pageSearch = intent.getIntExtra("pageSearch", 0);
		titleSearch = intent.getStringExtra("titleSearch");
		channelId = intent.getIntExtra("channelId", 0);
		list = (ArrayList<News>) intent.getSerializableExtra("list");
		pos = intent.getIntExtra("pos", 0);
		Log.i("pos", "pos init " + pos);
		int insert = intent.getIntExtra("insert", 0);
		if (insert != 0) {
			pos = pos - 1;// ==list index
			list.remove(0);// image
		}
		boolean last = false;
		if (pos >= 0 && pos < list.size() - 1) {
			title_text.setText("下一条：" + list.get(pos + 1).title);
		} else {
			last = pos == (list.size() - 1);
		}
		//
		new Thread(new Runnable() {
			@Override
			public void run() {
				initData(sessionId, newsId);
			}
		}).start();
		if(last){
			title_text.setText("下一条：加载中...");
		}
		if (last) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					getLast();
				}
			}).start();
		}
	}

	// private void initTitle(String sessionId, long newsId) {
	// int c = list.size();//已经加载的数目
	// Method.getArticleDetail(sessionId, newsId, sb);
	// }

	public void setTextSize(TextSize size) {
		WebSettings settings = webView.getSettings();
		settings.setTextSize(size);
	}

	public void initData(final String sessionId, final int newsId) {

		if (!MainActivity.canNet) {
			webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ONLY);
			SQLiteDatabase mResolver = DBHelper.getSQLite(this);
			Cursor cursor = mResolver.query(DBHelper.newsSave, new String[] {
					DBHelper.serviceId, DBHelper.title, DBHelper.content,
					DBHelper.thetime }, DBHelper.channelid + "=? and "
					+ DBHelper.pid + "=?", new String[] { "" + channelId,
					"" + newsId }, null, null, null);
			if (cursor != null) {
				while (cursor.moveToNext()) {
					art = new ArticleContent();
					art.id = cursor.getInt(0);
					art.title = cursor.getString(1);
					art.content = cursor.getString(2);
					art.showTime = cursor.getString(3);
				}
				cursor.close();
			}
			mResolver.close();
			Message msg = new Message();
			msg.what = 0;
			msg.obj = art;
			handler.sendMessage(msg);
			return;
		}
		try {
			StringBuilder sb = new StringBuilder();
			StringBuilder sbCode = new StringBuilder();
			art = Method.getArticleDetail(sessionId, (long) newsId, sb);
			if (art == null) {
//				Message msg = new Message();
//				msg.what = 4;
//				msg.obj = sb.toString();
//				handler.sendMessage(msg);
				handler.sendEmptyMessage(0);
//				if(!sbCode.toString().equals("0")){
//					NewsPaperBaseActivity.noLoginFinish(NewsContentActivity.this);
//				}
				return;
			}

			SQLiteDatabase mResolver = DBHelper.getSQLite(this);

			mResolver.delete(DBHelper.news, DBHelper.channelid + "=? and "
					+ DBHelper.pid + "=?", new String[] { "" + channelId,
					"" + newsId });

			ContentValues values = new ContentValues();
			values.put(DBHelper.serviceId, art.id);
			values.put(DBHelper.title, art.title);
			values.put(DBHelper.content, art.content);
			values.put(DBHelper.thetime, art.showTime);
			values.put(DBHelper.imgurl, art.titleImg);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, newsId);
			mResolver.insert(DBHelper.news, null, values);

			mResolver.close();
			Message msg = new Message();
			msg.what = 0;
			msg.obj = art;
			handler.sendMessage(msg);
		} catch (Exception e) {
//			Message msg = new Message();
//			msg.what = 4;
//			msg.obj = "读取新闻详情失败";
//			handler.sendMessage(msg);
			handler.sendEmptyMessage(0);
			e.printStackTrace();
		}
	}
	
	public void init() {
		handler = new MyHandler(this);
		webView = (WebView) findViewById(R.id.content);
		// webView.setHorizontalScrollBarEnabled(false);//水平不显示
		// webView.setVerticalScrollBarEnabled(false); //垂直不显示
		// webView.getSettings().setSupportZoom(true);
		// webView.getSettings().setBuiltInZoomControls(true);
		webView.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.clearCache(false);
		webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		webView.addJavascriptInterface(this, "method");
		newsBtn = (Button) findViewById(R.id.newsBtn);
		wenBtn = (Button) findViewById(R.id.wenBtn);
		infoBtn = (Button) findViewById(R.id.infoBtn);
		cdcBtn = (Button) findViewById(R.id.cdcBtn);
		moreBtn = (Button) findViewById(R.id.moreBtn);
		MenuClick menuClick = new MenuClick();
		newsBtn.setOnClickListener(menuClick);
		wenBtn.setOnClickListener(menuClick);
		infoBtn.setOnClickListener(menuClick);
		cdcBtn.setOnClickListener(menuClick);
		moreBtn.setOnClickListener(menuClick);
		newsBtn.setBackgroundResource(R.drawable.menu01_click);

		Button back = (Button) findViewById(R.id.back);
		Button small = (Button) findViewById(R.id.small);
		Button big = (Button) findViewById(R.id.big);
		ChangeClick cClick = new ChangeClick();
		back.setOnClickListener(cClick);
		small.setOnClickListener(cClick);
		big.setOnClickListener(cClick);

		next_btn = (Button) findViewById(R.id.next_btn);
		pre_btn = (Button) findViewById(R.id.pre_btn);
		NextPreClick np = new NextPreClick();
		next_btn.setOnClickListener(np);
		pre_btn.setOnClickListener(np);
		title_text = (TextView) findViewById(R.id.title_text);
	}

	public void getNetData(String sessionId, int channelId) throws Exception {
		
		if(netLast){
			handler.sendEmptyMessage(5);
			return;
		}
		channelCurPage++;
		StringBuilder sb = new StringBuilder();
		ArrayList<ArticleTitle> artList = Method.getArticleList(sessionId,
				channelCurPage, MainActivity.number, channelId, sb);
		if (artList == null) {
			Message msg = new Message();
			msg.what = 4;
			msg.obj = sb.toString();
			handler.sendMessage(msg);
			channelCurPage--;
			return;
		}
		artList.remove(artList.size() - 1);
		SQLiteDatabase mResolver = DBHelper.getSQLite(getApplicationContext());
		for (int index = 0; index < artList.size(); index++) {
			ArticleTitle aTitle = artList.get(index);
			ContentValues values = new ContentValues(6);
			values.put(DBHelper.serviceId, aTitle.id);
			values.put(DBHelper.title, aTitle.title);
			values.put(DBHelper.imgurl, aTitle.titleImg);
			values.put(DBHelper.thetime, aTitle.showTime);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, 0);

			News n = new News();
			n.serviceId = aTitle.id;
			n.title = aTitle.title;
			n.imgurl = aTitle.titleImg;
			n.theTime = aTitle.showTime;
			n.channelId = channelId;
			n.pid = 0;
			list.add(n);

			int num = mResolver.update(
					DBHelper.news,
					values,
					DBHelper.channelid + "=? and " + DBHelper.serviceId
							+ "=? and " + DBHelper.pid + "=0",
					new String[] { String.valueOf(channelId),
							String.valueOf(aTitle.id) });
			if (num == 0) {
				mResolver.insert(DBHelper.news, null, values);
			}
		}
		mResolver.close();
		if (artList.size() != MainActivity.number) {
			netLast = true;
			// 未加载到20条说明在最后一页了
			// downOver = true;
		}
		Log.i("response", "response " + pos);
		handler.sendEmptyMessage(5);
	}

	public void getSearchNetData(String sessionId, int channelId)
			throws Exception {

		if(netLast){
			handler.sendEmptyMessage(5);
			return;
		}
		
		searchChannelCurPage++;
		StringBuilder sb = new StringBuilder();
		ArrayList<ArticleTitle> artList = Method.searchArticleList(sessionId,
				"" + searchChannelCurPage, "" + MainActivity.number, ""
						+ channelId, titleSearch, sb);
		if (artList == null) {
			Message msg = new Message();
			msg.what = 4;
			msg.obj = sb.toString();
			handler.sendMessage(msg);
			searchChannelCurPage--;
			return;
		}
		artList.remove(artList.size() - 1);
		SQLiteDatabase mResolver = DBHelper.getSQLite(getApplicationContext());
		for (int index = 0; index < artList.size(); index++) {
			ArticleTitle aTitle = artList.get(index);
			ContentValues values = new ContentValues(6);
			values.put(DBHelper.serviceId, aTitle.id);
			values.put(DBHelper.title, aTitle.title);
			values.put(DBHelper.imgurl, aTitle.titleImg);
			values.put(DBHelper.thetime, aTitle.showTime);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, 0);

			News n = new News();
			n.serviceId = aTitle.id;
			n.title = aTitle.title;
			n.imgurl = aTitle.titleImg;
			n.theTime = aTitle.showTime;
			n.channelId = channelId;
			n.pid = 0;
			list.add(n);

			int num = mResolver.update(
					DBHelper.news,
					values,
					DBHelper.channelid + "=? and " + DBHelper.serviceId
							+ "=? and " + DBHelper.pid + "=0",
					new String[] { String.valueOf(channelId),
							String.valueOf(aTitle.id) });
			if (num == 0) {
				mResolver.insert(DBHelper.news, null, values);
			}

		}
		mResolver.close();
		if (artList.size() != MainActivity.number) {
			netLast = true;
			// 未加载到20条说明在最后一页了
			// downOverSearch = true;
		}
		handler.sendEmptyMessage(5);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		webView.stopLoading();
		webView.clearCache(false);
//		webView.clearHistory();
//		webView.clearView();
		webView.freeMemory();
	}

}
