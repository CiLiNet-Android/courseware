package com.cdc.android.app.news.webservice;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpMessage;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.telephony.TelephonyManager;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public final class HttpHelper {

	public final static int isDisConn = 0;
	public final static int is2g = 2;
	public final static int is3gWifi = 3;

	public static int isNetworkConnected(Context context) {
		if (context == null) {
			return isDisConn;
		}
		ConnectivityManager connManager = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connManager == null) {
			return isDisConn;
		}
		NetworkInfo networkInfo = connManager.getActiveNetworkInfo();
		if (networkInfo == null) {
			return isDisConn;
		}
		State mobileState = connManager.getNetworkInfo(
				ConnectivityManager.TYPE_MOBILE).getState();

		State wifiState = connManager.getNetworkInfo(
				ConnectivityManager.TYPE_WIFI).getState();
		if (mobileState == State.DISCONNECTED
				&& wifiState == State.DISCONNECTED) {
			return isDisConn;
		} else if (wifiState == State.CONNECTED) {
			return is3gWifi;
		}
		TelephonyManager telephonyManager = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		switch (telephonyManager.getNetworkType()) {
		case TelephonyManager.NETWORK_TYPE_1xRTT:
			return is2g; // ~ 50-100 kbps
		case TelephonyManager.NETWORK_TYPE_CDMA:
			return is2g; // ~ 14-64 kbps
		case TelephonyManager.NETWORK_TYPE_EDGE:
			return is2g; // ~ 50-100 kbps
		case TelephonyManager.NETWORK_TYPE_EVDO_0:
			return is3gWifi; // ~ 400-1000 kbps
		case TelephonyManager.NETWORK_TYPE_EVDO_A:
			return is3gWifi; // ~ 600-1400 kbps
		case TelephonyManager.NETWORK_TYPE_GPRS:
			return is2g; // ~ 100 kbps
		case TelephonyManager.NETWORK_TYPE_HSDPA:
			return is3gWifi; // ~ 2-14 Mbps
		case TelephonyManager.NETWORK_TYPE_HSPA:
			return is3gWifi; // ~ 700-1700 kbps
		case TelephonyManager.NETWORK_TYPE_HSUPA:
			return is3gWifi; // ~ 1-23 Mbps
		case TelephonyManager.NETWORK_TYPE_UNKNOWN:
			return is2g;
		default:
			return is3gWifi;
		}
	}

	private static void addHeader(HttpMessage httpMessage,
			TreeMap<String, String> headerMap) {
		if (headerMap != null && headerMap.size() > 0) {
			for (Map.Entry<String, String> entry : headerMap.entrySet()) {
				httpMessage.addHeader(entry.getKey(), entry.getValue());
			}
		}
	}

	private static void timeOutAndHttps(DefaultHttpClient httpClient, String url)
			throws KeyManagementException, NoSuchAlgorithmException,
			KeyStoreException, UnrecoverableKeyException {
		httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
				10000);
		httpClient.getParams().setParameter(
				CoreConnectionPNames.CONNECTION_TIMEOUT, 10000);
	}

	private static HttpGet getAddParamToUrl(String url,
			TreeMap<String, String> param) {
		if (param != null && param.size() > 0) {
			StringBuilder builder = new StringBuilder(url);
			builder.append('?');
			for (Map.Entry<String, String> entry : param.entrySet()) {
				builder.append(entry.getKey()).append('=')
						.append(entry.getValue()).append('&');
			}
			builder.deleteCharAt(builder.length() - 1);
			return new HttpGet(builder.toString());
		} else {
			return new HttpGet(url);
		}
	}

	public static byte[] doGet(final String url,
			final TreeMap<String, String> headerMap,
			final TreeMap<String, String> param) throws Exception {

		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpGet httpGet = getAddParamToUrl(url, param);
		addHeader(httpGet, headerMap);
		HttpEntity reEntity = null;
		try {
			timeOutAndHttps(httpClient, url);
			HttpResponse httpResponse = httpClient.execute(httpGet);
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			reEntity = httpResponse.getEntity();
			if (statusCode == HttpStatus.SC_OK) {
				return EntityUtils.toByteArray(reEntity);
			} else {
				throw new RuntimeException("HttpStatus.SC_OK != 200");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (reEntity != null) {
					reEntity.consumeContent();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			httpClient.getConnectionManager().shutdown();
		}
	}
}
