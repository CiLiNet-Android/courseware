package com.cdc.android.app.news;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.login.LoginActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

public class NewsPaperBaseActivity extends Activity {
	
	public static int RESULT_NOTLOGIN = 101;
	
	public static boolean isExist = false;
	public static boolean isLogin = true;

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(isExist){
			finish();
		}
	}
	
	public static void noLoginFinish(final Context context,String msg){
		NewsPaperBaseActivity.isLogin = false;
		NewsPaperBaseActivity.isExist = true;
		try {
//			final NewsPaperBaseActivity activity = ((NewsPaperBaseActivity)context);
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setMessage(msg + "");
			DialogInterface.OnClickListener l = new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					if (which == DialogInterface.BUTTON_POSITIVE) {
//						Intent intent = new Intent(activity, LoginActivity.class);
						((Activity) context).finish();
					}
				}
			};
			builder.setPositiveButton("重新登录", l);
			builder.setNegativeButton("取消", l);
			if (!((Activity) context).isFinishing())
				builder.create().show();
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
