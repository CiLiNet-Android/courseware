package com.cdc.android.app.news.webservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.cdc.android.app.news.MainActivity;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class MyBroadCastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		MainActivity.canDownImage = MainActivity.netImage(context);
		MainActivity.canOffLine = MainActivity.offLine(context);
		MainActivity.canNet = MainActivity.net(context);
		MyService.downLoad = MyService.stopDownLoad(context);
	}
}
