package com.cdc.android.app.news.webservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.cdc.android.app.news.NewsPaperBaseActivity;

import android.content.Context;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class Method {

	 public final static int timeOut = 20000;
	public final static String code = "code";
	public final static String code0 = "0";
	public final static String msg = "msg";
	public final static String data = "data";
	// http://218.5.66.44:9090/jianfa/ws/articleservice?wsdl
	public final static String nameSpace = "http://218.5.66.44:9090/jianfa";

	public static SoapObject soap(String url, String nameSpace,
			String methodName, HashMap<String, Object> theMap) throws Exception {
		String soapAction = nameSpace + methodName;

		SoapObject request = new SoapObject(nameSpace, methodName);

		for (Map.Entry<String, Object> entry : theMap.entrySet()) {
			request.addProperty(entry.getKey(), entry.getValue());
		}
		SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER11);

		envelope.setOutputSoapObject(request);

		HttpTransportSE ht = new HttpTransportSE(url,timeOut);

		ht.call(soapAction, envelope);

		if (envelope.getResponse() != null) {
			SoapObject response = (SoapObject) envelope.getResponse();
			return response;
		} else {
			throw new RuntimeException("envelope.getResponse()==null");
		}
	}

	/**
	 * 登录
	 * 
	 * @param userName
	 * @param password
	 * @param model
	 * @param systemVersion
	 * @param uuid
	 * @return
	 * @throws Exception
	 */
	public static SoapObject login(String userName, String password,
			String model, String systemVersion, String uuid) throws Exception {
		String methodName = "memberAndroidLogin";
		String url = "http://218.5.66.44:9090/jianfa/ws/organizationservice?wsdl";
		HashMap<String, Object> theMap = new HashMap<String, Object>(5);
		theMap.put("username", userName);
		theMap.put("password", password);
		theMap.put("model", model);
		theMap.put("systemVersion", systemVersion);
		theMap.put("uuid", uuid);
		return soap(url, nameSpace, methodName, theMap);
	}

	/**
	 * 取得sessionId
	 * 
	 * @param userName
	 * @param password
	 * @param model
	 * @param systemVersion
	 * @param uuid
	 * @return
	 * @throws Exception
	 */
	public static String getSessionId(String userName, String password,
			String model, String systemVersion, String uuid, StringBuilder sb)
			throws Exception {
		SoapObject response = login(userName, password, model, systemVersion,
				uuid);
		if (!success(response)) {
			String msgValue = response.getProperty(msg).toString();
			sb.append("" + msgValue);
			return null;
		}
		return ((SoapObject) response.getProperty(data)).getProperty(
				"sessionId").toString();
	}

	/**
	 * 取得栏目列表
	 * 
	 * @param sessionId
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public static ArrayList<Channel> getChannel(String sessionId,
			StringBuilder sb) throws Exception {
		String methodName = "getChannelList";
		String url = "http://218.5.66.44:9090/jianfa/ws/channelservice?wsdl";
		HashMap<String, Object> theMap = new HashMap<String, Object>();
		theMap.put("sessionId", sessionId);
		SoapObject response = soap(url, nameSpace, methodName, theMap);
		if (!success(response)) {
			String msgValue = response.getProperty(msg).toString();
			sb.append("" + msgValue);
			return null;
		}
		SoapObject dataObj = (SoapObject) response.getProperty(data);
		int len = dataObj.getPropertyCount();
		if (len == 0) {
			return null;
		}
		ArrayList<Channel> list = new ArrayList<Channel>();
		for (int index = 0; index < len; index++) {
			SoapObject obj = (SoapObject) dataObj.getProperty(index);
			Channel channel = new Channel();
			channel.id = Integer.parseInt(obj.getProperty("id").toString());
			channel.name = obj.getProperty("name").toString();
			channel.titleImg = obj.getProperty("titleImg").toString();
			channel.isSubscribe = Integer.parseInt(obj.getProperty(
					"isSubscribe").toString());
			channel.isAloneDeploy = Integer.parseInt(obj.getProperty(
					"isAloneDeploy").toString());
			list.add(channel);
		}
		return list;
	}

	/**
	 * 文章列表
	 * 
	 * @param sessionId
	 * @param page
	 * @param numPerPage
	 * @param channelId
	 * @return
	 * @throws Exception
	 */
	public static ArrayList<ArticleTitle> getArticleList(String sessionId,
			int page, int numPerPage, int channelId, StringBuilder sb)
			throws Exception {
		String methodName = "getArticleList";
		String url = "http://218.5.66.44:9090/jianfa/ws/articleservice?wsdl";
		HashMap<String, Object> theMap = new HashMap<String, Object>();
		theMap.put("sessionId", sessionId);
		theMap.put("page", page);
		theMap.put("numPerPage", numPerPage);
		theMap.put("channelId", channelId);
		SoapObject response = soap(url, nameSpace, methodName, theMap);
		if (!success(response)) {
			String msgValue = response.getProperty(msg).toString();
			sb.append("" + msgValue);
			return null;
		}
		SoapObject dataObj = (SoapObject) response.getProperty(data);
		int len = dataObj.getPropertyCount();
		if (len == 0) {
			return null;
		}
		ArrayList<ArticleTitle> list = new ArrayList<ArticleTitle>();
		for (int index = 0; index < len; index++) {
			ArticleTitle articleTitle = new ArticleTitle();
			if (index != len - 1) {
				SoapObject obj = (SoapObject) dataObj.getProperty(index);
				articleTitle.id = Integer.parseInt(obj.getProperty("id")
						.toString());
				articleTitle.title = obj.getProperty("title").toString();
				articleTitle.titleImg = obj.getProperty("titleImg").toString();
				articleTitle.showTime = obj.getProperty("showTime").toString();
			} else {
				articleTitle.total = Integer.parseInt(dataObj
						.getProperty(index).toString());
			}
			list.add(articleTitle);
		}
		return list;
	}

	/**
	 * 搜索文章列表
	 * 
	 * @param sessionId
	 * @param page
	 * @param numPerPage
	 * @param channelId
	 * @return
	 * @throws Exception
	 */
	public static ArrayList<ArticleTitle> searchArticleList(String sessionId,
			String page, String numPerPage, String channelIds, String keyword,
			StringBuilder sb) throws Exception {
		String methodName = "getArticleListByKeywords";
		String url = "http://218.5.66.44:9090/jianfa/ws/articleservice?wsdl";
		HashMap<String, Object> theMap = new HashMap<String, Object>();
		theMap.put("sessionId", sessionId);
		theMap.put("page", page);
		theMap.put("numPerPage", numPerPage);
		theMap.put("channelIds", channelIds);
		theMap.put("keyword", keyword);
		SoapObject response = soap(url, nameSpace, methodName, theMap);
		if (!success(response)) {
			String msgValue = response.getProperty(msg).toString();
			sb.append("" + msgValue);
			return null;
		}
		SoapObject dataObj = (SoapObject) response.getProperty(data);
		int len = dataObj.getPropertyCount();
		if (len == 0) {
			return null;
		}
		ArrayList<ArticleTitle> list = new ArrayList<ArticleTitle>();
		for (int index = 0; index < len; index++) {
			ArticleTitle articleTitle = new ArticleTitle();
			if (index != len - 1) {
				SoapObject obj = (SoapObject) dataObj.getProperty(index);
				articleTitle.id = Integer.parseInt(obj.getProperty("id")
						.toString());
				articleTitle.title = obj.getProperty("title").toString();
				articleTitle.titleImg = obj.getProperty("titleImg").toString();
				articleTitle.showTime = obj.getProperty("showTime").toString();
			} else {
				articleTitle.total = Integer.parseInt(dataObj
						.getProperty(index).toString());
			}
			list.add(articleTitle);
		}
		return list;
	}

	/**
	 * 文件详情
	 * 
	 * @param sessionId
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public static ArticleContent getArticleDetail(String sessionId, long id,
			StringBuilder sb) throws Exception {
		// <![CDATA[
		// ]]>
		String methodName = "getArticleDetail";
		String url = "http://218.5.66.44:9090/jianfa/ws/articleservice?wsdl";
		HashMap<String, Object> theMap = new HashMap<String, Object>();
		theMap.put("sessionId", sessionId);
		theMap.put("id", id);
		SoapObject response = soap(url, nameSpace, methodName, theMap);
		if (!success(response)) {
			String msgValue = response.getProperty(msg).toString();
			sb.append("" + msgValue);
			String code = response.getProperty("code").toString();
			if(!code.equals("0")){
				
			}
			return null;
		}
		SoapObject dataObj = (SoapObject) response.getProperty(data);
		int len = dataObj.getPropertyCount();
		if (len == 0) {
			return null;
		}
		ArticleContent articleContent = new ArticleContent();
		articleContent.id = Integer.parseInt(dataObj.getProperty("id")
				.toString());
		articleContent.title = dataObj.getProperty("title").toString();
		String c = dataObj.getProperty("content").toString();
		if (c.length() > 0&&c.indexOf("<![CDATA[")>=0) {
			String value = c.substring(0, c.length() - "]]>".length())
					.substring("<![CDATA[".length());
			articleContent.content = value;
		} else {
			articleContent.content = "";
		}
		articleContent.showTime = dataObj.getProperty("showTime").toString();
		articleContent.titleImg = dataObj.getProperty("titleImg").toString();
		return articleContent;
	}

	public static boolean success(SoapObject response) {
		if (response == null) {
			return false;
		}
		String theCode = response.getProperty(code).toString();
		if (!code0.equals(theCode)) {
			return false;
		}
		return true;
	}

//	public static void main(String[] args) throws Exception {
//		String userName = "linwh";
//		String password = "itad";
//		String model = "iPod touch";
//		String systemVersion = "iPhone OS(5.1.1)";
//		String uuid = "B8C75D803285";
//		StringBuilder sb = new StringBuilder();
//		String r = getSessionId(userName, password, model, systemVersion, uuid,
//				sb);
//		System.out.println(r);
//		ArrayList<Channel> list = getChannel(r, sb);
//		for (int i = 0; i < list.size(); i++) {
//			Channel ch = list.get(i);
//			System.out.println(ch.id);
//			System.out.println(ch.name);
//			System.out.println(ch.updateNum);
//			System.out.println(ch.titleImg);
//		}
//		System.out.println("******-----------******");
//		ArrayList<ArticleTitle> artList = getArticleList(r, 1, 20, 7, sb);
//		for (int j = 0; j < artList.size(); j++) {
//			ArticleTitle art = artList.get(j);
//			System.out.println(art.id);
//			System.out.println(art.title);
//			System.out.println(art.showTime);
//			System.out.println(art.total);
//		}
//		ArticleContent art = getArticleDetail(r, 255, sb);
//		System.out.println(art.id);
//		System.out.println(art.content);
//		System.out.println(art.title);
//	}
}
