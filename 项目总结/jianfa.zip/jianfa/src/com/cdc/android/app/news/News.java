package com.cdc.android.app.news;

import java.io.Serializable;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class News implements Serializable {
	
	private static final long serialVersionUID = 3388581914918016053L;
	
	public int serviceId;
	public String title;
	public String contentPart;
	public String content;
	public String theTime;
	public String theImg;
	public String imgurl;
	public String theimgIcon;
	public int channelId;
	public int pid;
	public int status;
	public int dbId;
}
