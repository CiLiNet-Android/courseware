package com.cdc.android.app.news;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public final class DBHelper extends SQLiteOpenHelper {

	public final static String thedb = "thedb";
	
	public final static String news = "news";
	public final static String newsSave = "newssave";
	public final static String _id = "_id";
	public final static String serviceId = "serviceId";
	public final static String title = "title";
	public final static String contentpart = "contentpart";
	public final static String content = "content";
	public final static String thetime = "thetime";
	public final static String theimg = "theimg";
	public final static String imgurl = "imgurl";
	public final static String theimgicon = "theimgicon";
	public final static String status = "status";
	public final static String thetype = "thetype";
	public final static String obj = "obj";
	public final static String theorder = "theorder";
	public final static String data1 = "data1";
	public final static String data2 = "data2";
	public final static String data3 = "data3";
	public final static String data4 = "data4";
	public final static String data5 = "data5";
	public final static String data6 = "data6";
	public final static String newupdatenum = "newupdatenum";
	public final static String total = "total";
	public final static String channelid = "channelid";
	public final static String pid = "pid";
	public final static String attachment = "attachment";
	public final static String newsid = "newsid";
	public final static String savepath = "savepath";
	
	public final static String createAttachment = "create table if not exists "+attachment 
			+ " ("+serviceId+" integer primary key autoincrement,"
			+ newsid+" integer default 0,"
			+ savepath+" savepath,"
			+ data1+" text,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";
	
	public final static String createNews = "create table if not exists "+news 
			+ " ("+_id+" integer primary key autoincrement,"
			+ serviceId+" integer default 0,"
			+ title+" text,"
			+ contentpart+" text,"
			+ content+" text,"
			+ thetime+" text,"
			+ theimg+" text,"
			+ imgurl+" text,"
			+ theimgicon+" text,"
			+ pid+" integer default 0,"
			+ status+" integer default 0,"
			+ thetype+" text,"
			+ obj+" text,"
			+ theorder+" text,"
			+ channelid+" integer default 0,"
			+ data1+"  integer default 0,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";
	
	public final static String createNewsSave = "create table if not exists "+newsSave 
			+ " ("+_id+" integer primary key autoincrement,"
			+ serviceId+" integer default 0,"
			+ title+" text,"
			+ contentpart+" text,"
			+ content+" blob,"
			+ thetime+" text,"
			+ theimg+" text,"
			+ imgurl+" text,"
			+ theimgicon+" text,"
			+ pid+" integer default 0,"
			+ status+" integer default 0,"
			+ thetype+" text,"
			+ obj+" text,"
			+ theorder+" text,"
			+ channelid+" integer default 0,"
			+ data1+"  integer default 0,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";

	public final static String logo = "logo";
	
	public final static String createLogo = "create table if not exists "+logo 
			+ " ("+serviceId+" integer primary key autoincrement,"
			+ theimg+" text,"
			+ imgurl+" text,"
			+ theimgicon+" text,"
			+ thetime+" text,"
			+ status+" integer default 0,"
			+ obj+" text,"
			+ theorder+" text,"
			+ data1+" text,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";
	
	public final static String channel = "channel";
	public final static String channelname = "channelname";
	public final static String issubscribe = "issubscribe";
	public final static String isalonedeploy = "isaloneDeploy";
	public final static String updatenum = "updatenum";
	public final static String createChannel = "create table if not exists "+channel 
			+ " ("+_id+" integer primary key autoincrement,"
			+ serviceId+" integer default 0,"
			+ channelname+" text,"
			+ theimg+" text,"
			+ imgurl+" text,"
			+ theimgicon+" text,"
			+ thetime+" text,"
			+ issubscribe+" integer default 0,"
			+ isalonedeploy+" integer default 0,"
			+ status+" integer default 0,"
			+ updatenum+" integer default 0,"
			+ newupdatenum+" integer default 0,"
			+ total+" integer default 0,"
			+ obj+" text,"
			+ theorder+" text,"
			+ data1+" text,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";
	
	public final static String channelpage = "channelpage";
	public final static String curpage = "curpage";
	public final static String updatetime = "updatetime";
	
	public final static String createChannelPage = "create table if not exists "+channelpage 
			+ " ("+_id+" integer primary key autoincrement,"
			+ serviceId+" integer default 0,"
			+ channelid+" integer default 0,"
			+ curpage+" integer default 0,"
			+ status+" integer default 0,"
			+ updatetime + " text,"
			+ data1+" text,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";
	
	public final static String theimage = "theimage";
	
	public final static String createImage = "create table if not exists "+theimage 
			+ " ("+_id+" integer primary key autoincrement,"
			+ serviceId+" integer default 0,"
			+ imgurl+" text,"
			+ theimg+" text,"
			+ theimgicon+" text,"
			+ status+" integer default 0,"
			+ data1+" text,"
			+ data2+" text,"
			+ data3+" text,"
			+ data4+" text,"
			+ data5+" text,"
			+ data6+" text"
					+")";
	
	
	public static SQLiteDatabase getSQLite(Context mContext) {
		synchronized (DBHelper.class) {
			DBHelper db = new DBHelper(mContext);
			return db.getWritableDatabase();
		}
	}
	
	public static SQLiteDatabase getReadSQLite(Context mContext) {
			DBHelper db = new DBHelper(mContext);
			return db.getReadableDatabase();
	}

	public final static int version = 1;

	public DBHelper(Context context) {
		super(context, thedb, null, version);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(createNews);
		db.execSQL(createNewsSave);
		db.execSQL(createLogo);
		db.execSQL(createChannel);
		db.execSQL(createImage);
		db.execSQL(createChannelPage);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// db.execSQL("drop table if exists " + TABLE1);
	}
	
}
