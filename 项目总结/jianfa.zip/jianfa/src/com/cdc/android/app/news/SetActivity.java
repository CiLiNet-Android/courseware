package com.cdc.android.app.news;

import java.io.File;
import java.lang.ref.WeakReference;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.cdc.android.app.news.webservice.MyService;
import com.suncco.chinacdc.R;

/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class SetActivity extends NewsPaperBaseActivity {

	public final static String net2gdown = "net2gdown";
	public final static String wifidown = "wifidown";
	public final static String data = "com.cdc.android.app.news.set";
	ListView listView;
	boolean ch1Status = false;
	boolean ch2Status = false;
	TheAdapter theAdapter;
	Button newsBtn, wenBtn, infoBtn, cdcBtn, moreBtn;
	MyHandler handler;

	public class MenuClick implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.newsBtn:
				finish();
				break;
			case R.id.wenBtn:
				finish();
				Intent wenIntent = new Intent(v.getContext(), WenActivity.class);
				startActivity(wenIntent);
				break;
			case R.id.infoBtn:
				finish();
				Intent infoIntent = new Intent(v.getContext(),
						InfoActivity.class);
				startActivity(infoIntent);
				break;
			case R.id.cdcBtn:
				NewsPaperBaseActivity.isExist =true;
				finish();
				break;
			case R.id.moreBtn:
				break;
			default:
				break;
			}
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_set);
		handler = new MyHandler(this);
		initData();
		init();
	}

	private void initData() {
		SharedPreferences settings = getSharedPreferences(data, MODE_PRIVATE);
		ch1Status = settings.getBoolean(wifidown, false);
		ch2Status = settings.getBoolean(net2gdown, false);
	}

	private void init() {
		newsBtn = (Button) findViewById(R.id.newsBtn);
		wenBtn = (Button) findViewById(R.id.wenBtn);
		infoBtn = (Button) findViewById(R.id.infoBtn);
		cdcBtn = (Button) findViewById(R.id.cdcBtn);
		moreBtn = (Button) findViewById(R.id.moreBtn);
		MenuClick menuClick = new MenuClick();
		newsBtn.setOnClickListener(menuClick);
		wenBtn.setOnClickListener(menuClick);
		infoBtn.setOnClickListener(menuClick);
		cdcBtn.setOnClickListener(menuClick);
		moreBtn.setOnClickListener(menuClick);
		moreBtn.setBackgroundResource(R.drawable.menu05_click);
		Button back = (Button) findViewById(R.id.back);
		back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		listView = (ListView) findViewById(R.id.listView);
		theAdapter = new TheAdapter(this);
		listView.setAdapter(theAdapter);
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int index,
					long pos) {
				switch ((int) pos) {
				case 0:
					ch1Action();
					break;
				case 1:
					ch2Action();
					break;
				case 2:
					AlertDialog.Builder builder = new Builder(SetActivity.this);
					builder.setMessage("清理缓存");
					builder.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									clear();
								}

							});
					builder.setNegativeButton("取消",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
								}
							});
					builder.create().show();
					break;
				default:
					break;
				}
				theAdapter.notifyDataSetChanged();
			}
		});
	}

	private class TheAdapter extends BaseAdapter {

		private Context mContext;

		public TheAdapter(Context context) {
			mContext = context;
		}

		public int getCount() {
			return 3;
		}

		public Object getItem(int position) {
			return new Object();
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			RelativeLayout layout;
			final LayoutInflater mInflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			switch (position) {
			case 0:
				layout = (RelativeLayout) mInflater.inflate(
						R.layout.activity_set_item1, parent, false);
				CheckBox ch1 = (CheckBox) layout.findViewById(R.id.wifiCheck);
				ch1.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						ch1Action();
					}
				});
				ch1.setChecked(ch1Status);
				break;
			case 1:
				layout = (RelativeLayout) mInflater.inflate(
						R.layout.activity_set_item2, parent, false);
				CheckBox ch2 = (CheckBox) layout.findViewById(R.id.netCheck);
				ch2.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						ch2Action();
					}
				});
				ch2.setChecked(ch2Status);
				break;
			case 2:
				layout = (RelativeLayout) mInflater.inflate(
						R.layout.activity_set_item3, parent, false);
				break;
			default:
				layout = (RelativeLayout) mInflater.inflate(
						R.layout.activity_set_item3, parent, false);
				break;
			}
			return layout;
		}
	}

	public void ch1Action() {
		ch1Status = !ch1Status;
		SharedPreferences settings2 = getSharedPreferences(data, MODE_PRIVATE);
		SharedPreferences.Editor editor2 = settings2.edit();
		editor2.putBoolean(wifidown, ch1Status);
		editor2.commit();
		Intent intent = new Intent(MyService.ACTION_SERVICE);
		intent.putExtra("change", ch1Status);
		intent.setClass(this, MyService.class);
		startService(intent);
	}

	public void ch2Action() {
		ch2Status = !ch2Status;
		SharedPreferences settings = getSharedPreferences(data, MODE_PRIVATE);
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean(net2gdown, ch2Status);
		editor.commit();
		MainActivity.canDownImage = MainActivity.netImage(this);
	}

	private void clear() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				SQLiteDatabase sqlite = DBHelper.getSQLite(getApplicationContext());
				sqlite.delete(DBHelper.news, null, null);
				sqlite.delete(DBHelper.newsSave, null, null);
				sqlite.close();
				String savePath = MainActivity.save_path;
				File f = new File(savePath+"/");
				if (f.isDirectory()) {
					File[] del = f.listFiles();
					for (int i = 0; i < del.length; i++) {
						del[i].delete();
					}
				}
				handler.sendEmptyMessage(0);
			}
		}).start();
	}
	
	static class MyHandler extends Handler {
		WeakReference<SetActivity> mActivity;

		MyHandler(SetActivity activity) {
			mActivity = new WeakReference<SetActivity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {
			SetActivity theActivity = mActivity.get();
			switch (msg.what) {
			case 0:
				Toast.makeText(theActivity, "清理完成", Toast.LENGTH_SHORT).show();
				break;
			default:
				break;
			}
		}
	};
}
