package com.cdc.android.app.news;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.suncco.chinacdc.R;

public class TheImageActivity extends Activity {

	String html = "<html><head><title></title></head><body><img src=\"?\" ></body></html>";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_theimage);
		WebView webView = (WebView)findViewById(R.id.webView);
//		webView.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setBuiltInZoomControls(true);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.clearCache(false);
		webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		Intent intent = this.getIntent();
		String url = intent.getStringExtra("url");
		html = html.replace("?", url);
		webView.loadDataWithBaseURL("", html,"text/html", "utf-8", null);
	}
}
