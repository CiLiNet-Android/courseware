package com.cdc.android.app.news.webservice;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class Channel {
	
	public int id;//资讯id
	public String name;//资讯名称
	public String titleImg;//图标
	public int isSubscribe;//是否必须订阅  1-订阅  0-不订阅 
	public int isAloneDeploy;//是否独立部署  1-是   0-否
	public int updateNum;//当天文章更新数
}
