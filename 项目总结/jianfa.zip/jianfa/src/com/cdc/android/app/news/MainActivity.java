package com.cdc.android.app.news;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.cdc.android.app.news.webservice.ArticleTitle;
import com.cdc.android.app.news.webservice.HttpHelper;
import com.cdc.android.app.news.webservice.Method;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;

/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class MainActivity extends NewsPaperBaseActivity {

	public class TheReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (action != null && action.equals(refresh)) {
				Log.i("view", "get");
				if (titleSearch == null || titleSearch.length() == 0) {
					newsAdapter.notifyDataSetChanged();
				} else {
					searchNewsAdapter.notifyDataSetChanged();
				}
			}
		}
	}

	public class SearchClick implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.search:
				mainHeadLayout.setVisibility(View.GONE);
				mainSearchLayout.setVisibility(View.VISIBLE);
				searchTitleBtn
						.setBackgroundResource(R.drawable.search_btn_close);
				searchTitle.setText("");
				searchTitle.setFocusable(true);
				searchTitle.setFocusableInTouchMode(true);
				searchTitle.requestFocus();
				InputMethodManager inputManager = (InputMethodManager) v
						.getContext().getSystemService(
								Context.INPUT_METHOD_SERVICE);
				inputManager.showSoftInput(searchTitle, 0);
				break;
			case R.id.searchTitleBtn:

				InputMethodManager inputManagerClose = (InputMethodManager) v
						.getContext().getSystemService(
								Context.INPUT_METHOD_SERVICE);
				inputManagerClose.hideSoftInputFromWindow(
						searchTitle.getWindowToken(), 0);
				if (!titleChange) {
					titleChange = true;
					searchTitleBtn.setBackgroundResource(R.drawable.search_btn);
					// /////////////
					mainHeadLayout.setVisibility(View.VISIBLE);
					mainSearchLayout.setVisibility(View.GONE);
					pullListView.setVisibility(View.VISIBLE);
					searchListView.setVisibility(View.GONE);
					loadLayout.setVisibility(View.GONE);
				} else {
					titleChange = false;
					searchTitleBtn
							.setBackgroundResource(R.drawable.search_btn_close);
					// //////////
					titleSearch = searchTitle.getText().toString().trim();
					if (titleSearch.length() > 0) {
						pullListView.setVisibility(View.GONE);
						searchListView.setVisibility(View.GONE);
						loadLayout.setVisibility(View.VISIBLE);
						new Thread(new Runnable() {
							@Override
							public void run() {
								doSearch();
							}
						}).start();
					}
				}
				break;
			default:
				break;
			}
		}
	}

	public class MenuClick implements OnClickListener {
		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.newsBtn:
				break;
			case R.id.wenBtn:
				Intent wenIntent = new Intent(v.getContext(), WenActivity.class);
				startActivity(wenIntent);
				break;
			case R.id.infoBtn:
				Intent infoIntent = new Intent(v.getContext(),
						InfoActivity.class);
				startActivity(infoIntent);
				break;
			case R.id.cdcBtn:
				NewsPaperBaseActivity.isExist =true;
				finish();
				break;
			case R.id.moreBtn:
				Intent moreIntent = new Intent(v.getContext(),
						SetActivity.class);
				startActivity(moreIntent);
				break;
			default:
				break;
			}
		}

	}

	public class PullListClick implements OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> adapter, View view, int index,
				long position) {
			if (position == 0) {
				return;
			}
			Intent intent = new Intent(view.getContext(),
					NewsContentActivity.class);
			intent.putExtra("newsId", list.get((int) position).serviceId);
			intent.putExtra("sessionId", sessionId);
			intent.putExtra("channelId", channelId);
			intent.putExtra("list", list);
			intent.putExtra("channelCurPage", channelCurPage);
			intent.putExtra("searchChannelCurPage", searchChannelCurPage);
			intent.putExtra("page", page);
			intent.putExtra("pageSearch", pageSearch);
			intent.putExtra("titleSearch", titleSearch);
			intent.putExtra("pos", (int) position);
			intent.putExtra("insert", 1);
			startActivity(intent);
		}

	}

	public class SearchListClick implements OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> adapter, View view, int index,
				long position) {
			if (position == 0) {
				return;
			}
			Intent intent = new Intent(view.getContext(),
					NewsContentActivity.class);
			intent.putExtra("newsId", searchList.get((int) position).serviceId);
			intent.putExtra("sessionId", sessionId);
			intent.putExtra("channelId", channelId);
			intent.putExtra("list", searchList);
			intent.putExtra("channelCurPage", channelCurPage);
			intent.putExtra("searchChannelCurPage", searchChannelCurPage);
			intent.putExtra("page", page);
			intent.putExtra("pageSearch", pageSearch);
			intent.putExtra("titleSearch", titleSearch);
			intent.putExtra("pos", (int) position);
			intent.putExtra("insert", 1);
			startActivity(intent);
		}

	}

	PullListView pullListView;
	PullListView searchListView;
	NewsAdapter newsAdapter;
	SearchNewsAdapter searchNewsAdapter;
	Object obj = new Object();
	Object searchObj = new Object();
	boolean down = true;
	boolean searchDown = true;
	boolean up = true;
	boolean downOver = false;
	boolean downOverSearch = false;
	ArrayList<News> list;
	ArrayList<News> searchList;
	public final static int number = 10;
	int channelId = 35;
	public static String sessionId = "";
	int channelCurPage = 0;
	int searchChannelCurPage = 0;
	MyHandler handler;
	RelativeLayout loadLayout;
	Button newsBtn, wenBtn, infoBtn, cdcBtn, moreBtn;
	public static boolean canDownImage = false;
	public static boolean aboutSDCard = true;
	public static boolean canOffLine = false;
	public static boolean canNet = false;
	public static int screenWidth = 0;// 屏幕宽（像素，如：480px）
	public static int screenHeight = 0;
	public static int webWidth = 0;
	Button search;
	RelativeLayout mainHeadLayout;
	LinearLayout mainSearchLayout;
	Button searchTitleBtn;
	EditText searchTitle;
	int page = 0;
	int pageSearch = 0;
	String titleSearch = "";
	boolean titleChange = false;
	ImageDownloader imageDown;

	public static String save_path = Environment.getExternalStorageDirectory()
			.getAbsolutePath() + File.separator + "cdc_news_image";
	public static String save_path_wifi = Environment
			.getExternalStorageDirectory().getAbsolutePath()
			+ File.separator
			+ "cdc_news_image_wifi";

	final static String[] queryItem = new String[] { DBHelper.serviceId,
			DBHelper.title, DBHelper.contentpart, DBHelper.thetime,
			DBHelper.theimgicon, DBHelper.imgurl };

	CacheImage cacheImage;
	TheReceiver theReceiver;

	static class MyHandler extends Handler {
		WeakReference<MainActivity> mActivity;

		MyHandler(MainActivity activity) {
			mActivity = new WeakReference<MainActivity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {
			MainActivity theActivity = mActivity.get();
			switch (msg.what) {
			case 0:
				theActivity.upHandler();
				break;
			case 1:
				theActivity.downHandler();
				break;
			case 2:
				theActivity.initHandler();
				break;
			case 3:
				// theActivity.newsAdapter.notifyDataSetChanged();
				// theActivity.searchNewsAdapter.notifyDataSetChanged();
				break;
			case 4:
				Toast.makeText(theActivity, "" + msg.obj, Toast.LENGTH_SHORT)
						.show();
				break;
			case 5:
				theActivity.upSearchHandler();
				break;
			case 6:
				theActivity.downSearchHandler();
				break;
			case 7:
				theActivity.initSearchHandler();
				break;
			case 8:
				NewsPaperBaseActivity.noLoginFinish(theActivity,"" + msg.obj);
				break;
			default:
				break;
			}
		}
	};

	public void initHandler() {
		loadLayout.setVisibility(View.GONE);
		pullListView.setVisibility(View.VISIBLE);
		downHandler();
	}

	public void initSearchHandler() {
		loadLayout.setVisibility(View.GONE);
		searchListView.setVisibility(View.VISIBLE);
		downSearchHandler();
	}

	public void upHandler() {
		down = true;
		downOver = false;
		cacheImage.clear();
		newsAdapter.setDataList(list);
		pullListView.onRefreshComplete();
	}

	public void downHandler() {
		down = true;
		hideFoot();
		cacheImage.clear();
		newsAdapter.setDataList(list);
	}

	public void upSearchHandler() {
		searchDown = true;
		downOverSearch = false;
		cacheImage.clear();
		searchNewsAdapter.setDataList(searchList);
		searchListView.onRefreshComplete();
	}

	public void downSearchHandler() {
		searchDown = true;
		hideSearchFoot();
		cacheImage.clear();
		searchNewsAdapter.setDataList(searchList);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		DisplayMetrics dm = new DisplayMetrics();
		dm = getResources().getDisplayMetrics();
		screenWidth = dm.widthPixels; // 屏幕宽（像素，如：480px）
		screenHeight = dm.heightPixels;
		final float scale = this.getResources().getDisplayMetrics().density;
		webWidth = (int) (screenWidth / scale + 0.5f);
		imageDown = new ImageDownloader();
		init();
		// SharedPreferences settings = getSharedPreferences(SetActivity.data,
		// MODE_PRIVATE);
		// boolean d = settings.getBoolean(SetActivity.wifidown, false);
		// int state = HttpHelper.isNetworkConnected(this);
		// if (state == HttpHelper.is3gWifi && d) {
		// Intent intent = new Intent(MyService.ACTION_SERVICE);
		// intent.putExtra("change", d);
		// intent.setClass(this, MyService.class);
		// startService(intent);
		// }
		initData();
	}

	@Override
	protected void onStop() {
		unregisterReceiver(theReceiver);
		super.onStop();
	}

	public void init() {
		handler = new MyHandler(this);
		SQLiteDatabase sqlite = DBHelper.getSQLite(this);
		sqlite.close();
		aboutFile();
		canDownImage = netImage(this);
		canOffLine = offLine(this);
		canNet = net(this);
		// ///////////////////////////////
		loadLayout = (RelativeLayout) findViewById(R.id.loadLayout);
		cacheImage = new CacheImage(this, R.drawable.no_image);
		pullListView = (PullListView) findViewById(R.id.listView);
		searchListView = (PullListView) findViewById(R.id.searchListView);
		newsBtn = (Button) findViewById(R.id.newsBtn);
		wenBtn = (Button) findViewById(R.id.wenBtn);
		infoBtn = (Button) findViewById(R.id.infoBtn);
		cdcBtn = (Button) findViewById(R.id.cdcBtn);
		moreBtn = (Button) findViewById(R.id.moreBtn);
		MenuClick menuClick = new MenuClick();
		newsBtn.setOnClickListener(menuClick);
		wenBtn.setOnClickListener(menuClick);
		infoBtn.setOnClickListener(menuClick);
		cdcBtn.setOnClickListener(menuClick);
		moreBtn.setOnClickListener(menuClick);
		newsBtn.setBackgroundResource(R.drawable.menu01_click);
		search = (Button) findViewById(R.id.search);
		SearchClick searchClick = new SearchClick();
		search.setOnClickListener(searchClick);
		mainHeadLayout = (RelativeLayout) findViewById(R.id.mainHeadLayout);
		mainSearchLayout = (LinearLayout) findViewById(R.id.mainSearchLayout);
		searchTitleBtn = (Button) findViewById(R.id.searchTitleBtn);
		searchTitleBtn.setOnClickListener(searchClick);
		searchTitle = (EditText) findViewById(R.id.searchTitle);
		searchTitle.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (v.hasFocus()) {
					searchTitleBtn
							.setBackgroundResource(R.drawable.search_btn_close);
				} else {
					searchTitleBtn.setBackgroundResource(R.drawable.search_btn);
				}
			}
		});

		searchTitle.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				String text = s.toString();
				if (text.toString().length() > 0) {
					titleChange = true;
					searchTitleBtn.setBackgroundResource(R.drawable.search_btn);
				} else {
					titleChange = false;
					searchTitleBtn
							.setBackgroundResource(R.drawable.search_btn_close);
				}
			}
		});

		searchTitle.setOnEditorActionListener(new OnEditorActionListener() {
			public boolean onEditorAction(TextView v, int actionId,
					KeyEvent event) {
				boolean enter = false;
				if (actionId == EditorInfo.IME_ACTION_DONE) {
					enter = true;
				}
				if (event != null
						&& (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
					enter = true;
				}
				if (enter) {
					InputMethodManager inputManagerClose = (InputMethodManager) v
							.getContext().getSystemService(
									Context.INPUT_METHOD_SERVICE);
					inputManagerClose.hideSoftInputFromWindow(
							searchTitle.getWindowToken(), 0);
					titleSearch = searchTitle.getText().toString().trim();
					if (titleSearch.length() > 0) {
						pullListView.setVisibility(View.GONE);
						searchListView.setVisibility(View.GONE);
						loadLayout.setVisibility(View.VISIBLE);
						titleChange = false;
						searchTitleBtn
								.setBackgroundResource(R.drawable.search_btn_close);
						new Thread(new Runnable() {
							@Override
							public void run() {
								doSearch();
							}
						}).start();
					}
				}
				return false;
			}
		});
		// //////////
		LinearLayout initLayout = (LinearLayout) findViewById(R.id.initLayout);
		ImageView logoImage = new ImageView(this);
		// 0.195
		logoImage.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
				(int) (0.195 * screenHeight)));
		logoImage.setScaleType(ImageView.ScaleType.FIT_XY);
		logoImage.setImageResource(R.drawable.logo);
		initLayout.addView(logoImage);
		// ///////////
		setListView();
		setSearchListView();
		newsAdapter = new NewsAdapter(this);
		searchNewsAdapter = new SearchNewsAdapter(this);
		pullListView.setAdapter(newsAdapter);
		searchList = new ArrayList<News>();
		searchList.add(new News());
		searchNewsAdapter.setDataList(searchList);
		searchListView.setAdapter(searchNewsAdapter);
		Button back = (Button) findViewById(R.id.back);
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}

	public void doSearch() {
		if (!canNet) {
			readSearchDataToUIOffLine();
			handler.sendEmptyMessage(7);
			return;
		}
		try {
			getSearchFirstNetData(sessionId, channelId);
		} catch (Exception e) {
			Message msg = new Message();
			msg.what = 4;
			msg.obj = "网络连接错误";
			handler.sendMessage(msg);
			readDataToUIOffLine();
			e.printStackTrace();
		}
		readSearchDataToUILine();
		handler.sendEmptyMessage(7);
	}

	public void initData() {
		new Thread(new Runnable() {
			@Override
			public void run() {

				if (!canNet) {

					try {
						File jsonFile = new File(MainActivity.save_path
								+ File.separator + "savedata.txt");
						FileInputStream inputStream = new FileInputStream(
								jsonFile);
						BufferedReader bufferedReader = new BufferedReader(
								new InputStreamReader(inputStream));
						StringBuffer buffer = new StringBuffer();
						String text = null;
						while ((text = bufferedReader.readLine()) != null) {
							buffer.append(text);
						}
						JSONArray arr = new JSONArray(buffer.toString());
						int len = arr.length();
						SQLiteDatabase mSqlite = DBHelper
								.getSQLite(getApplicationContext());
						Log.i("test", "test " + len);
						for (int index = 0; index < len; index++) {
							JSONObject json = arr.getJSONObject(index);
							ContentValues values = new ContentValues();
							String sid = json.getString(DBHelper.serviceId);
							values.put(DBHelper.serviceId, sid);
							values.put(DBHelper.title, json.getString(DBHelper.title));
							values.put(DBHelper.imgurl, json.getString(DBHelper.imgurl));
							values.put(DBHelper.thetime, json.getString(DBHelper.thetime));
							String cid = json.getString(DBHelper.channelid);
							values.put(DBHelper.channelid, cid);
							values.put(DBHelper.content, json.getString(DBHelper.content));
							String pid = json.getString(DBHelper.pid);
							values.put(DBHelper.pid, pid);
							int num = mSqlite.update(
									DBHelper.news,
									values,
									DBHelper.channelid + "=? and " + DBHelper.serviceId
											+ "=? and " + DBHelper.pid + "=?",
									new String[] { cid,sid,pid});
							if (num == 0) {
								mSqlite.insert(DBHelper.news, null, values);
							}
						}
						mSqlite.close();
					} catch (Exception e) {
						Log.i("test", ""+e.getMessage());
					}
//					String[] theQuery = new String[] { DBHelper.serviceId,
//							DBHelper.title, DBHelper.contentpart,
//							DBHelper.thetime, DBHelper.theimgicon,
//							DBHelper.imgurl, DBHelper.channelid, DBHelper.pid,
//							DBHelper.content, DBHelper.status, DBHelper._id };
//					SQLiteDatabase mSqlite = DBHelper
//							.getSQLite(getApplicationContext());
//					Cursor cursor = mSqlite.query(DBHelper.news, theQuery,
//							null, null, null, null, null, null);
//					ArrayList<News> newsTable = new ArrayList<News>();
//					if (cursor != null) {
//						while (cursor.moveToNext()) {
//							News newItem = new News();
//							newItem.serviceId = cursor.getInt(0);
//							newItem.title = cursor.getString(1);
//							newItem.contentPart = cursor.getString(2);
//							newItem.theTime = cursor.getString(3);
//							newItem.theimgIcon = cursor.getString(4);
//							newItem.imgurl = cursor.getString(5);
//							newItem.channelId = cursor.getInt(6);
//							newItem.pid = cursor.getInt(7);
//							newItem.content = cursor.getString(8);
//							newItem.status = cursor.getInt(9);
//							newItem.dbId = cursor.getInt(10);
//							newsTable.add(newItem);
//						}
//						cursor.close();
//					}
//					for (int index = 0; index < newsTable.size(); index++) {
//						News newItem = newsTable.get(index);
//						Cursor c = mSqlite.query(DBHelper.newsSave,
//								new String[] { DBHelper.serviceId },
//								DBHelper.serviceId + "=? and "
//										+ DBHelper.channelid + "=? and "
//										+ DBHelper.pid + "=?", new String[] {
//										"" + newItem.serviceId,
//										"" + newItem.channelId,
//										"" + newItem.pid }, null, null, null);
//
//						boolean e = c != null && c.getCount() > 0;
//						if (c != null) {
//							c.close();
//						}
//						if (e) {
//							continue;
//						}
//						ContentValues values = new ContentValues();
//						values.put(DBHelper.serviceId, newItem.serviceId);
//						values.put(DBHelper.title, newItem.title);
//						values.put(DBHelper.imgurl, newItem.imgurl);
//						values.put(DBHelper.thetime, newItem.theTime);
//						values.put(DBHelper.channelid, newItem.channelId);
//						values.put(DBHelper.content, newItem.content);
//						values.put(DBHelper.pid, newItem.pid);
//						values.put(DBHelper.status, newItem.status);
//						values.put(DBHelper.data1, newItem.dbId);
//						mSqlite.insert(DBHelper.newsSave, null, values);
//					}
//					mSqlite.close();
					readDataToUIOffLine();
					handler.sendEmptyMessage(2);
					return;
				}

				// //////////////////////////
				String userName = "linwh";
				String password = "itad";
				String model = "iPod touch";
				String systemVersion = "iPhone OS(5.1.1)";
				String uuid = "B8C75D803285";
				try {
					StringBuilder sb = new StringBuilder();
//					sessionId = Method.getSessionId(userName, password, model,
//							systemVersion, uuid, sb);
					sessionId = LoginBean.getInstance().sessionId;
					if (sessionId == null) {
						Message msg = new Message();
						msg.what = 8;
						msg.obj = sb.toString();
						handler.sendMessage(msg);
						return;
					}
					sb = new StringBuilder();
					getFirstNetData(sessionId, channelId);
				} catch (Exception e) {
					Message msg = new Message();
					msg.what = 4;
					msg.obj = "网络连接错误";
					handler.sendMessage(msg);
					readDataToUIOffLine();
					e.printStackTrace();
				}
				readDataToUILine();
				handler.sendEmptyMessage(2);
			}
		}).start();
	}

	public void getFirstNetData(String sessionId, int channelId)
			throws Exception {
		// /
		channelCurPage = 1;
		StringBuilder sb = new StringBuilder();
		ArrayList<ArticleTitle> artList = Method.getArticleList(sessionId,
				channelCurPage, number, channelId, sb);
		if (artList == null) {
			Message msg = new Message();
			msg.what = 8;
			msg.obj = sb.toString();
			handler.sendMessage(msg);
			channelCurPage = 1;
			return;
		}
		artList.remove(artList.size() - 1);
		SQLiteDatabase mResolver = DBHelper.getSQLite(getApplicationContext());
		//
		// mResolver.delete(DBHelper.news, DBHelper.channelid + "=?",
		// new String[] { String.valueOf(channelId) });

		for (int index = 0; index < artList.size(); index++) {
			// ArticleTitle aTitle = artList.get(index);
			// ContentValues values = new ContentValues(6);
			// values.put(DBHelper.serviceId, aTitle.id);
			// values.put(DBHelper.title, aTitle.title);
			// values.put(DBHelper.imgurl, aTitle.titleImg);
			// values.put(DBHelper.thetime, aTitle.showTime);
			// values.put(DBHelper.channelid, channelId);
			// values.put(DBHelper.pid, 0);
			// mResolver.insert(DBHelper.news, null, values);

			ArticleTitle aTitle = artList.get(index);
			ContentValues values = new ContentValues(6);
			values.put(DBHelper.serviceId, aTitle.id);
			values.put(DBHelper.title, aTitle.title);
			values.put(DBHelper.imgurl, aTitle.titleImg);
			values.put(DBHelper.thetime, aTitle.showTime);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, 0);
			int num = mResolver.update(
					DBHelper.news,
					values,
					DBHelper.channelid + "=? and " + DBHelper.serviceId
							+ "=? and " + DBHelper.pid + "=0",
					new String[] { String.valueOf(channelId),
							String.valueOf(aTitle.id) });
			if (num == 0) {
				mResolver.insert(DBHelper.news, null, values);
			}

		}
		mResolver.close();
		if (artList.size() != number) {
			// 未加载到20条说明在最后一页了
			downOver = true;
		}
	}

	public void getSearchFirstNetData(String sessionId, int channelId)
			throws Exception {
		// /
		searchChannelCurPage = 1;
		StringBuilder sb = new StringBuilder();
		ArrayList<ArticleTitle> artList = Method.searchArticleList(sessionId,
				"" + searchChannelCurPage, "" + number, "" + channelId,
				titleSearch, sb);
		if (artList == null) {
			Message msg = new Message();
			msg.what = 8;
			msg.obj = sb.toString();
			handler.sendMessage(msg);
			searchChannelCurPage = 1;
			return;
		}
		artList.remove(artList.size() - 1);
		SQLiteDatabase mResolver = DBHelper.getSQLite(getApplicationContext());
		//
		// mResolver.delete(DBHelper.news, DBHelper.channelid + "=? and "
		// + DBHelper.title + " like ?",
		// new String[] { String.valueOf(channelId),
		// "%" + titleSearch + "%" });

		for (int index = 0; index < artList.size(); index++) {
			ArticleTitle aTitle = artList.get(index);
			ContentValues values = new ContentValues(6);
			values.put(DBHelper.serviceId, aTitle.id);
			values.put(DBHelper.title, aTitle.title);
			values.put(DBHelper.imgurl, aTitle.titleImg);
			values.put(DBHelper.thetime, aTitle.showTime);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, 0);
			int num = mResolver.update(
					DBHelper.news,
					values,
					DBHelper.channelid + "=? and " + DBHelper.serviceId
							+ "=? and " + DBHelper.pid + "=0",
					new String[] { String.valueOf(channelId),
							String.valueOf(aTitle.id) });
			if (num == 0) {
				mResolver.insert(DBHelper.news, null, values);
			}
			// //////////mResolver.insert(DBHelper.news, null, values);
		}
		mResolver.close();
		if (artList.size() != number) {
			// 未加载到20条说明在最后一页了
			downOverSearch = true;
		}
	}

	public void getNetData(String sessionId, int channelId) throws Exception {
		channelCurPage++;
		StringBuilder sb = new StringBuilder();
		ArrayList<ArticleTitle> artList = Method.getArticleList(sessionId,
				channelCurPage, number, channelId, sb);
		if (artList == null) {
			Message msg = new Message();
			msg.what = 8;
			msg.obj = sb.toString();
			handler.sendMessage(msg);
			channelCurPage--;
			return;
		}
		artList.remove(artList.size() - 1);
		SQLiteDatabase mResolver = DBHelper.getSQLite(getApplicationContext());
		for (int index = 0; index < artList.size(); index++) {
			ArticleTitle aTitle = artList.get(index);
			ContentValues values = new ContentValues(6);
			values.put(DBHelper.serviceId, aTitle.id);
			values.put(DBHelper.title, aTitle.title);
			values.put(DBHelper.imgurl, aTitle.titleImg);
			values.put(DBHelper.thetime, aTitle.showTime);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, 0);

			int num = mResolver.update(
					DBHelper.news,
					values,
					DBHelper.channelid + "=? and " + DBHelper.serviceId
							+ "=? and " + DBHelper.pid + "=0",
					new String[] { String.valueOf(channelId),
							String.valueOf(aTitle.id) });
			if (num == 0) {
				mResolver.insert(DBHelper.news, null, values);
			}
			// mResolver.update(DBHelper.news, values, DBHelper.channelid +
			// "=? and " + DBHelper.serviceId
			// + "=? and " + DBHelper.pid + "=0", new String[] {
			// String.valueOf(channelId),
			// String.valueOf(aTitle.id)});

		}
		mResolver.close();
		if (artList.size() != number) {
			// 未加载到20条说明在最后一页了
			downOver = true;
		}
	}

	public void getSearchNetData(String sessionId, int channelId)
			throws Exception {
		searchChannelCurPage++;
		StringBuilder sb = new StringBuilder();
		ArrayList<ArticleTitle> artList = Method.searchArticleList(sessionId,
				"" + searchChannelCurPage, "" + number, "" + channelId,
				titleSearch, sb);
		if (artList == null) {
			Message msg = new Message();
			msg.what = 8;
			msg.obj = sb.toString();
			handler.sendMessage(msg);
			searchChannelCurPage--;
			return;
		}
		artList.remove(artList.size() - 1);
		SQLiteDatabase mResolver = DBHelper.getSQLite(getApplicationContext());
		for (int index = 0; index < artList.size(); index++) {
			ArticleTitle aTitle = artList.get(index);
			ContentValues values = new ContentValues(6);
			values.put(DBHelper.serviceId, aTitle.id);
			values.put(DBHelper.title, aTitle.title);
			values.put(DBHelper.imgurl, aTitle.titleImg);
			values.put(DBHelper.thetime, aTitle.showTime);
			values.put(DBHelper.channelid, channelId);
			values.put(DBHelper.pid, 0);
			// mResolver.delete(
			// DBHelper.news,
			// DBHelper.channelid + "=? and " + DBHelper.serviceId
			// + "=? and " + DBHelper.pid + "=0",
			// new String[] { String.valueOf(channelId),
			// String.valueOf(aTitle.id) });
			// mResolver.insert(DBHelper.news, null, values);

			int num = mResolver.update(
					DBHelper.news,
					values,
					DBHelper.channelid + "=? and " + DBHelper.serviceId
							+ "=? and " + DBHelper.pid + "=0",
					new String[] { String.valueOf(channelId),
							String.valueOf(aTitle.id) });
			if (num == 0) {
				mResolver.insert(DBHelper.news, null, values);
			}

		}
		mResolver.close();
		if (artList.size() != number) {
			// 未加载到20条说明在最后一页了
			downOverSearch = true;
		}
	}

	public void readDataToUIOffLine() {
		page++;
		SQLiteDatabase sqlite = DBHelper.getReadSQLite(getApplicationContext());
		Cursor cursor = sqlite.query(DBHelper.news, queryItem,
				DBHelper.channelid + "=? and " + DBHelper.pid + "=0",
				new String[] { String.valueOf(channelId) }, null, null,
				DBHelper.data1, "0," + page * number);
		list = new ArrayList<News>();
		list.add(new News());
		if (cursor != null) {
			while (cursor.moveToNext()) {
				News newItem = new News();
				newItem.serviceId = cursor.getInt(0);
				newItem.title = cursor.getString(1);
				newItem.contentPart = cursor.getString(2);
				newItem.theTime = cursor.getString(3);
				newItem.theimgIcon = cursor.getString(4);
				newItem.imgurl = cursor.getString(5);
				list.add(newItem);
			}
			cursor.close();
		}
		sqlite.close();
	}

	public void readSearchDataToUIOffLine() {
		pageSearch++;
		SQLiteDatabase sqlite = DBHelper.getReadSQLite(getApplicationContext());
		Cursor cursor = sqlite.query(DBHelper.news, queryItem,
				DBHelper.channelid + "=? and " + DBHelper.pid + "=0 and "
						+ DBHelper.title + " like ?",
				new String[] { String.valueOf(channelId),
						"%" + titleSearch + "%" }, null, null, DBHelper.data1,
				"0," + pageSearch * number);
		searchList = new ArrayList<News>();
		searchList.add(new News());
		if (cursor != null) {
			while (cursor.moveToNext()) {
				News newItem = new News();
				newItem.serviceId = cursor.getInt(0);
				newItem.title = cursor.getString(1);
				newItem.contentPart = cursor.getString(2);
				newItem.theTime = cursor.getString(3);
				newItem.theimgIcon = cursor.getString(4);
				newItem.imgurl = cursor.getString(5);
				searchList.add(newItem);
			}
			cursor.close();
		}
		sqlite.close();
	}

	public void readSearchDataToUILine() {
		SQLiteDatabase sqlite = DBHelper.getReadSQLite(getApplicationContext());
		Cursor cursor = sqlite.query(DBHelper.news, queryItem,
				DBHelper.channelid + "=? and " + DBHelper.pid + "=0 and "
						+ DBHelper.title + " like ?",
				new String[] { String.valueOf(channelId),
						"%" + titleSearch + "%" }, null, null, null, null);
		searchList = new ArrayList<News>();
		searchList.add(new News());
		if (cursor != null) {
			while (cursor.moveToNext()) {
				News newItem = new News();
				newItem.serviceId = cursor.getInt(0);
				newItem.title = cursor.getString(1);
				newItem.contentPart = cursor.getString(2);
				newItem.theTime = cursor.getString(3);
				newItem.theimgIcon = cursor.getString(4);
				newItem.imgurl = cursor.getString(5);
				searchList.add(newItem);
			}
			cursor.close();
		}
		sqlite.close();
	}

	public void readDataToUILine() {
		SQLiteDatabase sqlite = DBHelper.getReadSQLite(getApplicationContext());
		Cursor cursor = sqlite.query(DBHelper.news, queryItem,
				DBHelper.channelid + "=? and " + DBHelper.pid + "=0",
				new String[] { String.valueOf(channelId) }, null, null, null,
				null);
		list = new ArrayList<News>();
		list.add(new News());
		if (cursor != null) {
			while (cursor.moveToNext()) {
				News newItem = new News();
				newItem.serviceId = cursor.getInt(0);
				newItem.title = cursor.getString(1);
				newItem.contentPart = cursor.getString(2);
				newItem.theTime = cursor.getString(3);
				newItem.theimgIcon = cursor.getString(4);
				newItem.imgurl = cursor.getString(5);
				list.add(newItem);
			}
			cursor.close();
		}
		sqlite.close();
	}

	@SuppressWarnings("unused")
	private class NewsAdapter extends BaseAdapter {

		private Context mContext;

		private ArrayList<News> mList;

		public NewsAdapter(Context context, ArrayList<News> list) {
			mContext = context;
			mList = list;
		}

		public NewsAdapter(Context context) {
			mContext = context;
		}

		public void setDataList(ArrayList<News> mList) {
			this.mList = mList;
			notifyDataSetChanged();
		}

		public ArrayList<News> getDataList() {
			return mList;
		}

		public int getCount() {
			return mList == null ? 0 : mList.size();
		}

		public Object getItem(int position) {
			return mList.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			LinearLayout layout;
			if (position == 0) {
				final LayoutInflater mInflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				layout = (LinearLayout) mInflater.inflate(R.layout.main_image,
						parent, false);
				ImageView logoImage = new ImageView(mContext);
				// 0.195
				logoImage
						.setLayoutParams(new LayoutParams(
								LayoutParams.FILL_PARENT,
								(int) (0.195 * screenHeight)));
				logoImage.setScaleType(ImageView.ScaleType.FIT_XY);
				logoImage.setImageResource(R.drawable.logo);
				layout.addView(logoImage);
			} else {
				News curNews = mList.get(position);
				final LayoutInflater mInflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				layout = (LinearLayout) mInflater.inflate(R.layout.main_news,
						parent, false);
				TextView title = (TextView) layout.findViewById(R.id.title);
				title.setText(curNews.title);
				TextView contentPart = (TextView) layout
						.findViewById(R.id.contentPart);
				contentPart.setText(curNews.contentPart);
				TextView time = (TextView) layout.findViewById(R.id.time);
				time.setText(curNews.theTime);
				ImageView theImg = (ImageView) layout.findViewById(R.id.theImg);
				File fileIcon = new File(save_path + File.separator + channelId
						+ "_" + DBHelper.news + "_icon_" + curNews.serviceId
						+ ".png");
				if (fileIcon.isFile() && fileIcon.exists()) {
					Bitmap bm = BitmapFactory.decodeFile(fileIcon
							.getAbsolutePath());
					if (bm != null && bm.getWidth() != 0) {
						theImg.setImageBitmap(bm);
						bm = null;
					} else {
						if (MainActivity.canDownImage) {
							imageDown.download(curNews.imgurl, theImg,
									curNews.serviceId, channelId);
						}
					}
				} else {
					if (MainActivity.canDownImage) {
						imageDown.download(curNews.imgurl, theImg,
								curNews.serviceId, channelId);
					}
				}
				// if (canDownImage) {
				// // ########
				// // if (!cacheImage.loadCachedPhoto(theImg, item.id)) {
				// File fileIcon = new File(save_path + File.separator
				// + channelId + "_" + DBHelper.news + "_icon_"
				// + curNews.serviceId + ".png");
				// if (fileIcon.isFile() && fileIcon.exists()
				// ) {
				// Log.i("data1", "local " + fileIcon.getAbsolutePath());
				// Bitmap bm = BitmapFactory.decodeFile(fileIcon
				// .getAbsolutePath());
				// if (bm == null || bm.getWidth() == 0) {
				// // cacheImage.fail(curNews.serviceId);
				// cacheImage.loadImage(theImg, curNews.serviceId
				// ,channelId,curNews.imgurl);
				// } else {
				// Log.i("data1", "local " + curNews.serviceId);
				// theImg.setImageBitmap(bm);
				// // ########
				// // cacheImage.cacheBitmap(item.id, bm);
				// // cacheImage.loadCachedPhoto(theImg, item.id);
				// bm = null;
				// }
				// } else {
				// cacheImage.loadImage(theImg, curNews.serviceId
				// ,channelId,curNews.imgurl);
				// }
				// // ########
				// // }
				// } else {
				// File fileIcon = new File(save_path + File.separator
				// + channelId + "_" + DBHelper.news + "_icon_"
				// + curNews.serviceId + ".png");
				// if (fileIcon.isFile() && fileIcon.exists()
				// ) {
				// Log.i("data1", "local " + fileIcon.getAbsolutePath());
				// Bitmap bm = BitmapFactory.decodeFile(fileIcon
				// .getAbsolutePath());
				// if (bm != null && bm.getWidth() != 0) {
				// theImg.setImageBitmap(bm);
				// bm = null;
				// } else {
				// theImg.setBackgroundResource(R.drawable.no_image);
				// }
				// } else {
				// theImg.setBackgroundResource(R.drawable.no_image);
				// }
				// }
			}
			return layout;
		}
	}

	@SuppressWarnings("unused")
	private class SearchNewsAdapter extends BaseAdapter {

		private Context mContext;

		private ArrayList<News> mList;

		public SearchNewsAdapter(Context context, ArrayList<News> list) {
			mContext = context;
			mList = list;
		}

		public SearchNewsAdapter(Context context) {
			mContext = context;
		}

		public void setDataList(ArrayList<News> mList) {
			this.mList = mList;
			notifyDataSetChanged();
		}

		public ArrayList<News> getDataList() {
			return mList;
		}

		public int getCount() {
			return mList == null ? 0 : mList.size();
		}

		public Object getItem(int position) {
			return mList.get(position);
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			LinearLayout layout;
			if (position == 0) {
				final LayoutInflater mInflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				layout = (LinearLayout) mInflater.inflate(R.layout.main_image,
						parent, false);
				ImageView logoImage = new ImageView(mContext);
				// 0.195
				logoImage
						.setLayoutParams(new LayoutParams(
								LayoutParams.FILL_PARENT,
								(int) (0.195 * screenHeight)));
				logoImage.setScaleType(ImageView.ScaleType.FIT_XY);
				logoImage.setImageResource(R.drawable.logo);
				layout.addView(logoImage);
			} else {
				News curNews = mList.get(position);
				final LayoutInflater mInflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				layout = (LinearLayout) mInflater.inflate(R.layout.main_news,
						parent, false);
				TextView title = (TextView) layout.findViewById(R.id.title);
				title.setText(curNews.title);
				TextView contentPart = (TextView) layout
						.findViewById(R.id.contentPart);
				contentPart.setText(curNews.contentPart);
				TextView time = (TextView) layout.findViewById(R.id.time);
				time.setText(curNews.theTime);
				ImageView theImg = (ImageView) layout.findViewById(R.id.theImg);
				File fileIcon = new File(save_path + File.separator + channelId
						+ "_" + DBHelper.news + "_icon_" + curNews.serviceId
						+ ".png");
				if (fileIcon.isFile() && fileIcon.exists()) {
					Bitmap bm = BitmapFactory.decodeFile(fileIcon
							.getAbsolutePath());
					if (bm != null && bm.getWidth() != 0) {
						theImg.setImageBitmap(bm);
						bm = null;
					} else {
						if (MainActivity.canDownImage) {
							imageDown.download(curNews.imgurl, theImg,
									curNews.serviceId, channelId);
						}
					}
				} else {
					if (MainActivity.canDownImage) {
						imageDown.download(curNews.imgurl, theImg,
								curNews.serviceId, channelId);
					}
				}
				// if (canDownImage) {
				// // ########
				// // if (!cacheImage.loadCachedPhoto(theImg, item.id)) {
				// File fileIcon = new File(save_path + File.separator
				// + channelId + "_" + DBHelper.news + "_icon_"
				// + curNews.serviceId + ".png");
				// if (fileIcon.isFile() && fileIcon.exists()) {
				// Log.i("data1", "local " + fileIcon.getAbsolutePath());
				// Bitmap bm = BitmapFactory.decodeFile(fileIcon
				// .getAbsolutePath());
				// if (bm == null || bm.getWidth() == 0) {
				// // cacheImage.fail(curNews.serviceId);
				// fileIcon.delete();
				// cacheImage.loadImage(theImg,
				// curNews.serviceId,channelId,curNews.imgurl);
				// } else {
				// Log.i("data1", "local " + curNews.serviceId);
				// theImg.setImageBitmap(bm);
				// // ########
				// // cacheImage.cacheBitmap(item.id, bm);
				// // cacheImage.loadCachedPhoto(theImg, item.id);
				// bm = null;
				// }
				// } else {
				// cacheImage.loadImage(theImg,
				// curNews.serviceId,channelId,curNews.imgurl);
				// }
				// // ########
				// // }
				// } else {
				// File fileIcon = new File(save_path + File.separator
				// + channelId + "_" + DBHelper.news + "_icon_"
				// + curNews.serviceId + ".png");
				// if (fileIcon.isFile() && fileIcon.exists()) {
				// Log.i("data1", "local " + fileIcon.getAbsolutePath());
				// Bitmap bm = BitmapFactory.decodeFile(fileIcon
				// .getAbsolutePath());
				// if (bm != null && bm.getWidth() != 0) {
				// theImg.setImageBitmap(bm);
				// bm = null;
				// } else {
				// theImg.setBackgroundResource(R.drawable.no_image);
				// }
				// } else {
				// theImg.setBackgroundResource(R.drawable.no_image);
				// }
				// }
			}
			return layout;
		}
	}

	public void hideFoot() {
		pullListView.getFootView().setVisibility(View.GONE);
	}

	public void hideSearchFoot() {
		searchListView.getFootView().setVisibility(View.GONE);
	}

	private void setListView() {
		hideFoot();
		pullListView.setonRefreshListener(new PullListView.OnRefreshListener() {
			public void onRefresh() {
				synchronized (obj) {
					if (down) {
						down = false;
						new Thread(new Runnable() {
							@Override
							public void run() {
								if (canNet) {
									int tmp = channelCurPage;
									try {
										getFirstNetData(sessionId, channelId);
										readDataToUILine();
									} catch (Exception e) {
										channelCurPage = tmp;
										readDataToUIOffLine();
									}
								} else {
									try {
										Thread.sleep(500);
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
									readDataToUIOffLine();
								}
								handler.sendEmptyMessage(0);
							}
						}).start();
					}
				}
			}
		});
		pullListView.setOnScrollListener(new OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
						&& (view.getLastVisiblePosition() + 1 == view
								.getCount())) {
					synchronized (obj) {
						if (down && !downOver) {
							down = false;
							pullListView.getFootView().setVisibility(
									View.VISIBLE);
							new Thread(new Runnable() {
								@Override
								public void run() {
									try {
										downData();
										handler.sendEmptyMessage(1);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}).start();
						}
					}
				}
				if (scrollState == OnScrollListener.SCROLL_STATE_FLING) {
					cacheImage.pause();
				} else {
					cacheImage.resume();
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				pullListView.fix(firstVisibleItem);
			}
		});

		pullListView.setOnItemClickListener(new PullListClick());
	}

	private void setSearchListView() {
		hideSearchFoot();
		searchListView
				.setonRefreshListener(new PullListView.OnRefreshListener() {
					public void onRefresh() {
						synchronized (searchObj) {
							if (searchDown) {
								searchDown = false;
								new Thread(new Runnable() {
									@Override
									public void run() {
										if (canNet) {
											int tmp = searchChannelCurPage;
											try {
												getSearchFirstNetData(
														sessionId, channelId);
												readSearchDataToUILine();
											} catch (Exception e) {
												searchChannelCurPage = tmp;
												readSearchDataToUIOffLine();
											}
										} else {
											try {
												Thread.sleep(500);
											} catch (InterruptedException e) {
												e.printStackTrace();
											}
											readSearchDataToUIOffLine();
										}
										handler.sendEmptyMessage(5);
									}
								}).start();
							}
						}
					}
				});
		searchListView.setOnScrollListener(new OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				if (scrollState == OnScrollListener.SCROLL_STATE_IDLE
						&& (view.getLastVisiblePosition() + 1 == view
								.getCount())) {
					synchronized (searchObj) {
						if (searchDown && !downOverSearch) {
							searchDown = false;
							searchListView.getFootView().setVisibility(
									View.VISIBLE);
							new Thread(new Runnable() {
								@Override
								public void run() {
									try {
										downSearchData();
										handler.sendEmptyMessage(6);
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
							}).start();
						}
					}
				}
				if (scrollState == OnScrollListener.SCROLL_STATE_FLING) {
					cacheImage.pause();
				} else {
					cacheImage.resume();
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				searchListView.fix(firstVisibleItem);
			}
		});

		searchListView.setOnItemClickListener(new SearchListClick());
	}

	public void aboutFile() {
		if (!Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED)) {
			save_path = this.getFilesDir().getAbsolutePath() + File.separator
					+ "cdc_news_image";
			save_path_wifi = this.getFilesDir().getAbsolutePath()
					+ File.separator + "cdc_news_image_wifi";
		}
		File saveFile = new File(save_path);
		if (!saveFile.isDirectory()) {
			if (!saveFile.mkdirs()) {
				aboutSDCard = false;
			}
		}
		File saveFile2 = new File(save_path_wifi);
		if (!saveFile2.isDirectory()) {
			if (!saveFile2.mkdirs()) {
				aboutSDCard = false;
			}
		}
	}

	public void downData() {
		if (canNet) {
			try {
				getNetData(sessionId, channelId);
				readDataToUILine();
			} catch (Exception e) {
				e.printStackTrace();
				channelCurPage--;
				readDataToUIOffLine();
			}
		} else {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			readDataToUIOffLine();
		}
	}

	public void downSearchData() {
		if (canNet) {
			try {
				getSearchNetData(sessionId, channelId);
				readSearchDataToUILine();
			} catch (Exception e) {
				e.printStackTrace();
				searchChannelCurPage--;
				readSearchDataToUIOffLine();
			}
		} else {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			readSearchDataToUIOffLine();
		}
	}

	// public boolean aboutImage(int id) {
	// SQLiteDatabase sqlite = DBHelper.getReadSQLite(getApplicationContext());
	// Cursor cursor = sqlite.query(DBHelper.news,
	// new String[] { DBHelper.serviceId }, DBHelper.serviceId
	// + " = ? and " + DBHelper.status + " = ?", new String[] {
	// String.valueOf(id), String.valueOf(100) }, null, null,
	// null, null);
	// boolean e = cursor != null && cursor.getCount() > 0;
	// if (cursor != null) {
	// cursor.close();
	// }
	// sqlite.close();
	// return e;
	// }

	final static String refresh = "com.cdc.android.app.news.refresh";

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		theReceiver = new TheReceiver();
		registerReceiver(theReceiver, new IntentFilter(refresh));
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		canDownImage = netImage(this);
		cacheImage.resume();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		cacheImage.stop();
	}

	public static boolean offLine(Context mContext) {
		int state = HttpHelper.isNetworkConnected(mContext);
		if (state == HttpHelper.isDisConn) {
			return false;
		}
		SharedPreferences settings = mContext.getSharedPreferences(
				SetActivity.data, MODE_PRIVATE);
		boolean wifidown = settings.getBoolean(SetActivity.wifidown, false);
		return state != HttpHelper.is2g && wifidown && aboutSDCard;
	}

	public static boolean netImage(Context mContext) {
		int state = HttpHelper.isNetworkConnected(mContext);
		if (state == HttpHelper.isDisConn) {
			return false;
		}
		if (state == HttpHelper.is3gWifi) {
			return true && aboutSDCard;
		}
		SharedPreferences settings = mContext.getSharedPreferences(
				SetActivity.data, MODE_PRIVATE);
		boolean net2gdownValue = settings.getBoolean(SetActivity.net2gdown,
				false);
		return state == HttpHelper.is2g && !net2gdownValue && aboutSDCard;
	}

	public static boolean net(Context mContext) {
		int state = HttpHelper.isNetworkConnected(mContext);
		if (state == HttpHelper.isDisConn) {
			return false;
		}
		return true;
	}

	// @Override
	// public boolean onKeyDown(int keyCode, KeyEvent event) {
	// if (keyCode == KeyEvent.KEYCODE_BACK) {
	// if (mainSearchLayout.getVisibility() == View.VISIBLE) {
	// mainHeadLayout.setVisibility(View.VISIBLE);
	// mainSearchLayout.setVisibility(View.GONE);
	// searchTitle.setText("");
	// } else {
	// finish();
	// }
	// return true;
	// }
	// return super.onKeyDown(keyCode, event);
	// }
}
