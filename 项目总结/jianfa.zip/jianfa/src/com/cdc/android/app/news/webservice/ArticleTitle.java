package com.cdc.android.app.news.webservice;
/**
 * @author 刘泉兴 <br />
 * @version 1.0 <br />
 * @email spring9501@163.com <br />
 */
public class ArticleTitle {
	public int id;
	public String title;
	public Object descript;
	public String showTime;
	public String titleImg;
	public int total;
}
