/**
 * 
 */
package com.suncco.chinacdc.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.utils.LogUtil;

/**
 * @author 陈俊金
 * @date 2012-6-28 下午2:25:16
 */
public class ViewPagerIndicator extends View {

	private Bitmap mPageTag;
	private float mUnitSpace;
	private float mStartPosition;
	private int mSeletedItemId = 0;
	private int mTextSize;
	private int mPagerCount = 5;

	public ViewPagerIndicator(Context context, AttributeSet attrs) {
		super(context, attrs);

		TypedArray a = context.obtainStyledAttributes(attrs,
				R.styleable.ViewPagerTitleIndicator);
		mPageTag = ((BitmapDrawable) a
				.getDrawable(R.styleable.ViewPagerTitleIndicator_text_seleted_tag))
				.getBitmap();
		mTextSize = (int) a.getDimension(
				R.styleable.ViewPagerTitleIndicator_text_size, 14);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		Paint paint = new Paint();
		paint.setAntiAlias(true);
		paint.setTextSize(mTextSize);
		float textWidth = paint.measureText((mSeletedItemId + 1) + "");
		LogUtil.i(mStartPosition + ",  " + mUnitSpace);
		canvas.drawBitmap(mPageTag, mStartPosition + (mUnitSpace * 2)
				* mSeletedItemId - mPageTag.getWidth() / 2, getHeight()
				- mPageTag.getHeight(), paint);

		float x = mStartPosition + (mUnitSpace * 2) * mSeletedItemId
				- textWidth / 2;
		float y = getHeight() / 2 + paint.getTextSize() / 3;

		canvas.drawText(mSeletedItemId + 1 + "", x, y, paint);
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		setMeasuredDimension(measureWidth(widthMeasureSpec),
				measureHeight(heightMeasureSpec));
	}

	private int measureWidth(int measureSpec) {
		int result = 0;
		int specMode = MeasureSpec.getMode(measureSpec);
		int specSize = MeasureSpec.getSize(measureSpec);

		if (specMode == MeasureSpec.EXACTLY) {
			result = specSize;
		} else {
			result = (int) (getPaddingLeft() + getPaddingRight());
			if (specMode == MeasureSpec.AT_MOST) {
				result = Math.min(result, specSize);
			}
		}
		return result;
	}

	public void setPageCount(int count) {
		this.mPagerCount = count;
		mStartPosition = mUnitSpace = BaseApp.sScreenWidth
				/ (float) (mPagerCount * 2);
		invalidate();
	}

	public void onSroll(int pageId, float x) {
		this.mStartPosition = mUnitSpace + mUnitSpace * 2 * x;
		mSeletedItemId = pageId;
		invalidate();
	}

	private int measureHeight(int measureSpec) {
		int result = 0;
		int specMode = MeasureSpec.getMode(measureSpec);
		int specSize = MeasureSpec.getSize(measureSpec);
		if (specMode == MeasureSpec.EXACTLY) {
			result = specSize;
		} else {
			if (mPageTag != null) {
				result = getPaddingTop() + getPaddingBottom()
						+ mPageTag.getHeight();
			} else {
				result = getPaddingBottom() + getPaddingTop();
			}
		}
		return result;
	}

}
