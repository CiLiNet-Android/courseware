package com.suncco.chinacdc.subscription;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.R;

public class SubscriptionActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.subscription_activity);
		prepareView();
	}

	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		ListView listView = (ListView) findViewById(R.id.subscription_list);
		listView.setAdapter(new SubscriptionAdapter(this));
		listView.setOnItemClickListener(this);
	}

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		Intent intent = new Intent(this, SubDetailActivity.class);
		intent.putExtra("type", position);
		startActivity(intent);
	}
}
