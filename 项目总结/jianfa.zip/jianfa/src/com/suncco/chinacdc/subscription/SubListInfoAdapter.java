package com.suncco.chinacdc.subscription;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ChannelBean;
import com.suncco.chinacdc.bean.ChannelListBean;

public class SubListInfoAdapter extends BaseAdapter {

	private Context mContext;
	private ChannelListBean mChannelListBean;

	public SubListInfoAdapter(Context context, ChannelListBean bean) {
		this.mContext = context;
		this.mChannelListBean = bean;
	}

	public int getCount() {
		return mChannelListBean == null ? 0 : mChannelListBean.mChannelBeans
				.size();
	}

	public ChannelBean getItem(int position) {
		return mChannelListBean.mChannelBeans.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		ImageView icon;
		TextView title;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.sub_detail_list_item, null);
			holder = new ViewHolder();
			holder.icon = (ImageView) convertView
					.findViewById(R.id.sub_detail_tag);
			holder.title = (TextView) convertView
					.findViewById(R.id.sub_detail_name);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		ChannelBean bean = getItem(position);
		holder.title.setText(bean.name);
		if(bean.isSubscribe){
			holder.icon.setImageResource(R.drawable.icon_uncheck);
		}else{
			if(bean.isOrder){
				holder.icon.setImageResource(R.drawable.icon_check_blue);
			}else{
				holder.icon.setImageResource(R.drawable.icon_plus);
			}
			
		}
		
		return convertView;
	}
}
