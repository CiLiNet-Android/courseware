package com.suncco.chinacdc.subscription;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ChannelBean;
import com.suncco.chinacdc.bean.ChannelListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.MagazineBean;
import com.suncco.chinacdc.bean.MagazineListBean;
import com.suncco.chinacdc.information.ArticleImgListActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.XListView;
import com.suncco.chinacdc.widget.XListView.IXListViewListener;

public class SubDetailActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener, IXListViewListener {
	
	private static final int HANDLER_CHANNEL_WHAT = 100;
	private static final int HANDLER_MAGAZINE_WHAT = 101;
	
	TextView mTitle;
	int type = 0;
	ChannelListBean mChannelListBean;
	MagazineListBean mMagazineListBean;
	SubListInfoAdapter mSubListInfoAdapter;
	SubListMagazineAdapter mSubListMagazineAdapter;
	private LoadingProgressDialog mProgress;
	
	private XListView mXListView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.subscribe_detail_activity);
		prepareView();
		initData();
	}


	private void prepareView() {
		mProgress  = new LoadingProgressDialog(this);
		findViewById(R.id.title_but1).setOnClickListener(this);
		mTitle = (TextView) findViewById(R.id.title_text);
		mXListView = (XListView) findViewById(R.id.subscribe_list);
		mXListView.setXListViewListener(this);
		mXListView.setPullLoadEnable(false);
		mXListView.setPullRefreshEnable(true);
		mXListView.setOnItemClickListener(this);
	}
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_CHANNEL_WHAT) {
				mProgress.dismiss();
				ChannelListBean bean = (ChannelListBean) msg.obj;
				if (bean != null) {
					if (bean.code == 0) {
						mChannelListBean =  ChannelListBean.getSubChannelList(bean);
						ChannelListBean.saveSub(mChannelListBean);
						setListInfoView();
					} else {
						BaseApp.showSessionnDialog(SubDetailActivity.this, bean);
//						BaseApp.showToast(bean.message);
					}
				} else {
					BaseApp.showToast(R.string.app_net_exc);
				}
				hasNextPage();
			} else if (msg.what == HANDLER_MAGAZINE_WHAT) {
				mProgress.dismiss();
				MagazineListBean bean = (MagazineListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_load_exc);
				} else {
					if (bean.code == 0) {
						mMagazineListBean = MagazineListBean.getSubMagazingList(bean);
						MagazineListBean.saveSub(mMagazineListBean);
						setListMagazingView();
					} else {
						BaseApp.showSessionnDialog(SubDetailActivity.this, bean);
//						BaseApp.showToast(bean.message);
					}
				}
				hasNextPage();
			}
		};
	};
	
	private void initData() {
		type = getIntent().getIntExtra("type", 0);
		switch(type){
		case 0:
			mTitle.setText("资讯中心");
			getChannelList();
			break;
		case 1:
			mTitle.setText("杂志期刊");
			getMagazineList();
			break;
		default:break;
		
		}
	}
	
	

	public void onClick(View v) {
		if (v.getId() == R.id.title_but1) {
			finish();
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		position --;
		switch(type){
		case 0:
			ChannelBean bean = mChannelListBean.mChannelBeans.get(position);
			if(bean.isSubscribe)return;
			bean.isOrder = !bean.isOrder;
			ChannelListBean.saveSub(mChannelListBean);
			mSubListInfoAdapter.notifyDataSetChanged();
			break;
		case 1:
			MagazineBean bean2 = mMagazineListBean.mMagazineBeans.get(position);
			if(bean2.isSubscribe)return;
			bean2.isOrder = !bean2.isOrder;
			MagazineListBean.saveSub(mMagazineListBean);
			mSubListMagazineAdapter.notifyDataSetChanged();
			break;
		default:break;
		}
	}
	
	private void getChannelList() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		new ChinacdcThread(ChannelListBean.class, utils.formatParams(),
				mHandler, HANDLER_CHANNEL_WHAT).start();
		mProgress.show();
	}
	
	private void getMagazineList() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		mProgress.show();
		new ChinacdcThread(MagazineListBean.class, utils.formatParams(),
				mHandler, HANDLER_MAGAZINE_WHAT).start();

	}
	
	private void setListInfoView(){
		mSubListInfoAdapter = new SubListInfoAdapter(this, mChannelListBean);
		mXListView.setAdapter(mSubListInfoAdapter);
	}

	private void setListMagazingView(){
		mSubListMagazineAdapter = new SubListMagazineAdapter(this, mMagazineListBean);
		mXListView.setAdapter(mSubListMagazineAdapter);
	}
	
	private void hasNextPage() {
		mXListView.stopRefresh();
		mXListView.stopLoadMore();
		switch(type){
		case 0:
			break;
		case 1:
			break;
		default:break;
		}
	}

	@Override
	public void onRefresh() {
		switch(type){
		case 0:
			getChannelList();
			break;
		case 1:
			getMagazineList();
			break;
		default:getChannelList();
		break;
		
		}
	}


	@Override
	public void onLoadMore() {
		
	}
	
}
