package com.suncco.chinacdc.subscription;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.suncco.chinacdc.R;

public class SubscriptionAdapter extends BaseAdapter {

	private Context mContext;

	public SubscriptionAdapter(Context context) {
		this.mContext = context;
	}

	public int getCount() {
		// TODO Auto-generated method stub
		return 2;
	}

	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		TextView title;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.subscription_item, null);
			holder.title = (TextView) convertView
					.findViewById(R.id.subscription_title);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		if (position == 0) {
			holder.title.setText("资讯中心");
		} else {
			holder.title.setText("杂志期刊");
		}
		return convertView;
	}

}
