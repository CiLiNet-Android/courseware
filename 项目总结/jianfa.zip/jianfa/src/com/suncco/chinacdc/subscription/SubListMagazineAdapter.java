package com.suncco.chinacdc.subscription;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.MagazineBean;
import com.suncco.chinacdc.bean.MagazineListBean;

public class SubListMagazineAdapter extends BaseAdapter {

	private Context mContext;
	private MagazineListBean mMagazineListBean;

	public SubListMagazineAdapter(Context context, MagazineListBean bean) {
		this.mContext = context;
		this.mMagazineListBean = bean;
	}

	public int getCount() {
		return mMagazineListBean == null ? 0 : mMagazineListBean.mMagazineBeans
				.size();
	}

	public MagazineBean getItem(int arg0) {
		return mMagazineListBean.mMagazineBeans.get(arg0);
	}

	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		ImageView icon;
		TextView name;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.sub_detail_list_item, null);
			holder = new ViewHolder();
			holder.icon = (ImageView) convertView
					.findViewById(R.id.sub_detail_tag);
			holder.name = (TextView) convertView
					.findViewById(R.id.sub_detail_name);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		MagazineBean bean = getItem(position);
		holder.name.setText(bean.name);
		if(bean.isSubscribe){
			holder.icon.setImageResource(R.drawable.icon_uncheck);
		}else{
			if(bean.isOrder){
				holder.icon.setImageResource(R.drawable.icon_check_blue);
			}else{
				holder.icon.setImageResource(R.drawable.icon_plus);
			}
			
		}
		
		return convertView;
	}
}
