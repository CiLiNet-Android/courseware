package com.suncco.chinacdc.downloader;

import java.io.File;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import android.os.Handler;
import android.widget.RatingBar;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.bean.BaseBean;
import com.suncco.chinacdc.bean.DownloadBean;
import com.suncco.chinacdc.bean.DownloadListBean;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebResourceUtils;

/**
 * 一次下载中间件， 用于获取下载对象的文件大小等信息，实际发起下载的类
 * 
 * @author 陈俊金
 * @date 2012-7-23 下午6:00:50
 */
public class FileDownloader extends BaseBean implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 6209403450856015705L;

	/**
	 * 下载中
	 */
	static final int DOWNLOAD_RUNNING = 0;

	/**
	 * 下载失败
	 */
	static final int DOWNLOAD_FAILED = -1;

	/**
	 * 下载完成
	 */
	static final int DOWNLOAD_SUCCEED = 1;

	/**
	 * 下载暂停
	 */
	static final int DOWNLOAD_PAUSE = 2;

	private DownloadBean mDownloadBean;

	private DownloadTask mDownloadTask;

	private boolean mIsCancel = false;

	private RatingBar ratingBar;

	Handler handler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			ratingBar.setRating(mDownloadBean.getProgress());
		};
	};
	
	public boolean isCancel(){
		return mIsCancel;
	}

	public DownloadBean getDownloadBean() {
		return mDownloadBean;
	}

	public void regiestProgressBar(RatingBar bar) {
		this.ratingBar = bar;
	}

	public RatingBar getProgressBar() {
		return ratingBar;
	}

	public void updateDownloadedSize(int size) {
		mDownloadBean.updateDownloadedSize(size);
		if (ratingBar != null) {
//			LogUtil.i(mDownloadBean.getProgress() + "");
			ratingBar.setRating(mDownloadBean.getProgress());
		}
	}

	public void cancel() {
		if (mDownloadTask != null) {
			mDownloadTask.cancel();
		}
		mIsCancel = true;
	}

	/**
	 * 根据URL 获取服务器文件信息 需要在子线程线程中执行
	 * 
	 * @param downloadUrl
	 *            下载地址
	 * @param bean
	 *            下载记录
	 */
	public FileDownloader(DownloadBean bean) {
		this.mDownloadBean = bean;
		mDownloadBean.initDownloadedSize();
	}

	public void getFileMessage() throws DownloadException {
		if (mIsCancel) {
			return;
		}
		try {
			String urlStr = mDownloadBean.url;
			LogUtil.i("FileDownloader", urlStr);
			URL url = new URL(urlStr);
			File fileSaveDir = new File(Constans.DOWNLOAD_DIR);
			if (!fileSaveDir.exists()) {
				fileSaveDir.mkdirs();
			}
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("Referer", urlStr);
			HttpURLConnection conn = WebResourceUtils.getHttpURLConnection(url,
					WebResourceUtils.GET, map);
			conn.connect();

			if (conn.getResponseCode() == 200) {
				long fileSize = conn.getContentLength();// 根据响应获取文件大小
				LogUtil.i("文件大小 :" + fileSize);
				if (fileSize <= 0) {
					throw new RuntimeException("Unkown file size ");
				} else {
					mDownloadBean.fileSize = fileSize;
				}
				DownloadListBean.save();
			} else {
				throw new RuntimeException("server no response ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new DownloadException("");
		}
	}

	/**
	 * 开始下载文件
	 * 
	 * @param listener
	 * 
	 * @throws DownloadException
	 */
	public void download(DownloadedListener listener) throws DownloadException {
		try {
			mDownloadTask = new DownloadTask(this, listener);
			mDownloadTask.run();
			LogUtil.i("start");
		} catch (Exception e) {
			e.printStackTrace();
			throw new DownloadException("file download fail");
		}
	}
}
