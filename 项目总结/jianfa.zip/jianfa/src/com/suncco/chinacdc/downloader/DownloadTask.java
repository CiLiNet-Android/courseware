package com.suncco.chinacdc.downloader;

import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.bean.DownloadBean;
import com.suncco.chinacdc.bean.DownloadListBean;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.SystemParamsUtils;
import com.suncco.chinacdc.utils.WebResourceUtils;

/**
 * 下载线程类
 * 
 * 
 * @date 2012-7-23 下午5:58:46
 */
public class DownloadTask {

	static final int LOAD_BUF_SIZE = 102400;
	private DownloadedListener mDownloadedListener;
	private boolean mIsCancel = false;
	private DownloadBean mDownloadBean;
	private FileDownloader mFileDownloader;

	public DownloadTask(FileDownloader fileDownloader,
			DownloadedListener listener) {
		this.mFileDownloader = fileDownloader;
		this.mDownloadBean = mFileDownloader.getDownloadBean();
		this.mDownloadedListener = listener;
	}

	// 停止线程
	public void cancel() {
		mIsCancel = true;
	}

	public void run() {
		if (!mDownloadBean.isFinish()) {
			try {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("Referer", mDownloadBean.url);
				File file = new File(Constans.DOWNLOAD_DIR + mDownloadBean.name
						+ ".zip");
				if(file != null && file.exists()){
					file.delete();
					file = new File(Constans.DOWNLOAD_DIR + mDownloadBean.name
							+ ".zip");
				}
				long startPos = mDownloadBean.getLoadedFileSize();
				double endPos = mDownloadBean.fileSize;
				if (startPos == 0) {
					map.put("Range", "bytes=" + startPos + "-");
				} else {
					map.put("Range", "bytes=" + startPos + "-" + endPos);
				}
				LogUtil.i("start position : " + startPos + " end position :"
						+ endPos);
				HttpURLConnection http = WebResourceUtils.getHttpURLConnection(
						new URL(mDownloadBean.url), WebResourceUtils.GET, map);
				long size = http.getContentLength();
				mDownloadBean.fileSize = size;
				LogUtil.i("aa", size + "======================");
				InputStream inStream = http.getInputStream();
				byte[] buffer = new byte[LOAD_BUF_SIZE];
				int offset = 0;
				RandomAccessFile threadfile = new RandomAccessFile(file, "rwd");
				threadfile.seek(startPos);
//				while ((offset = inStream.read(buffer, 0, LOAD_BUF_SIZE)) != -1) {
//					if (mIsCancel) {
//						break;
//					} else {
//						threadfile.write(buffer, 0, offset);
//						mFileDownloader.updateDownloadedSize(LOAD_BUF_SIZE);
//					}
//				}
				while ((offset = inStream.read(buffer)) != -1) {
					if (mIsCancel) {
						break;
					} else {
						threadfile.write(buffer, 0, offset);
						LogUtil.i(""+offset);
						mFileDownloader.updateDownloadedSize(offset);
					}
				}
				threadfile.close();
				inStream.close();
			} catch (Exception e) {
				e.printStackTrace();
				mDownloadBean.isLoadFailed = true;
			}finally{
				
			}
		}
		if (mDownloadedListener != null) {
			mDownloadedListener.onDownloadFinish(getDownloadStatus());
		}
		DownloadListBean.save();
	}

	private int getDownloadStatus() {
		int status;
		if (mDownloadBean.isLoadFailed) {
			if (!SystemParamsUtils.SDEnable()) {
				status = DownloadedListener.DOWNLOAD_FIALED_SD_UNABLE;
			} else if (SystemParamsUtils.getSDCardAvailableMemory() == 0) {
				status = DownloadedListener.DOWNLOAD_FIALED_SD_MEMORY_LACK;
			}
			status = DownloadedListener.DOWNLOAD_FIALED_NETWORK;
		} else {
			if (mDownloadBean.isFinish()) {
				status = DownloadedListener.DOWNLOAD_SUCCEED;// succeed
			} else {
				if (mIsCancel) {
					status = DownloadedListener.DOWNLOAD_PAUSE;// pause
				} else {
					status = DownloadedListener.DOWNLOAD_BREAK_OFF;// break_off
				}
			}
		}
		return status;
	}

}
