package com.suncco.chinacdc.downloader;

public class DownloadException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8283759398117520224L;

	public DownloadException(String message) {
		super(message);
	}
	
}
