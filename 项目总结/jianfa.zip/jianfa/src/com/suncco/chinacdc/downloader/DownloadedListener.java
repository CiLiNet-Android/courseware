package com.suncco.chinacdc.downloader;

/**
 * 下载状态
 * 
 * @author 陈俊金
 * @date 2012-7-23 下午5:58:46
 */
public interface DownloadedListener {
	public static final int DOWNLOAD_PAUSE = 0; // 暂停
	public static final int DOWNLOAD_FIALED_NETWORK = -1; // 失败
	public static final int DOWNLOAD_FIALED_SD_UNABLE = -2; // sd卡不可用
	public static final int DOWNLOAD_FIALED_SD_MEMORY_LACK = -2; // sd卡内存不足
	public static final int DOWNLOAD_SUCCEED = 1; // 成功
	public static final int DOWNLOAD_BREAK_OFF = 2; // 连接中断

	/**
	 * status :DOWNLOAD_PAUSE DOWNLOAD_FIALED DOWNLOAD_SUCCEED
	 * DOWNLOAD_BREAK_OFF
	 * 
	 * @param status
	 */
	public void onDownloadFinish(int status);

}
