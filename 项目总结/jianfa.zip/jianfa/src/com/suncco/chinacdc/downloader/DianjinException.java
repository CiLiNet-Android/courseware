package com.suncco.chinacdc.downloader;

public class DianjinException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8283759398117520224L;

	public DianjinException(String message) {
		super(message);
	}
	
}
