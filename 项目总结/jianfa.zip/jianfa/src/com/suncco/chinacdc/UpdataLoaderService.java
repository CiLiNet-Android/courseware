package com.suncco.chinacdc;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.RemoteViews;

import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebResourceUtils;

/**
 * 点金更新 service
 * 
 * @author 陈俊金
 * @date 2012-7-13 下午8:27:38
 */
public class UpdataLoaderService extends Service {
	static final int HANDLER_LAODING = 0;
	static final int HANDLER_LOADED = 2;
	static final int BUF_SIZE = 2048;
	private Notification notification = null;
	private NotificationManager manager = null;
	private String filePath;
	private String url;
	private long size;
	private String version;
	private Timer mTimer;
	private boolean tag = true;
	Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_LAODING) {
				sendLoadingProgress();
			} else if (msg.what == HANDLER_LOADED) {
				sendLoadedState();
				stopSelf();
			}
		};
	};

	private void sendLoadingProgress() {
		File file = new File(filePath);
		long downloadedSize = 0;
		if (file.exists()) {
			downloadedSize = file.length();
		}
		notification = new Notification(R.drawable.ic_launcher, "开始下载"
				+ getString(R.string.app_name), System.currentTimeMillis());
		if (tag) {
			notification.defaults = Notification.DEFAULT_SOUND;
			tag = false;
		}
		Intent intent = new Intent();
		PendingIntent pi = PendingIntent.getActivity(UpdataLoaderService.this,
				0, intent, 0);
		RemoteViews rv = new RemoteViews(
				UpdataLoaderService.this.getPackageName(),
				R.layout.custom_dialog);
		float progress = (float) downloadedSize / (float) size;
		rv.setProgressBar(R.id.progressBar1, 100, (int) (progress * 100f),
				false);
		rv.setTextViewText(R.id.status, ((int) (progress * 100)) + "%");
		notification.contentView = rv;
		notification.contentIntent = pi;
		manager.notify(R.drawable.ic_launcher, notification);
	}

	private boolean isDownloaded(long fileSize) {
		File file = new File(filePath);
		if (file.exists()) {
			if (file.length() == fileSize) {
				return true;
			} else if (file.length() > fileSize) {
				file.delete();
			}
		}
		return false;
	}

	private void sendLoadedState() {
		LogUtil.e("sendLoadeState");
		mTimer.cancel();
		boolean downloadStatus = isDownloaded(size);
		LogUtil.e("" + downloadStatus +"\n" + size);
		
		Intent installIntent = new Intent();
		if (downloadStatus) {
			notification = new Notification(R.drawable.ic_launcher,
					getString(R.string.app_name) + "下载完成",
					System.currentTimeMillis());
			installIntent.setAction(android.content.Intent.ACTION_VIEW);
			String appType = "application/vnd.android.package-archive";
			installIntent.setDataAndType(Uri.fromFile(new File(filePath)),
					appType);
		} else {
			notification = new Notification(R.drawable.ic_launcher,
					getString(R.string.app_name) + "下载失败",
					System.currentTimeMillis());
		}
		notification.defaults = Notification.DEFAULT_SOUND;
		PendingIntent pi = PendingIntent.getActivity(UpdataLoaderService.this,
				0, installIntent, 0);
		RemoteViews rv = new RemoteViews(
				UpdataLoaderService.this.getPackageName(),
				R.layout.custom_dialog);
		rv.setProgressBar(R.id.progressBar1, 100, 100, false);
		rv.setTextViewText(R.id.status, downloadStatus ? "下载成功！" : "下载失败！");
		notification.contentView = rv;
		notification.contentIntent = pi;
		notification.flags = Notification.FLAG_AUTO_CANCEL;
		manager.notify(R.drawable.ic_launcher, notification);
	}

	@Override
	public void onCreate() {
		super.onCreate();
	}

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		url = intent.getStringExtra("url");
		version = intent.getStringExtra("version");
//		size = intent.getLongExtra("size", 0);
		File file = new File(Constans.DOWNLOAD_DIR);
		if (!file.isDirectory()) {
			file.mkdirs();
		}
		filePath = Constans.DOWNLOAD_DIR + getString(R.string.app_name) + "v"
				+ version + ".apk";
		manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		mTimer = new Timer();
		mTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				mHandler.sendEmptyMessage(HANDLER_LAODING);
			}
		}, 0, 1000);
		new Thread() {
			public void run() {
				super.run();
				if (url == null) {
					mHandler.sendEmptyMessage(HANDLER_LOADED);
					return;
				}
				File file = new File(filePath);
				InputStream in = null;
				FileOutputStream out = null;
				byte[] buf = new byte[2048];
				try {
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("Referer", url);
					HttpURLConnection http = WebResourceUtils.getHttpURLConnection(
							new URL(url), WebResourceUtils.GET, map);
					size = http.getContentLength();
//					URL u = new URL(url);
//					URLConnection conn = u.openConnection();
//					size = conn.getContentLength();
					
					if (isDownloaded(size)) {
						mHandler.sendEmptyMessage(HANDLER_LOADED);
						return;
					}
					LogUtil.i("aa", size + "======================");
					in = http.getInputStream();
					out = new FileOutputStream(filePath);

					int i;
					while ((i = in.read(buf)) != -1) {
						out.write(buf, 0, i);
					}
					return;
				} catch (Exception e) {
					if (file.exists()) {
						file.delete();
					}
					e.printStackTrace();
				} finally {
					if (out != null) {
						try {
							out.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					mHandler.sendEmptyMessage(HANDLER_LOADED);
				}
				return;
			};
		}.start();

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	};

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
}
