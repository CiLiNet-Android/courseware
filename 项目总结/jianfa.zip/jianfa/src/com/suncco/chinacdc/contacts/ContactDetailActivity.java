package com.suncco.chinacdc.contacts;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Contacts;
import android.provider.Contacts.Intents;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.CareListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.OrganizationBean;
import com.suncco.chinacdc.bean.PhotoBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ContactUtils;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;

public class ContactDetailActivity extends BaseActivity implements
		OnClickListener {

	private static final int HANDLER_SAVE_CONTACT = 100;
	
	private static final int HANDLER_PHOTO_RESULT = 101;

	private UserBean mUserBean;
	private LoadingProgressDialog mProgress;
	private ImageView mPhoto;
	boolean isFavourite = false;
	private Button btnFav;
	private ImageView mFavIcon;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contact_detail_activity);
		mUserBean = (UserBean) getIntent().getSerializableExtra("user");
		prepareView();
		setPhotoView();
	}

	private void prepareView() {
		mProgress = new LoadingProgressDialog(this);
		TextView organization = (TextView) findViewById(R.id.organization_name);
		organization.setText(mUserBean.orgName);
		
		TextView name = (TextView) findViewById(R.id.contact_detail_name);
		name.setText(mUserBean.name);
		TextView job = (TextView) findViewById(R.id.contact_detail_job);
		job.setText(mUserBean.job);
		TextView partment = (TextView) findViewById(R.id.contact_detail_partment);
		if(mUserBean.orgName.equals("集团本部")){
			partment.setText("建发集团");
		}else{
			partment.setText(mUserBean.orgName);
		}
		partment.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
		partment.getPaint().setAntiAlias(true);// 抗锯齿
		partment.setOnClickListener(this);
		TextView phone = (TextView) findViewById(R.id.contact_detail_phone);
		phone.setText(mUserBean.phone1);
//		TextView tel = (TextView) findViewById(R.id.contact_detail_tel);
//		tel.setText(mUserBean.phone2);
		TextView telephone = (TextView) findViewById(R.id.contact_detail_tel);
		telephone.setText(mUserBean.telephone);
		TextView email = (TextView) findViewById(R.id.contact_detail_emial);
		email.setText(mUserBean.email);
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.contact_detail_send_msm).setOnClickListener(this);
		findViewById(R.id.contact_detail_call_phone).setOnClickListener(this);
		findViewById(R.id.contact_detail_call_tel).setOnClickListener(this);
		findViewById(R.id.contact_detail_send_email).setOnClickListener(this);
		findViewById(R.id.contact_detail_send).setOnClickListener(this);
		findViewById(R.id.contact_detail_save).setOnClickListener(this);
		mPhoto = (ImageView) findViewById(R.id.contact_detail_photo);
		findViewById(R.id.contact_detail_favour).setOnClickListener(this);
		isFavourite = CareListBean.isFavourite(mUserBean);
		btnFav = (Button)findViewById(R.id.contact_detail_favour);
		mFavIcon = (ImageView)findViewById(R.id.contact_detail_care_img);
		setFavouriteView();
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.back:
			finish();
			break;
		case R.id.contact_detail_send_msm:
			if (!TextUtils.isEmpty(mUserBean.phone1)) {
				ContactUtils.sendSMS(this, mUserBean.phone1, "");
			}
			break;
		case R.id.contact_detail_call_phone:
			if (!TextUtils.isEmpty(mUserBean.phone1)) {
				ContactUtils.call(this, mUserBean.phone1);
			}
			break;
		case R.id.contact_detail_call_tel:
			if (!TextUtils.isEmpty(mUserBean.telephone)) {
				ContactUtils.call(this, mUserBean.telephone);
			}
			break;
		case R.id.contact_detail_send_email:
			if (!TextUtils.isEmpty(mUserBean.email)) {
				ContactUtils.sendEmial(this, mUserBean.email);
			}
			break;
		case R.id.contact_detail_send:
			String head = "smsto:";
			Intent mIntent = new Intent(android.content.Intent.ACTION_SENDTO,
					Uri.parse(head));
			mIntent.putExtra("sms_body", mUserBean.parseToCard());
			mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			// Intent mIntent = new Intent(Intent.ACTION_VIEW);
			// mIntent.putExtra("address", number);
			// mIntent.setType("vnd.android-dir/mms-sms");
			startActivity(Intent.createChooser(mIntent,getResources().getString( R.string.app_choose_app_please)));
//			ContactUtils.sendSMS(this, "", mUserBean.parseToCard());
			break;
		case R.id.contact_detail_save:
			addContact();
//			mProgress.show();
//			new Thread(new Runnable() {
//				public void run() {
//					Message msg = new Message();
//					try {
//						boolean result = ContactUtils.insertContact(mUserBean);
//						msg.arg2 = result ? 1 : 0;
//						msg.arg1 = 1;
//					} catch (Exception e) {
//						e.printStackTrace();
//						msg.arg1 = 0;
//					}
//					msg.what = HANDLER_SAVE_CONTACT;
//					mHandler.sendMessage(msg);
//				}
//			}).start();
			break;
		case R.id.contact_detail_favour:
			isFavourite = CareListBean.getInstance().changeFavourite(mUserBean);
			if(isFavourite){
				BaseApp.showToast("已关注");
			}else{
				BaseApp.showToast("已取消关注");
			}
			setFavouriteView();
			break;
		case R.id.contact_detail_partment:
			OrganizationBean bean = new OrganizationBean();
			bean.id = mUserBean.orgId;
			bean.name = mUserBean.orgName;
			bean.type = mUserBean.orgType;
			OrganizationActivity.mSearchOrganizationBean = bean;
			Intent intent = new Intent(ContactDetailActivity.this,ContactTabActivity.class);
			intent.putExtra("index", 2);
			intent.addFlags(Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//			intent.addFlags(0x10200000);
//			intent.setAction(Intent.ACTION_MAIN);
//			intent.addCategory("android.intent.category.LAUNCHER");
			intent.setAction(String.valueOf(System.currentTimeMillis()));
			startActivity(intent);
			finish();
			break;
		default:
			break;
		}
	}

	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_SAVE_CONTACT) {
				mProgress.dismiss();
				if (msg.arg1 == 0) {
					BaseApp.showToast(R.string.contact_save_exc);
				} else {
					if (msg.arg2 == 0) {
						BaseApp.showToast(R.string.contact_save_exit_exc);
					} else {
						BaseApp.showToast(R.string.contact_save_succeed);
					}
				}
			}else if(msg.what == HANDLER_PHOTO_RESULT){
				PhotoBean bean = (PhotoBean) msg.obj;
				if(bean != null){
					Bitmap bm = ImageUtils.stringtoBitmap(bean.photo);
					if(bm != null){
						ImageUtils.saveMyBitmap(bm, Constans.IMG_DIR + mUserBean.photo);
						mPhoto.setImageBitmap(bm);
					}
				}
			}
		};
	};
	
	private void setPhotoView(){
		if(mUserBean.photo == null || mUserBean.photo.equals("")){
			return;
		}
		
		Bitmap bm = null;
		try {
			bm= ImageUtils.getBitmap(Constans.IMG_DIR + mUserBean.photo);
//				ImageLoader.getInstance().loadBitmapByUrl(bean.photo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (bm != null) {
			mPhoto.setImageBitmap(bm);
		} else {
//			mPhoto.setImageResource(R.drawable.test_p);
				WebServiceParamsUtils utils = new WebServiceParamsUtils();
				utils.addNameAndValue("imageId", mUserBean.photo );
				utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId );
				LogUtil.e("imageId------>" + mUserBean.photo);
				new ChinacdcThread(PhotoBean.class, utils.formatParams(),
						mHandler, HANDLER_PHOTO_RESULT).start();
			}
		}
	
	private void setFavouriteView(){
		if(isFavourite){
			btnFav.setText("取消关注");
			mFavIcon.setImageResource(R.drawable.icon_care_selected);
		}else{
			btnFav.setText("关注");
			mFavIcon.setImageResource(R.drawable.icon_care);
		}
	}
	
	private void addContact() {
//		long contactID = ContactUtils.insertContactFirest(mUserBean);
        Intent intent = new Intent(android.provider.ContactsContract.Intents.Insert.ACTION);
        intent.setType("vnd.android.cursor.dir/person");
        intent.setType("vnd.android.cursor.dir/contact");
        intent.setType("vnd.android.cursor.dir/raw_contact");
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.NAME, mUserBean.name);
//        intent.putExtra(android.provider.ContactsContract.Contacts.DISPLAY_NAME, mUserBean.name);
//        intent.putExtra(android.provider.ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME, mUserBean.name);
//        intent.putExtra(android.provider.ContactsContract.CommonDataKinds.StructuredName.PHONETIC_GIVEN_NAME, mUserBean.name);
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.COMPANY,mUserBean.orgName);
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.JOB_TITLE,mUserBean.job);
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, mUserBean.phone1);
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.EMAIL, mUserBean.email);
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.NOTES, mUserBean.name);
        intent.putExtra(android.provider.ContactsContract.Intents.Insert.TERTIARY_PHONE, mUserBean.telephone);

        startActivity(intent);
}
		

}
