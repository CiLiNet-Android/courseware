package com.suncco.chinacdc.contacts;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.OrganizationListBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ContactUtils;

public class UserAdapter extends BaseAdapter {

	private Context mContext;
	public OrganizationListBean mOrganizationListBean;
//	private boolean isThreadOn;
	public boolean selectMode;
	private boolean[] checks;


	public UserAdapter(Context context, OrganizationListBean bean) {
		this.mContext = context;
		this.mOrganizationListBean = bean;
		this.checks = new boolean[mOrganizationListBean.mUserBeans.size()];
	}

	private OnClickListener mOnClickListener = new OnClickListener() {
		public void onClick(View v) {
			// TODO Auto-generated method stub
			String phone = (String) v.getTag();
			if(!TextUtils.isEmpty(phone))
			ContactUtils.call(mContext,phone);
		}
	};
	public int getCount() {
		return mOrganizationListBean == null ? 0
				: mOrganizationListBean.mUserBeans.size();
	}
	
	public boolean setSelect(int position){
		
		checks[position] = !checks[position];
		notifyDataSetChanged();
		return checks[position];
	}
	
	public boolean setSeletAll(boolean isSelect){
		for(int i = 0 , l = checks.length ; i < l ; i++){
			checks[i] = isSelect;
		}
		notifyDataSetChanged();
		return isSelect;
	}
	
	
	public ArrayList<UserBean> getSeletUserBeans(){
		ArrayList<UserBean> list = new ArrayList<UserBean>();
		for(int i = 0 , l = checks.length ; i < l ; i++){
			if(checks[i]){
				list.add(getItem(i));
			}
		}
		return list;
	}

	public UserBean getItem(int arg0) {
		return mOrganizationListBean.mUserBeans.get(arg0);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		ImageView photo;
		TextView name;
		TextView job;
		TextView phone;
		CheckBox check;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.contact_leader_item, null);
			holder = new ViewHolder();
			holder.photo = (ImageView) convertView.findViewById(R.id.photo);
			holder.name = (TextView) convertView.findViewById(R.id.name);
			holder.job = (TextView) convertView.findViewById(R.id.job);
			holder.phone = (TextView) convertView.findViewById(R.id.phone);
			holder.check = (CheckBox) convertView.findViewById(R.id.contact_checkbox);
			holder.check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					int pos = (Integer) buttonView.getTag();
					checks[pos] = isChecked;
					notifyDataSetChanged();
				}
			});
			holder.phone.setOnClickListener(mOnClickListener);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		UserBean bean = getItem(position);
		holder.check.setTag(position);
		holder.name.setText(bean.name);
		holder.job.setText(bean.job);
		holder.phone.setText(bean.phone1);
		holder.phone.setTag(bean.phone1);
		if(selectMode){
			holder.check.setVisibility(View.VISIBLE);
			holder.check.setChecked(checks[position]);
		}else{
			holder.check.setVisibility(View.GONE);
		}

		if (!TextUtils.isEmpty(bean.photo)) {

			Bitmap bm = null;
			//这里要纳入图片缓存体系中去.
			bm = BitmapLoader.getInstance().loadBitmapByPath(Constans.IMG_DIR + bean.photo, BaseApp.sScreenWidth/3, BaseApp.sScreenWidth/3);
//			bm = ImageLoader.getInstance().loadBitmapByPath(Constans.IMG_DIR + bean.photo);
//			bm = ImageLoader.getInstance().loadBitmapByPath(
//					Constans.IMG_DIR + bean.photo);
			if (bm != null) {
				holder.photo.setImageBitmap(bm);
			} else {
				holder.photo.setImageResource(R.drawable.contact_default_img);
			}
		}else{
			holder.photo.setImageResource(R.drawable.contact_default_img);
		}

		return convertView;
	}

}
