package com.suncco.chinacdc.contacts;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.OrgaParentListDate;

public class ContactsPopDirAdapter extends BaseAdapter {

	private Context mContext;
	private ArrayList<OrgaParentListDate> mList;

	public ContactsPopDirAdapter(Context context ,ArrayList<OrgaParentListDate> list) {
		this.mContext = context;
		this.mList = list;
	}
	
	private class Holder{
		
		TextView name;
	}

	public int getCount() {
		// TODO Auto-generated method stub
		return mList.size();
	}

	public OrgaParentListDate getItem(int position) {
		// TODO Auto-generated method stub
		return mList.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		Holder holder;
		if (convertView == null) {
			holder = new Holder();
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.contacts_pop_item, null);
			holder.name = (TextView) convertView.findViewById(R.id.organize_name);
			convertView.setTag(holder);
		}else{
			holder = (Holder) convertView.getTag();
		}
		OrgaParentListDate bean = getItem(position);
		holder.name.setText(bean.name);
		
		return convertView;
	}

}
