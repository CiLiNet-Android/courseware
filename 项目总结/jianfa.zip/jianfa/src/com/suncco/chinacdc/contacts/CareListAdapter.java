package com.suncco.chinacdc.contacts;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.CareListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.PhotoBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ContactUtils;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;

public class CareListAdapter extends BaseAdapter {

	private Context mContext;
	public CareListBean mCareListBean;
	private boolean isThreadOn;
	public boolean selectMode;
	private boolean[] checks;

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if (msg.what < 0 || msg.what > mCareListBean.mUserBeans.size()) {
				return;
			}
			PhotoBean bean = (PhotoBean) msg.obj;
			if (bean == null) {
				isThreadOn = false;
				getItem(msg.what).isLoadedPhoto = true;
				notifyDataSetChanged();
			} else {
				Bitmap bitmap = ImageUtils.stringtoBitmap(bean.photo);
				if (bitmap != null) {
					ImageUtils.saveMyBitmap(bitmap, Constans.IMG_DIR
							+ getItem(msg.what).photo);
					bitmap.recycle(); // yy之前这里没回收图片
					isThreadOn = false;
					getItem(msg.what).isLoadedPhoto = true;
					notifyDataSetChanged();
				} else {
					isThreadOn = false;
					getItem(msg.what).isLoadedPhoto = true;
					notifyDataSetChanged();
				}
			}
		}

	};

	public CareListAdapter(Context context, CareListBean bean) {
		this.mContext = context;
		this.mCareListBean = bean;
//		mCareListBean.mUserBeans.addAll(bean.mUserBeans);
		checks = new boolean[mCareListBean.mUserBeans.size()];
		
	}
	
	private OnClickListener mOnClickListener = new OnClickListener() {
		public void onClick(View v) {
			// TODO Auto-generated method stub
			String phone = (String) v.getTag();
			if(!TextUtils.isEmpty(phone))
			ContactUtils.call(mContext,phone);
		}
	};

	public int getCount() {
		return mCareListBean == null ? 0 : mCareListBean.mUserBeans.size();
	}

	public void setSelect(int position) {

		checks[position] = !checks[position];
//		LogUtil.e("setSelect-->" + checks[position] + position);
		notifyDataSetChanged();
	}

	public boolean setSeletAll(boolean isSelect) {
		for (int i = 0, l = checks.length; i < l; i++) {
			checks[i] = isSelect;
		}
		notifyDataSetChanged();
		return isSelect;
	}

	public ArrayList<UserBean> getSeletUserBeans() {
		ArrayList<UserBean> list = new ArrayList<UserBean>();
		for (int i = 0, l = checks.length; i < l; i++) {
//			LogUtil.e("is selected-->" + checks[i]);
			if (checks[i]) {
				list.add(getItem(i));
			}
		}
		return list;
	}

	public UserBean getItem(int position) {
		return mCareListBean.mUserBeans.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		ImageView photo;
		TextView name;
		TextView job;
		TextView phone;
		CheckBox check;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.contact_leader_item, null);
			holder = new ViewHolder();
			holder.photo = (ImageView) convertView.findViewById(R.id.photo);
			holder.name = (TextView) convertView.findViewById(R.id.name);
			holder.job = (TextView) convertView.findViewById(R.id.job);
			holder.phone = (TextView) convertView.findViewById(R.id.phone);
			holder.check = (CheckBox) convertView
					.findViewById(R.id.contact_checkbox);
			holder.check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					int pos = (Integer) buttonView.getTag();
					checks[pos] = isChecked;
					notifyDataSetChanged();
				}
			});
			holder.phone.setOnClickListener(mOnClickListener);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		UserBean bean = getItem(position);
		holder.check.setTag(position);
		holder.name.setText(bean.name);
		holder.job.setText(bean.job);
		holder.phone.setText(bean.phone1);
		holder.phone.setTag(bean.phone1);
		if (selectMode) {
			holder.check.setVisibility(View.VISIBLE);
			holder.check.setChecked(checks[position]);
		} else {
			holder.check.setVisibility(View.GONE);
		}

		if (!TextUtils.isEmpty(bean.photo)) {

			Bitmap bm = null;
			// 这里要纳入图片缓存体系中去.
			bm = ImageUtils.getBitmap(Constans.IMG_DIR + bean.photo);
			// bm = ImageLoader.getInstance().loadBitmapByPath(
			// Constans.IMG_DIR + bean.photo);
			if (bm != null) {
				holder.photo.setImageBitmap(bm);
			} else {
//				holder.photo.setImageResource(R.drawable.test_p);
				if (!isThreadOn && !bean.isLoadedPhoto) {
					WebServiceParamsUtils utils = new WebServiceParamsUtils();
					utils.addNameAndValue("imageId", bean.photo + "");
					utils.addNameAndValue("sessionId",
							LoginBean.getInstance().sessionId + "");
					isThreadOn = true;
					new ChinacdcThread(PhotoBean.class, utils.formatParams(),
							mHandler, position).start();
				}
			}
		}

		return convertView;
	}

}
