package com.suncco.chinacdc.contacts;

import java.text.MessageFormat;
import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.OrgRootListBean;
import com.suncco.chinacdc.bean.OrgaCustomParentListBean;
import com.suncco.chinacdc.bean.OrgaParentListBean;
import com.suncco.chinacdc.bean.OrgaParentListDate;
import com.suncco.chinacdc.bean.OrganizationBean;
import com.suncco.chinacdc.bean.OrganizationCustomListBean;
import com.suncco.chinacdc.bean.OrganizationListBean;
import com.suncco.chinacdc.bean.PhotoBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.downloader.ThreadPoolHelper;
import com.suncco.chinacdc.utils.ChinacdcPhotoThread;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ContactUtils;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.MyListView;
import com.suncco.chinacdc.widget.MyRefreshListView;
import com.suncco.chinacdc.widget.MyRefreshListView.OnRefreshListener;

public class OrganizationActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener, OnCancelListener,
		OnCheckedChangeListener, OnRefreshListener {

	private static final int HANDLER_ORGANIZATION_WHAT = 100;
	private static final int HANDLER_SAVE_WHAT = 101;
	private static final int HANDLER_PHOTO_RESULT = 102;
	private static final int HANDLER_PHOTO_SAVE_DONE = 103;
	private static final int HANDLER_ORGPARENT_RESULT = 104;
	private static final int HANDLER_ORGROOT_RESULT = 105;

	private boolean isOpenMenuPop;
	private boolean isOpenDirPop;
	private PopupWindow mPopupMenuWindow;
	private PopupWindow mPopupDirWindow;
	private View mTitleBar;
	private LoadingProgressDialog mProgress;
	private UserAdapter mUserAdapter;
	private OrganizationAdapter mOrganizationAdapter;
	private TextView mTitleName;
	private AlertDialog mAlertDialog;
	private ChinacdcThread mChinacdcThread;
	private ContactTabActivity mParent;
	private MyListView mUserList;
	private MyRefreshListView mOrganList;

	private ContactsPopDirAdapter mHistoryAdapter;
	private ArrayList<OrganizationListBean> mOrganizes = new ArrayList<OrganizationListBean>();
	private OrganizationListBean mCurrentOrganize;
	private OrgRootListBean mOrgRootListBean;
	public static OrganizationBean mSearchOrganizationBean;
	private boolean selectMode = false;
	View viewSelectAll;
	private ArrayList<UserBean> mSeletUserBeans;
	private int selectType = 0;// 0是添加联系人，1是发送短信
	Button mTitleButton2;
	Button mTitleButton1;
	CheckBox mCheckBox;
	Thread mSelectThread;
	ChinacdcPhotoThread mChinacdcPhotoThread;

	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_ORGANIZATION_WHAT) {
				OrganizationListBean bean = (OrganizationListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_net_exc);
				} else {
					if (bean.code == 0) {
						// addHistoryOrg(bean);
						LogUtil.e("bean id---- --》" + bean.id);
						mCurrentOrganize = bean;

						boolean saved = mCurrentOrganize.save();
						setListView();
						ThreadPoolHelper.execute(new Runnable() {
							public void run() {
								// TODO Auto-generated method stub
								Bitmap bm = null;
								String[] imgs = new String[mCurrentOrganize.mUserBeans
										.size()];
								for (int i = 0, l = mCurrentOrganize.mUserBeans
										.size(); i < l; i++) {
									imgs[i] = mCurrentOrganize.mUserBeans
											.get(i).photo;
								}
								mChinacdcPhotoThread = new ChinacdcPhotoThread(
										PhotoBean.class, imgs, mHandler,
										HANDLER_PHOTO_SAVE_DONE);
								mChinacdcPhotoThread.start();
							}
						});
					} else {
						BaseApp.showSessionnDialog(OrganizationActivity.this,
								bean);
					}
				}
				mOrganList.onRefreshComplete();
				mProgress.dismiss();
			} else if (msg.what == HANDLER_SAVE_WHAT) {
				UserBean bean = (UserBean) msg.obj;
				if (bean != null) {
					String info = MessageFormat.format(
							getString(R.string.contact_saving_template),
							bean.name, msg.arg1, msg.arg2);
					mAlertDialog.setMessage(info);
				} else {
					mAlertDialog.dismiss();
					mAlertDialog = null;
					BaseApp.showToast(R.string.contact_save_succeed);
				}
			} else if (msg.what == HANDLER_PHOTO_RESULT) {
				final PhotoBean bean = (PhotoBean) msg.obj;
				if (bean == null) {
				} else {
					LogUtil.e("下载到图片啦！！！");
					ThreadPoolHelper.execute(new Runnable() {
						public void run() {
							Bitmap bitmap = ImageUtils
									.stringtoBitmap(bean.photo);
							if (bitmap != null) {
								ImageUtils.saveMyBitmap(bitmap,
										Constans.IMG_DIR + bean.id);
								bitmap.recycle();
								mHandler.sendEmptyMessage(HANDLER_PHOTO_SAVE_DONE);
							} else {
							}

						}
					});
				}

			} else if (HANDLER_PHOTO_SAVE_DONE == msg.what) {
				if (mUserAdapter != null)
					mUserAdapter.notifyDataSetChanged();
			} else if (HANDLER_ORGPARENT_RESULT == msg.what) {
				OrgaParentListBean bean = (OrgaParentListBean) msg.obj;
				if (bean != null) {
					if (bean.code == 0) {
						popDirWindow(mTitleName, bean);
					} else if(bean.code == 2){
						BaseApp.showSessionnDialog(OrganizationActivity.this, bean);
					} else{
						
						BaseApp.showToast(bean.message);
					}
				} else {
					BaseApp.showToast(R.string.app_net_exc);
				}
				mProgress.dismiss();
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contacts_activity);
		prepareView();
		// mProgress.show();
		if (mSearchOrganizationBean != null
				&& !mSearchOrganizationBean.id
						.equals(mCurrentOrganize == null ? "0"
								: mCurrentOrganize.id)) {
			getOrganizationList(mSearchOrganizationBean.id,
					mSearchOrganizationBean.type);
			mSearchOrganizationBean = null;
		} else {
			getOrganizationList("0", "1");
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		mTitleButton2.setVisibility(View.VISIBLE);
		mTitleButton2.setOnClickListener(this);
		mTitleButton2.setText("多选");
		mTitleName.setOnClickListener(this);
		if (mCurrentOrganize != null && mCurrentOrganize.name != null) {
			mTitleName.setText(mCurrentOrganize.name);
		} else {
			mTitleName.setText("通讯录");
		}
		selectMode = false;
		setSeletView();

		if (mSearchOrganizationBean != null
				&& !mSearchOrganizationBean.id
						.equals(mCurrentOrganize == null ? "0"
								: mCurrentOrganize.id)) {
			// BaseApp.showToast(mSearchOrganizationBean.id);
			getOrganizationList(mSearchOrganizationBean.id,
					mSearchOrganizationBean.type);
			mSearchOrganizationBean = null;
		}

		mTitleButton1.setOnClickListener(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.title_but1:
			if (selectMode) {
				selectMode = false;
				setSeletView();
			} else {

				if (mCurrentOrganize == null
						|| mCurrentOrganize.parentId == null) {
					finish();
				} else {
					getOrganizationList(mCurrentOrganize.parentId,
							mCurrentOrganize.parentId.equals("0")? "1":mCurrentOrganize.type);
				}
			}
			break;
		case R.id.title_but2:
			if (selectMode) {
				if (mUserAdapter == null) {
					BaseApp.showToast("未选择联系人");
					return;
				}
				mSeletUserBeans = mUserAdapter.getSeletUserBeans();
				if (mSeletUserBeans.size() <= 0) {
					BaseApp.showToast("未选择联系人");
					return;
				}
				if (selectType == 0) {
					bitchSave();
				} else {
					ContactUtils.bitchSendMSM(this, mSeletUserBeans);
				}
				selectMode = false;
				setSeletView();
			} else {
				changMenuPopState(mTitleButton2);
			}
			break;
		case R.id.contacts_menu_save:
			if (mUserAdapter == null || mUserAdapter.getCount() <= 0) {
				BaseApp.showToast("没有联系人供选择");
				return;
			}
			selectMode = true;
			selectType = 0;
			setSeletView();
			changMenuPopState(mTitleButton2);
			break;
		case R.id.contacts_menu_send:
			if (mUserAdapter == null || mUserAdapter.getCount() <= 0) {
				BaseApp.showToast("没有联系人供选择");
				return;
			}
			selectMode = true;
			selectType = 1;
			setSeletView();
			changMenuPopState(mTitleButton2);
			break;
		case R.id.title_text:
			if (mCurrentOrganize == null || mCurrentOrganize.parentId == null
					|| mCurrentOrganize.parentId.equals("0"))
				return;
			getParentOrgList();
			// changeDirPopState(v);
			break;
		case R.id.contact_selectall_view:
			mCheckBox.performClick();
			break;
		default:
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// if (keyCode == KeyEvent.KEYCODE_BACK) {
		// if (mSearchFlipper.getCurrentView().getId() == R.id.search_view) {
		// mSearchFlipper.showNext();
		// findViewById(R.id.back).setVisibility(View.VISIBLE);
		// findViewById(R.id.contacts_menu).setVisibility(View.VISIBLE);
		// mTitleName.setText(getIntent().getStringExtra("org_name"));
		// return true;
		// }
		// }
		mTitleButton1.performClick();
		return true;
		// return super.onKeyDown(keyCode, event);
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		if (parent.getId() == R.id.contact_leader_list) {
			if (selectMode) {
				mUserAdapter.setSelect(position);
				return;
			}
			UserBean bean = mUserAdapter.getItem(position);
			Intent intent = new Intent(this, ContactDetailActivity.class);
			intent.putExtra("user", bean);
			startActivity(intent);
		} else if (parent.getId() == R.id.contacts_dir_list) {
			if (selectMode) {
				return;
			}
			OrganizationBean bean = mOrganizationAdapter.getItem(position - 2);
			// Intent intent = new Intent(this, OrganizationActivity.class);
			// intent.putExtra("org_id", bean.id);
			// intent.putExtra("org_name", bean.name);
			// startActivity(intent);
			getOrganizationList(bean.id, bean.type);
		} else if (parent.getId() == R.id.contacts_pop_list) {
			OrgaParentListDate bean = mHistoryAdapter.getItem(position);
			if (bean != null) {
				// mOrganizes.s
				// mCurrentOrganize = bean;
				// setListView();
				// selectMode = false;
				// setSeletView();
				getOrganizationList(bean.id, mCurrentOrganize.type);
			}
			changeDirPopState(mTitleName);
		}
	}

	public void onCancel(DialogInterface dialog) {
		if (mChinacdcThread != null) {
			mChinacdcThread.cancel();
		}
	}

	private void bitchSave() {
		mSeletUserBeans = mUserAdapter.getSeletUserBeans();
		if (mSeletUserBeans.size() <= 0) {
			BaseApp.showToast("未选择联系人");
			return;
		}
		if (mAlertDialog == null) {
			mAlertDialog = new AlertDialog.Builder(this)
					.setTitle(R.string.app_prompt).setMessage("").create();
			mAlertDialog.setOnCancelListener(new OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					// TODO Auto-generated method stub
					if (mSelectThread != null) {
						try {
							// mSelectThread.stop();
							mSelectThread.interrupt();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			});
			mAlertDialog.show();
			// bitchSave();
			mSelectThread = new Thread(new Runnable() {

				public void run() {
					ArrayList<UserBean> list = new ArrayList<UserBean>();
					list.addAll(mSeletUserBeans);
					int len = list.size();
					for (int i = 0; i < len && !Thread.interrupted(); i++) {
						UserBean bean = list.get(i);
						Message msg = new Message();
						msg.obj = bean;
						msg.what = HANDLER_SAVE_WHAT;
						msg.arg1 = i + 1;
						msg.arg2 = len;
						mHandler.sendMessage(msg);
						try {
							ContactUtils.insertContact(bean);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					mHandler.sendEmptyMessage(HANDLER_SAVE_WHAT);
				}
			});
			mSelectThread.start();
		}
	}

	private void getOrganizationList(String orgId, String type) {

		// OrganizationListBean listBean = null;
		OrganizationListBean listBean = OrganizationListBean.getOrgListBean(
				orgId, type);
		if (listBean != null) {
			LogUtil.e("get organize from cache!!!");
			mCurrentOrganize = listBean;
			setListView();
			ThreadPoolHelper.execute(new Runnable() {
				public void run() {
					// TODO Auto-generated method stub
					Bitmap bm = null;
					String[] imgs = new String[mCurrentOrganize.mUserBeans
							.size()];
					for (int i = 0, l = mCurrentOrganize.mUserBeans.size(); i < l; i++) {
						imgs[i] = mCurrentOrganize.mUserBeans.get(i).photo;
					}
					mChinacdcPhotoThread = new ChinacdcPhotoThread(
							PhotoBean.class, imgs, mHandler,
							HANDLER_PHOTO_SAVE_DONE);
					mChinacdcPhotoThread.start();
				}
			});
		} else {
			mProgress.show();
			WebServiceParamsUtils utils = new WebServiceParamsUtils();
			utils.addNameAndValue("sessionId",
					LoginBean.getInstance().sessionId);
			if (orgId.equals("0")) {
				// utils.addNameAndValue("orgId", "0");
				new ChinacdcThread(OrgRootListBean.class, utils.formatParams(),
						mHandler, HANDLER_ORGANIZATION_WHAT).start();
			} else {
				if (type.equals("2")) {
					utils.addNameAndValue("orgId", orgId);
					new ChinacdcThread(OrganizationCustomListBean.class,
							utils.formatParams(), mHandler,
							HANDLER_ORGANIZATION_WHAT).start();
				} else {
					utils.addNameAndValue("orgId", orgId);
					new ChinacdcThread(OrganizationListBean.class,
							utils.formatParams(), mHandler,
							HANDLER_ORGANIZATION_WHAT).start();

				}
			}
		}
	}

	private void changMenuPopState(View v) {
		isOpenMenuPop = !isOpenMenuPop;
		if (isOpenMenuPop) {
			popMenuWindow(v);
		} else {
			if (mPopupMenuWindow != null) {
				mPopupMenuWindow.dismiss();
			}
		}
	}

	private void changeDirPopState(View v) {
		isOpenDirPop = !isOpenDirPop;
		if (isOpenDirPop) {
			// popDirWindow(v);

		} else {
			if (mPopupDirWindow != null) {
				LogUtil.e("isOpenDir---->" + isOpenDirPop);
				mPopupDirWindow.dismiss();
			}
		}
	}

	private void prepareView() {
		mParent = (ContactTabActivity) getParent();
		mTitleButton2 = (Button) mParent.findViewById(R.id.title_but2);
		mTitleButton2.setOnClickListener(this);
		mTitleButton1 = (Button) mParent.findViewById(R.id.title_but1);
		mParent.findViewById(R.id.title_but1).setOnClickListener(this);
		mTitleBar = mParent.findViewById(R.id.title_text);
		mTitleBar.setOnClickListener(this);
		mProgress = new LoadingProgressDialog(this);
		mProgress.setOnCancelListener(this);
		mTitleName = (TextView) mParent.findViewById(R.id.title_text);
		mTitleName.setText("建发");
		// mTitleName.setText(getIntent().getStringExtra("org_name"));
		View head = LayoutInflater.from(OrganizationActivity.this).inflate(
				R.layout.contact_leader_list, null);
		viewSelectAll = head.findViewById(R.id.contact_selectall_view);
		viewSelectAll.setOnClickListener(this);
		mCheckBox = ((CheckBox) head.findViewById(R.id.contact_selectall_check));

		mCheckBox.setOnCheckedChangeListener(this);
		mUserList = (MyListView) head.findViewById(R.id.contact_leader_list);
		mUserList.setOnItemClickListener(OrganizationActivity.this);
		mOrganList = (MyRefreshListView) findViewById(R.id.contacts_dir_list);
		mOrganList.setonRefreshListener(this);
		mOrganList.setOnItemClickListener(OrganizationActivity.this);
		mOrganList.addHeaderView(head);
		setSeletView();
	}

	private void popDirWindow(View parent, OrgaParentListBean bean) {
		isOpenDirPop = true;
		if (mPopupDirWindow != null && mPopupDirWindow.isShowing()) {
			mPopupDirWindow.dismiss();
			mPopupDirWindow = null;
		}
		View popView = LayoutInflater.from(this).inflate(
				R.layout.contacts_pop_list, null);

		ArrayList<OrgaParentListDate> list = bean.mList;
		if (list == null || list.size() == 0) {
			isOpenDirPop = false;
			return;
		}
		ListView listView = (ListView) popView
				.findViewById(R.id.contacts_pop_list);
		mHistoryAdapter = new ContactsPopDirAdapter(this, list);
		listView.setAdapter(mHistoryAdapter);
		listView.setOnItemClickListener(this);
		mPopupDirWindow = new PopupWindow(popView,
				(int) (BaseApp.sScreenWidth * 2 / 3), LayoutParams.WRAP_CONTENT);
		mPopupDirWindow.setTouchInterceptor(new OnTouchListener() {

			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
					mPopupDirWindow.dismiss();
					return true;
				}
				return false;
			}
		});
		mPopupDirWindow.setOnDismissListener(new OnDismissListener() {

			public void onDismiss() {
				isOpenDirPop = false;
			}
		});
		ColorDrawable cd = new ColorDrawable(-0000);
		mPopupDirWindow.setBackgroundDrawable(cd);
		mPopupDirWindow.update();
		mPopupDirWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
		mPopupDirWindow.setTouchable(true);
		mPopupDirWindow.setOutsideTouchable(true);
		mPopupDirWindow.setFocusable(true);
		mPopupDirWindow.showAtLocation(parent, Gravity.TOP | Gravity.LEFT,
				(int) (BaseApp.sScreenWidth / 6),
				(int) (1.35f * mTitleBar.getBottom()));
//		mPopupDirWindow.showAsDropDown(parent, -(int) (BaseApp.sScreenWidth / 6), -10);
		// mPopupDirWindow.showAtLocation(parent, Gravity.TOP | Gravity.LEFT,
		// (int) (BaseApp.sScreenWidth / 2f - BaseApp.sScreenWidth / 3f),
		// (int) (1.2f * mTitleBar.getBottom()));
	}

	private void popMenuWindow(View parent) {
		isOpenMenuPop = true;
		if (mPopupMenuWindow != null) {
			mPopupMenuWindow.dismiss();
			mPopupMenuWindow = null;
		}
		if (mPopupMenuWindow == null) {
			View popView = LayoutInflater.from(this).inflate(
					R.layout.contacts_pop_menu, null);
			popView.findViewById(R.id.contacts_menu_save).setOnClickListener(
					this);
			popView.findViewById(R.id.contacts_menu_send).setOnClickListener(
					this);
			mPopupMenuWindow = new PopupWindow(popView,
					BaseApp.sScreenWidth / 2,
					(int) (BaseApp.sScreenHeight / 5.5f));
			mPopupMenuWindow.setTouchInterceptor(new OnTouchListener() {

				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
						mPopupMenuWindow.dismiss();
						return true;
					}
					return false;
				}
			});
			mPopupMenuWindow.setOnDismissListener(new OnDismissListener() {

				public void onDismiss() {
					isOpenMenuPop = false;
				}
			});
		}
		ColorDrawable cd = new ColorDrawable(-0000);
		mPopupMenuWindow.setBackgroundDrawable(cd);
		mPopupMenuWindow.update();
		mPopupMenuWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
		mPopupMenuWindow.setTouchable(true);
		mPopupMenuWindow.setOutsideTouchable(true);
		mPopupMenuWindow.setFocusable(true);
//		mPopupMenuWindow.showAtLocation(parent, Gravity.TOP,
//				(int) (BaseApp.sScreenWidth / 2),
//				(int) (1.35f * mTitleBar.getBottom()));
		mPopupMenuWindow.showAsDropDown(parent,0, -15);
		// mPopupMenuWindow.showAtLocation(parent,
		// (Gravity.BOTTOM - parent.getHeight()) | Gravity.LEFT,
		// BaseApp.sScreenWidth / 2, (int) (1.2f * mTitleBar.getBottom()));
	}

	public void onRefresh() {
		String orgId = mCurrentOrganize == null ? "0" : mCurrentOrganize.id;
		OrganizationListBean.clear(orgId, mCurrentOrganize == null ? "1"
				: mCurrentOrganize.type);
		getOrganizationList(orgId, mCurrentOrganize == null ? "1"
				: mCurrentOrganize.type);
	}

	// private OrganizationListBean getHistoryOrganizeById(String organizeId) {
	//
	// if (mOrganizes.size() == 0) {
	// return null;
	// }
	// OrganizationListBean bean;
	// for (int i = 0, l = mOrganizes.size(); i < l; i++) {
	// bean = mOrganizes.get(i);
	// if (bean.id != null && bean.id.equals(organizeId)) {
	// return mOrganizes.get(i);
	// }
	// }
	// return null;
	// }

	private void setListView() {
		if (mUserList == null) {

		}
		mUserAdapter = new UserAdapter(OrganizationActivity.this,
				mCurrentOrganize);
		mUserList.setAdapter(mUserAdapter);
		LogUtil.i("" + mCurrentOrganize.mOrganizationBeans.size());
		mOrganizationAdapter = new OrganizationAdapter(
				OrganizationActivity.this, mCurrentOrganize.mOrganizationBeans);
		mOrganList.setAdapter(mOrganizationAdapter);
		if (mCurrentOrganize.parentId == null) {
			((Button) mParent.findViewById(R.id.title_but1)).setText("返回");
			((ImageView) mParent.findViewById(R.id.title_text_img))
					.setVisibility(View.GONE);
		} else {
			if (mCurrentOrganize == null || mCurrentOrganize.parentId == null
					|| mCurrentOrganize.parentId.equals("0")) {
				((ImageView) mParent.findViewById(R.id.title_text_img))
						.setVisibility(View.GONE);

			} else {
				((ImageView) mParent.findViewById(R.id.title_text_img))
						.setVisibility(View.VISIBLE);

			}
			((Button) mParent.findViewById(R.id.title_but1)).setText("上级");
		}
		mTitleName.setText(mCurrentOrganize.name + "");

	}

	// private ArrayList<OrganizationListBean> getHistoryOrganize(String orgId)
	// {
	// ArrayList<OrganizationListBean> list = new
	// ArrayList<OrganizationListBean>();
	// OrganizationListBean bean;
	//
	// bean = getHistoryOrganizeById(orgId);
	// if (bean == null)
	// return list;
	// do {
	// list.add(bean);
	// bean = getHistoryOrganizeById(bean.parentId);
	// } while (bean != null);
	//
	// return list;
	// }

	private void setSeletView() {
		if (selectMode) {
			viewSelectAll.setVisibility(View.VISIBLE);
			mTitleButton2.setText("确认");
			mTitleButton1.setText("取消");
		} else {
			viewSelectAll.setVisibility(View.GONE);
			mTitleButton2.setText("多选");
			if (mCurrentOrganize != null && mCurrentOrganize.parentId == null) {
				mTitleButton1.setText("返回");
				((ImageView) mParent.findViewById(R.id.title_text_img))
						.setVisibility(View.GONE);
			} else {
				mTitleButton1.setText("上级");
				if (mCurrentOrganize == null
						|| mCurrentOrganize.parentId == null
						|| mCurrentOrganize.parentId.equals("0")) {
					((ImageView) mParent.findViewById(R.id.title_text_img))
							.setVisibility(View.GONE);
				} else {
					((ImageView) mParent.findViewById(R.id.title_text_img))
							.setVisibility(View.VISIBLE);
				}
			}
		}
		mCheckBox.setChecked(false);
		if (mUserAdapter != null) {
			mUserAdapter.selectMode = selectMode;
			mUserAdapter.setSeletAll(false);
			// mUserAdapter.notifyDataSetChanged();
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch (buttonView.getId()) {
		case R.id.contact_selectall_check:
			if (mUserAdapter != null)
				mUserAdapter.setSeletAll(isChecked);
			break;
		default:
			break;

		}
	}

	// protected void addHistoryOrg(OrganizationListBean bean) {
	// boolean add = true;
	// for (int i = 0, l = mOrganizes.size(); i < l; i++) {
	// if (bean.id.equals(mOrganizes.get(i).id)) {
	// add = false;
	// }
	// }
	//
	// if (add)
	// mOrganizes.add(bean);
	// }

	private void getParentOrgList() {
		mProgress.show();
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		utils.addNameAndValue("orgId", mCurrentOrganize.id);
		if(mCurrentOrganize != null && mCurrentOrganize.type.equals("2")){
			mChinacdcThread = new ChinacdcThread(OrgaCustomParentListBean.class,
					utils.formatParams(), mHandler, HANDLER_ORGPARENT_RESULT);
			mChinacdcThread.start();
		}else{
			mChinacdcThread = new ChinacdcThread(OrgaParentListBean.class,
					utils.formatParams(), mHandler, HANDLER_ORGPARENT_RESULT);
			mChinacdcThread.start();
		}
	}

}
