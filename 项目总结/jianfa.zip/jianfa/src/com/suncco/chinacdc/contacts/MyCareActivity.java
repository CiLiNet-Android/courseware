package com.suncco.chinacdc.contacts;

import java.text.MessageFormat;
import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.CareListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.PhotoBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ContactUtils;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.MyListView;

public class MyCareActivity extends BaseActivity implements OnClickListener,
		OnItemClickListener, OnCheckedChangeListener {

	private static final int HANDLER_PHOTO_RESULT = 101;

	ContactTabActivity mParent;
	TextView mTitle;
	Button mTitleButton2;
	Button mTitleButton1;
	MyListView mListView;
	CareListAdapter mCareListAdapter;
	boolean selectMode = false;
	CareListBean mCareListBean;
	private PopupWindow mPopupMenuWindow;
	View viewSelectAll, head;
	private ArrayList<UserBean> mSeletUserBeans;
	private int selectType = 0;// 0是添加联系人，1是发送短信，2是取消关注
	private AlertDialog mAlertDialog;
	// private ChinacdcThread mChinacdcThread;
	CheckBox mCheckBox;
	Thread mSelectThread;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contacts_care_activity);
		prepareViews();
		setCareListView();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		setCareListView();
		((Button) mParent.findViewById(R.id.title_but1)).setText("返回");
		mParent.findViewById(R.id.title_but1).setOnClickListener(this);
		((ImageView)mParent.findViewById(R.id.title_text_img)).setVisibility(View.GONE);
		mTitleButton2.setVisibility(View.VISIBLE);
		mTitle.setText("我的关注");
		mTitle.setOnClickListener(null);
		mTitleButton2.setOnClickListener(this);
		mTitleButton2.setText("多选");
		selectMode = false;
		setSeletView();
	}

	private static final int HANDLER_SAVE_WHAT = 100;
	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_SAVE_WHAT) {
				UserBean bean = (UserBean) msg.obj;
				if (bean != null) {
					String info = MessageFormat.format(
							getString(R.string.contact_saving_template),
							bean.name, msg.arg1, msg.arg2);
					mAlertDialog.setMessage(info);
				} else {
					mAlertDialog.dismiss();
					mAlertDialog = null;
					BaseApp.showToast(R.string.contact_save_succeed);
				}
			} else if (msg.what == HANDLER_PHOTO_RESULT) {
				PhotoBean bean = (PhotoBean) msg.obj;
				if (bean == null) {
				} else {
					LogUtil.e("下载到图片啦！！！");
					Bitmap bitmap = ImageUtils.stringtoBitmap(bean.photo);
					if (bitmap != null) {
						ImageUtils.saveMyBitmap(bitmap, Constans.IMG_DIR
								+ bean.id);
						bitmap.recycle();
						if (mCareListAdapter != null)
							mCareListAdapter.notifyDataSetChanged();
					} else {
					}
				}
			}
		}
	};

	private void prepareViews() {
		mParent = (ContactTabActivity) getParent();
		mParent.findViewById(R.id.title_but1).setOnClickListener(this);
		mListView = (MyListView) findViewById(R.id.care_list);
		mTitle = (TextView) mParent.findViewById(R.id.title_text);
		mTitleButton2 = (Button) mParent.findViewById(R.id.title_but2);
		mTitleButton1 = (Button) mParent.findViewById(R.id.title_but1);
		// head = LayoutInflater.from(this).inflate(
		// R.layout.contact_care_list_header, null);
		viewSelectAll = findViewById(R.id.contact_selectall_view);
		viewSelectAll.setOnClickListener(this);
		mCheckBox = ((CheckBox) findViewById(R.id.contact_selectall_check));
		mCheckBox.setOnCheckedChangeListener(this);
		// mListView.addHeaderView(head, null, true);
		// head.setVisibility(View.GONE);
		mListView.setOnItemClickListener(this);
		setSeletView();

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.title_but1:
			if(selectMode){
				selectMode = false;
				setSeletView();
			}else{
				finish();
			}
			break;
		case R.id.title_but2:
			if (selectMode) {
				mSeletUserBeans = mCareListAdapter.getSeletUserBeans();
				// LogUtil.e("selec user-->" + mSeletUserBeans.size());
				// LogUtil.e("adapter-->" + mCareListAdapter.getCount());
				if (mSeletUserBeans.size() <= 0) {
					BaseApp.showToast("未选择联系人");
					return;
				}
				if (selectType == 0) {
					bitchSave();
				} else if (selectType == 1) {
					ContactUtils.bitchSendMSM(this, mSeletUserBeans);
				} else if (selectType == 2) {
					CareListBean.getInstance().cancelCare(mSeletUserBeans);
					setCareListView();
				}
				selectMode = false;
				setSeletView();

			} else {
				popMenuWindow(mTitleButton2);
			}
			break;
		case R.id.contacts_menu_save:
			if (mCareListAdapter == null || mCareListAdapter.getCount() <= 0) {
				BaseApp.showToast("没有联系人供选择");
				return;
			}
			selectMode = true;
			selectType = 0;
			setSeletView();
			mPopupMenuWindow.dismiss();
			break;
		case R.id.contacts_menu_send:
			if (mCareListAdapter == null || mCareListAdapter.getCount() <= 0) {
				BaseApp.showToast("没有联系人供选择");
				return;
			}
			selectMode = true;
			selectType = 1;
			setSeletView();
			mPopupMenuWindow.dismiss();
			break;
		case R.id.contacts_menu_favourite:
			if (mCareListAdapter == null || mCareListAdapter.getCount() <= 0) {
				BaseApp.showToast("没有联系人供选择");
				return;
			}
			selectMode = true;
			selectType = 2;
			setSeletView();
			mPopupMenuWindow.dismiss();
			break;
		case R.id.contact_selectall_view:
			mCheckBox.performClick();
			// mCheckBox.setChecked(!mCheckBox.isChecked());
			break;
		default:
			break;
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		if (parent.getId() == R.id.care_list) {
			if (selectMode) {
				mCareListAdapter.setSelect(position);
			} else {
				UserBean bean = mCareListAdapter.getItem(position);
				Intent intent = new Intent(this, ContactDetailActivity.class);
				intent.putExtra("user", bean);
				startActivity(intent);
			}
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch (buttonView.getId()) {
		case R.id.contact_selectall_check:
			if (mCareListAdapter != null)
				mCareListAdapter.setSeletAll(isChecked);
			break;
		default:
			break;

		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			finish();
			mParent.finish();
		}
		return super.onKeyDown(keyCode, event);
	}

	private void setCareListView() {
		mCareListBean = CareListBean.getInstance();
		CareListBean bean = new CareListBean();
		bean.mUserBeans.addAll(mCareListBean.mUserBeans);
		mCareListAdapter = new CareListAdapter(this, bean);
		mListView.setAdapter(mCareListAdapter);
		Bitmap bm;
		for (int i = 0, l = bean.mUserBeans.size(); i < l; i++) {
			UserBean userBean = bean.mUserBeans.get(i);
			bm = ImageUtils.getBitmap(Constans.IMG_DIR + userBean.photo);
			if (bm != null) {

			} else {
				WebServiceParamsUtils utils = new WebServiceParamsUtils();
				utils.addNameAndValue("imageId", userBean.photo + "");
				utils.addNameAndValue("sessionId",
						LoginBean.getInstance().sessionId + "");
				new ChinacdcThread(PhotoBean.class, utils.formatParams(),
						mHandler, HANDLER_PHOTO_RESULT).start();
			}
		}
	}

	private void setSeletView() {
		if (selectMode) {
			viewSelectAll.setVisibility(View.VISIBLE);
			// head.setVisibility(View.VISIBLE);
			mTitleButton2.setText("确认");
			mTitleButton1.setText("取消");
		} else {
			viewSelectAll.setVisibility(View.GONE);
			// head.setVisibility(View.GONE);
			mTitleButton2.setText("多选");
			mTitleButton1.setText("返回");
		}
		mCheckBox.setChecked(false);
		if (mCareListAdapter != null) {
			mCareListAdapter.selectMode = selectMode;
			mCareListAdapter.setSeletAll(false);
			// mCareListAdapter.notifyDataSetChanged();
		}
	}

	private void popMenuWindow(View parent) {
		if (mPopupMenuWindow != null) {
			mPopupMenuWindow.dismiss();
			mPopupMenuWindow = null;
		}
		if (mPopupMenuWindow == null) {
			View popView = LayoutInflater.from(this).inflate(
					R.layout.contacts_care_pop_menu, null);
			popView.findViewById(R.id.contacts_menu_save).setOnClickListener(
					this);
			popView.findViewById(R.id.contacts_menu_send).setOnClickListener(
					this);
			popView.findViewById(R.id.contacts_menu_favourite)
					.setOnClickListener(this);
			mPopupMenuWindow = new PopupWindow(popView,
					BaseApp.sScreenWidth * 2 / 3,
					(int) (BaseApp.sScreenHeight / 5.5f));
			mPopupMenuWindow.setTouchInterceptor(new OnTouchListener() {

				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
						mPopupMenuWindow.dismiss();
						return true;
					}
					return false;
				}
			});
			mPopupMenuWindow.setOnDismissListener(new OnDismissListener() {

				public void onDismiss() {
				}
			});
		}
		ColorDrawable cd = new ColorDrawable(-0000);
		mPopupMenuWindow.setBackgroundDrawable(cd);
		mPopupMenuWindow.update();
		mPopupMenuWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
		mPopupMenuWindow.setTouchable(true);
		mPopupMenuWindow.setOutsideTouchable(true);
		mPopupMenuWindow.setFocusable(true);
		mPopupMenuWindow.showAtLocation(parent,
				Gravity.TOP,
				(int) (BaseApp.sScreenWidth /3),
				(int) (1.35f * mTitleButton2.getBottom()));
//		mPopupMenuWindow.showAtLocation(parent,
//				(Gravity.BOTTOM - parent.getHeight()) | Gravity.LEFT,
//				BaseApp.sScreenWidth / 3,
//				(int) (1.2f * mTitleButton2.getBottom()));
	}

	private void bitchSave() {
		mSeletUserBeans = mCareListAdapter.getSeletUserBeans();
		if (mSeletUserBeans.size() <= 0) {
			BaseApp.showToast("未选择联系人");
			return;
		}
		if (mAlertDialog == null) {
			mAlertDialog = new AlertDialog.Builder(this)
					.setTitle(R.string.app_prompt).setMessage("").create();
			mAlertDialog.setOnCancelListener(new OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					// TODO Auto-generated method stub
					if (mSelectThread != null) {
						try {
							mSelectThread.interrupt();
							// mSelectThread.stop();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			});
			mAlertDialog.show();
			// bitchSave();
			new Thread(new Runnable() {

				public void run() {
					ArrayList<UserBean> list = new ArrayList<UserBean>();
					list.addAll(mSeletUserBeans);
					int len = list.size();
					for (int i = 0; i < len && !Thread.interrupted(); i++) {
						UserBean bean = list.get(i);
						Message msg = new Message();
						msg.obj = bean;
						msg.what = HANDLER_SAVE_WHAT;
						msg.arg1 = i + 1;
						msg.arg2 = len;
						mHandler.sendMessage(msg);
						try {
							ContactUtils.insertContact(bean);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					mHandler.sendEmptyMessage(HANDLER_SAVE_WHAT);
				}
			}).start();
		}
	}

}
