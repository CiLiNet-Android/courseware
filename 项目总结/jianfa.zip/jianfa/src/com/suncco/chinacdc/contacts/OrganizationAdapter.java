package com.suncco.chinacdc.contacts;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.OrganizationBean;

public class OrganizationAdapter extends BaseAdapter {

	private Context mContext;
	private ArrayList<OrganizationBean> mOrganizationListBean;
	public boolean selectMode = false;

	public OrganizationAdapter(Context context, ArrayList<OrganizationBean> bean) {
		this.mContext = context;
		this.mOrganizationListBean = bean;
	}

	public int getCount() {
		return mOrganizationListBean == null ? 0
				: mOrganizationListBean.size();
	}

	public OrganizationBean getItem(int position) {
		return mOrganizationListBean.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		TextView name;
		TextView count;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.contact_dir_item, null);
			holder = new ViewHolder();
			holder.name = (TextView) convertView
					.findViewById(R.id.organization_name);
			holder.count = (TextView) convertView.findViewById(R.id.user_count);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		OrganizationBean bean = getItem(position);
		holder.name.setText(bean.name);
		holder.count.setText(bean.count + "");
		return convertView;
	}

}
