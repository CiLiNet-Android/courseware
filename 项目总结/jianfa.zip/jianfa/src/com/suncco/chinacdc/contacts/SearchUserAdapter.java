package com.suncco.chinacdc.contacts;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.SearchUserListBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.utils.ContactUtils;
import com.suncco.chinacdc.utils.ImageLoader;

public class SearchUserAdapter extends BaseAdapter {

	private Context mContext;
	public SearchUserListBean mSearchUserListBean;

	public SearchUserAdapter(Context context, SearchUserListBean bean) {
		this.mContext = context;
		this.mSearchUserListBean = bean;
	}
	
	private OnClickListener mOnClickListener = new OnClickListener() {
		public void onClick(View v) {
			String phone = (String) v.getTag();
			if(!TextUtils.isEmpty(phone))
			ContactUtils.call(mContext,phone);
		}
	};

	public int getCount() {
		return mSearchUserListBean == null ? 0 : mSearchUserListBean.mUserBeans
				.size();
	}

	public UserBean getItem(int arg0) {
		return mSearchUserListBean.mUserBeans.get(arg0);
	}

	public long getItemId(int position) {
		return 0;
	}

	static class ViewHolder {
		ImageView photo;
		TextView name;
		TextView job;
		TextView phone;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.contact_leader_item, null);
			holder = new ViewHolder();
			holder.photo = (ImageView) convertView.findViewById(R.id.photo);
			holder.name = (TextView) convertView.findViewById(R.id.name);
			holder.job = (TextView) convertView.findViewById(R.id.job);
			holder.phone = (TextView) convertView.findViewById(R.id.phone);
			holder.phone.setOnClickListener(mOnClickListener);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		UserBean bean = getItem(position);
		holder.name.setText(bean.name);
		holder.job.setText(bean.job);
		holder.phone.setText(bean.phone1);
		holder.phone.setTag(bean.phone1);
		if (!TextUtils.isEmpty(bean.photo)) {

			Bitmap bm = null;
			//这里要纳入图片缓存体系中去.
//			bm = ImageUtils.getBitmap(Constans.IMG_DIR + bean.photo);
			bm = ImageLoader.getInstance().loadBitmapByPath(
					Constans.IMG_DIR + bean.photo);
			if (bm != null) {
				holder.photo.setImageBitmap(bm);
			} else {
				holder.photo.setImageResource(R.drawable.contact_default_img);			}
		}
		
		return convertView;
	}

}
