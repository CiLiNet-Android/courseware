package com.suncco.chinacdc.contacts;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.ViewFlipper;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.OrganizationBean;
import com.suncco.chinacdc.bean.PhotoBean;
import com.suncco.chinacdc.bean.SearchOranizationListBean;
import com.suncco.chinacdc.bean.SearchUserListBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.XListView;
import com.suncco.chinacdc.widget.XListView.IXListViewListener;

public class SearchActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener, OnEditorActionListener,
		OnCancelListener, IXListViewListener {

	private static final int HANDLER_SEARCH_USER_WHAT = 102;
	private static final int HANDLER_SEARCH_ORGANIZATION_WHAT = 103;
	private static final int HANDLER_PHOTO_RESULT = 104;
	private LoadingProgressDialog mProgress;
	private EditText mSearchText;
	private ViewFlipper mSearchListFlipper;
	private int mSearchType;
	private XListView mSearchUserListView;
	private XListView mSearchOrganizationListView;
	private ChinacdcThread mChinacdcThread;
	private SearchUserAdapter mSearchUserAdapter;
	private String mKeyword;
	
	private ContactTabActivity mParent;
	
	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			  if (msg.what == HANDLER_SEARCH_ORGANIZATION_WHAT) {
				mProgress.dismiss();
				SearchOranizationListBean bean = (SearchOranizationListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_load_exc);
					mSearchOrganizationListView.stopRefresh();
					mSearchOrganizationListView.stopLoadMore();
					mSearchOrganizationListView.setPullLoadEnable(false);
					
				} else {
					if (bean.code == 0) {
						if (mSearchOrganizationAdapter == null || mSearchOrganizationAdapter.mSearchOranizationListBean.getCurrentPage() < 1  ) {
							mSearchOrganizationAdapter = new SearchOrganizationAdapter(
									SearchActivity.this, bean);
							mSearchOrganizationListView
									.setAdapter(mSearchOrganizationAdapter);
						} else {
							mSearchOrganizationAdapter.mSearchOranizationListBean
									.addPage(bean);
							mSearchOrganizationAdapter.notifyDataSetChanged();
						}
						hasNextPageOrganize();
					} else {
//						BaseApp.showToast(bean.message);
						mSearchOrganizationListView.stopRefresh();
						mSearchOrganizationListView.stopLoadMore();
						mSearchOrganizationListView.setPullLoadEnable(false);
						BaseApp.showSessionnDialog(SearchActivity.this, bean);
					}
				}
			} else if (msg.what == HANDLER_SEARCH_USER_WHAT) {
				mProgress.dismiss();
				SearchUserListBean bean = (SearchUserListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_load_exc);
					mSearchUserListView.stopRefresh();
					mSearchUserListView.stopLoadMore();
					mSearchUserListView.setPullLoadEnable(false);
				} else {
					if (bean.code == 0) {
						if (mSearchUserAdapter == null || mSearchUserAdapter.mSearchUserListBean.getCurrentPage() < 1) {
							
							mSearchUserAdapter = new SearchUserAdapter(
									SearchActivity.this, bean);
							mSearchUserListView.setAdapter(mSearchUserAdapter);
							getPhoto(bean);
							
						} else {
							mSearchUserAdapter.mSearchUserListBean
									.addPage(bean);
							mSearchUserAdapter.notifyDataSetChanged();
							getPhoto(bean);
						}
						hasNextPageUser();
					} else {
						mSearchUserListView.stopRefresh();
						mSearchUserListView.stopLoadMore();
						mSearchUserListView.setPullLoadEnable(false);
						BaseApp.showSessionnDialog(SearchActivity.this, bean);
					}
				}
			}else if(msg.what == HANDLER_PHOTO_RESULT){
				PhotoBean bean = (PhotoBean) msg.obj;
				if (bean == null) {
				} else {
					LogUtil.e("下载到图片啦！！！");
					Bitmap bitmap = ImageUtils.stringtoBitmap(bean.photo);
					if (bitmap != null) {
						ImageUtils.saveMyBitmap(bitmap, Constans.IMG_DIR
								+ bean.id);
						bitmap.recycle(); 
						if (mSearchUserAdapter != null)
							mSearchUserAdapter.notifyDataSetChanged();
					} else {
					}
				}
				
				if(mSearchUserAdapter != null)mSearchUserAdapter.notifyDataSetChanged();
			}
		};
	};

	private void hasNextPageUser() {
			mSearchUserListView.stopRefresh();
			mSearchUserListView.stopLoadMore();
			if (!mSearchUserAdapter.mSearchUserListBean.hasNextPage()) {
				LogUtil.i("没下一页了");
				mSearchUserListView.setPullLoadEnable(false);
			} else {
				LogUtil.i("还有下一页");
				mSearchUserListView.setPullLoadEnable(true);
			}
	}
	
	private void hasNextPageOrganize() {
			mSearchOrganizationListView.stopRefresh();
			mSearchOrganizationListView.stopLoadMore();
			if (!mSearchOrganizationAdapter.mSearchOranizationListBean
					.hasNextPage()) {
				LogUtil.i("没下一页了");
				mSearchOrganizationListView.setPullLoadEnable(false);
			} else {
				LogUtil.i("还有下一页");
				mSearchOrganizationListView.setPullLoadEnable(true);
			}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contacts_search_activity);
		prepareView();
//		mProgress.show();
//		getOrganizationList(getIntent().getStringExtra("org_id"));
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		((TextView)mParent.findViewById(R.id.title_text)).setText("搜索");
		((TextView)mParent.findViewById(R.id.title_text)).setOnClickListener(null);
		mParent.findViewById(R.id.title_but2).setVisibility(View.INVISIBLE);
		mParent.findViewById(R.id.title_but1).setOnClickListener(this);
		((ImageView)mParent.findViewById(R.id.title_text_img)).setVisibility(View.GONE);
		((Button)mParent.findViewById(R.id.title_but1)).setText("返回");
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.title_but1:
			finish();
			break;
		case R.id.search_edit:
			
			break;
		case R.id.search_left_but:
			changeSearchType(0);
			mSearchText.setHint("姓名、电话、邮箱");
			break;
		case R.id.search_right_but:
			changeSearchType(1);
			mSearchText.setHint("组织名称");
			break;
		default:
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
//			if (mSearchFlipper.getCurrentView().getId() == R.id.search_view) {
//				mSearchFlipper.showNext();
//				findViewById(R.id.back).setVisibility(View.VISIBLE);
////				findViewById(R.id.contacts_menu).setVisibility(View.VISIBLE);
//				mTitleName.setText(getIntent().getStringExtra("org_name"));
//				return true;
//			}
			finish();
			mParent.finish();
		}
		return super.onKeyDown(keyCode, event);
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		 if (parent.getId() == R.id.search_user_list) {
			if (mSearchType == 0) {
				if(position == 0)return;
				if(mSearchUserAdapter == null)return;
				UserBean bean = mSearchUserAdapter.getItem(position - 1);
				Intent intent = new Intent(this, ContactDetailActivity.class);
				intent.putExtra("user", bean);
				startActivity(intent);
			} else {
				if(mSearchOrganizationAdapter == null)return;
				OrganizationBean bean = mSearchOrganizationAdapter
						.getItem(position - 1);
				Intent intent = new Intent(this, SearchActivity.class);
				intent.putExtra("org_id", bean.id);
				intent.putExtra("org_name", bean.name);
				startActivity(intent);
			}
		}else if(parent.getId() == R.id.search_organization_list){
			if(position == 0)return;
			if(mSearchOrganizationAdapter == null)return;
			OrganizationBean bean = mSearchOrganizationAdapter
					.getItem(position - 1);
			OrganizationActivity.mSearchOrganizationBean = bean;
			mParent.mMainTabBut2.performClick();
		}
	}

	public void onCancel(DialogInterface dialog) {
		if (mChinacdcThread != null) {
			mChinacdcThread.cancel();
		}
	}

	public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
//		mKeyword = mSearchText.getText().toString().trim();
		String keyWord = mSearchText.getText().toString().trim();
		LogUtil.e("onEditorAction------>" + actionId);
//		if(actionId != EditorInfo.IME_ACTION_NEXT) return false;
		if(mChinacdcThread!= null && mChinacdcThread.isAlive())return false;
		if (!TextUtils.isEmpty(keyWord)) {
			if (mSearchType == 0) {
				mSearchUserAdapter = null;
				mSearchUserListView.setAdapter(null);
				mProgress.show();
				searchUsers(keyWord);
			} else {
				mSearchOrganizationAdapter = null;
				mSearchOrganizationListView.setAdapter(null);
				mProgress.show();
				searchOrganization(keyWord);
			}
		} else {
			BaseApp.showToast(R.string.contact_search_exc);
		}
		return true;
	}

	private void searchUsers(String keyword) {
		int page = 1;
		LogUtil.e(""+keyword + mKeyword);
		if (mSearchUserAdapter != null && keyword.equals(mKeyword)) {
			page = mSearchUserAdapter.mSearchUserListBean.getCurrentPage() + 1;
		}else{
			mKeyword =new String(keyword);
		}
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("keyWord", keyword);
		utils.addNameAndValue("numPerpage", Constans.PAGE_SIZE + "");
		utils.addNameAndValue("page", page + "");
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		mChinacdcThread = new ChinacdcThread(SearchUserListBean.class,
				utils.formatParams(), mHandler, HANDLER_SEARCH_USER_WHAT);
		mChinacdcThread.start();
	}

	private SearchOrganizationAdapter mSearchOrganizationAdapter;

	private void searchOrganization(String keyword) {
		int page = 1;
		if (mSearchOrganizationAdapter != null && keyword.equals(mKeyword)) {
			page = mSearchOrganizationAdapter.mSearchOranizationListBean
					.getCurrentPage() + 1;
		}else{
			mKeyword =new String(keyword);
		}
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("keyWord", keyword);
		utils.addNameAndValue("numPerpage", Constans.PAGE_SIZE + "");
		utils.addNameAndValue("page", page + "");
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		mChinacdcThread = new ChinacdcThread(SearchOranizationListBean.class,
				utils.formatParams(), mHandler,
				HANDLER_SEARCH_ORGANIZATION_WHAT);
		mChinacdcThread.start();
	}

	private void changeSearchType(int type) {
//		if (mChinacdcThread != null) {
//			mChinacdcThread.cancel();
//		}
		if (mSearchType != type) {
			mSearchType = type;
//			mKeyword = "";
//			mSearchText.setText("");
			View backgroup = findViewById(R.id.search_type_view);
			if (mSearchType == 0) {
				backgroup
						.setBackgroundResource(R.drawable.search_left_seleted_but);
			} else {
				backgroup
						.setBackgroundResource(R.drawable.search_right_seelted_but);
			}
			mSearchListFlipper.showNext();
		}
	}




	private void prepareView() {
		mParent = (ContactTabActivity) getParent();
		mParent.findViewById(R.id.title_but1).setOnClickListener(this);
		mProgress = new LoadingProgressDialog(this);
		mProgress.setOnCancelListener(this);
		mSearchText = (EditText) findViewById(R.id.search_edit);
		mSearchText.setOnEditorActionListener(this);
		mSearchText.setOnClickListener(this);
		mSearchText.setOnFocusChangeListener(new OnFocusChangeListener() {
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				View backgroup = findViewById(R.id.search_type_view);
				if(hasFocus){
					backgroup.setVisibility(View.VISIBLE);
				}else{
					backgroup.setVisibility(View.GONE);
				}
			}
		});
		findViewById(R.id.search_left_but).setOnClickListener(this);
		findViewById(R.id.search_right_but).setOnClickListener(this);
		mSearchUserListView = (XListView) findViewById(R.id.search_user_list);
		mSearchUserListView.setOnItemClickListener(this);
		mSearchUserListView.setPullRefreshEnable(true);
		mSearchUserListView.setPullLoadEnable(true);
		mSearchUserListView.setXListViewListener(this);
		mSearchListFlipper = (ViewFlipper) findViewById(R.id.search_list_flipper);
		mSearchOrganizationListView = (XListView) findViewById(R.id.search_organization_list);
		mSearchOrganizationListView.setOnItemClickListener(this);
		mSearchOrganizationListView.setPullRefreshEnable(true);
		mSearchOrganizationListView.setPullLoadEnable(true);
		mSearchOrganizationListView.setXListViewListener(this);
	}


	public void onRefresh() {
		if (mSearchType == 0) {
//			mSearchUserAdapter = null;
			String keyWord = new String(mKeyword);
			mKeyword = "";
			searchUsers(keyWord);
		} else {
//			mSearchOrganizationAdapter = null;
			String keyWord = new String(mKeyword);
			mKeyword = "";
			searchOrganization(keyWord);
		}
	}

	public void onLoadMore() {
		if (mSearchType == 0) {
			searchUsers(mKeyword);
		} else {
			searchOrganization(mKeyword);
		}
	}
	
	private void getPhoto(final SearchUserListBean bean){
		mHandler.post(new Runnable() {
			public void run() {
				// TODO Auto-generated method stub
				Bitmap bm = null;
				for (int i = 0, l = bean.mUserBeans.size(); i < l; i++) {
					UserBean userBean = bean.mUserBeans.get(i);
					
					bm = ImageUtils.getBitmap(Constans.IMG_DIR + userBean.photo);
					if (bm != null) {

					} else {
						WebServiceParamsUtils utils = new WebServiceParamsUtils();
						utils.addNameAndValue("imageId", userBean.photo + "");
						utils.addNameAndValue("sessionId",
								LoginBean.getInstance().sessionId + "");
						new ChinacdcThread(PhotoBean.class, utils.formatParams(),
								mHandler, HANDLER_PHOTO_RESULT).start();
					}
				}
			}
		});
	}
	
}
