package com.suncco.chinacdc;

import java.text.MessageFormat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;

import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.SettingsBean;
import com.suncco.chinacdc.bean.StateCheckBean;
import com.suncco.chinacdc.login.LoginActivity;
import com.suncco.chinacdc.menu.MenuActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;

/**
 * 欢迎页面
 * 
 * @author suncco 10036 2012-10-11
 */
public class LoadingActivity extends Activity {

	private ChinacdcThread mChinacdcThread;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loading_activity);
		checkState();
		BaseApp mBaseApp = (BaseApp) getApplication();
		mBaseApp.setIsProgramExist(false);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (mChinacdcThread != null) {
				mChinacdcThread.cancel();
			}
		}
		return super.onKeyDown(keyCode, event);
	}

	private void checkState() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("uuid", BaseApp.sOnlyMark);
		new ChinacdcThread(StateCheckBean.class, utils.formatParams(),
				mHandler, 1).start();
	}

	private void startApp() {
		boolean isAutoLogin = Constans.TRUE.equals(SettingsBean.getInstance()
				.getSettingValueByName(Constans.AUTO_LOGIN));
		isAutoLogin = false;
//		isAutoLogin = true;
		if (!isAutoLogin) {
			startLoginActivity();
			LogUtil.i("进入登入页面");
		} else {
			autoLogin();
			LogUtil.i("测试自动登入");
		}
	}

	private void autoLogin() {
		String userName = SettingsBean.getInstance().getSettingValueByName(
				Constans.USER_NAME);
		String password = SettingsBean.getInstance().getSettingValueByName(
				Constans.PASSWORD);
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("username", userName);
		utils.addNameAndValue("password", password);
		utils.addNameAndValue("uuid", BaseApp.sOnlyMark);
		mChinacdcThread = new ChinacdcThread(LoginBean.class,
				utils.formatParams(), mHandler, 0);
		mChinacdcThread.start();
	}

	private void onLoingSucceed() {
		Intent intent = new Intent(this, MenuActivity.class);
		startActivity(intent);
		finish();
	}

	private void startLoginActivity() {
		Intent intent = new Intent(this, LoginActivity.class);
		startActivity(intent);
		finish();
	}

	private void netExceptionDialog() {
		if(this.isFinishing()){
			return;
		}
		DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if (which == DialogInterface.BUTTON_POSITIVE) {
					checkState();
				} else if (which == DialogInterface.BUTTON_NEGATIVE) {
					finish();
				}
			}
		};
		new AlertDialog.Builder(this).setTitle(R.string.app_warn)
				.setMessage(R.string.app_net_exc)
				.setPositiveButton(R.string.app_net_reapte, listener)
				.setNegativeButton(R.string.app_exit, listener).show();
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == 0) {
				LoginBean loginBean = (LoginBean) msg.obj;
				if (loginBean != null) {
					if (loginBean.code == 0) {
						BaseApp.showToast(MessageFormat.format(
								getString(R.string.app_login_succeed_msg),
								loginBean.name));
						onLoingSucceed();
					} else {
						SettingsBean.getInstance().delSettingValue(
								Constans.USER_NAME);
						SettingsBean.getInstance().delSettingValue(
								Constans.PASSWORD);
						SettingsBean.save();
						startLoginActivity();
					}
				} else {
					startLoginActivity();
				}
			} else if (msg.what == 1) {
				StateCheckBean bean = (StateCheckBean) msg.obj;
				if (bean == null) {
					netExceptionDialog();
				} else {
					if (bean.code == 0 && bean.status == 0) {
						startApp();
					} else {
						BaseApp.showToast(bean.message);
						finish();
					}
				}
			}
		};
	};
}