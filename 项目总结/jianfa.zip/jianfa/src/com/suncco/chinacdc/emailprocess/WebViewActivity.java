package com.suncco.chinacdc.emailprocess;

import java.io.File;
import java.net.URL;
import java.net.URLEncoder;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.ConsoleMessage;
import android.webkit.DownloadListener;
import android.webkit.HttpAuthHandler;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.SettingsBean;
import com.suncco.chinacdc.utils.FileDownloadThread;
import com.suncco.chinacdc.utils.FileUtils;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.MySharedPreferences;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.umeng.analytics.MobclickAgent;

public class WebViewActivity extends BaseActivity implements OnClickListener,
		DownloadListener {
	private final int HANDLER_FILEDOWNLOAD = 101;
	
	
	WebView mWebView;
	LoadingProgressDialog myProgressDialog;
	SettingsBean mSettingsBean;
	boolean isUseCache = true;
	
	boolean isAutoLogin = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview_activity);
		prepareViews();
		initUrl();
		MobclickAgent.onEvent(this, UmengEvent.intoCoreMailEvent);
	}

	 private Handler mHandler = new Handler() {
	 public void handleMessage(Message msg) {
	 // TODO Auto-generated method stub
	 super.handleMessage(msg);
	 switch(msg.what){
	 case HANDLER_FILEDOWNLOAD:
		 String path = (String) msg.obj;
		 File file = new File(path);
		 if(file.exists()){
			 FileUtils.openFile(file, WebViewActivity.this);
		 }else{
			 BaseApp.showToast("文件下载失败");
		 }
		 break;
	 }
	 
	 
	 }
	
	 };

	private void prepareViews() {
//		mSettingsBean = SettingsBean.getInstance();
//		// isUseCache = false;
//		if (mSettingsBean.getSettingValueByName("isUseCache", 0) == 0) {
//			isUseCache = false;
//			mSettingsBean.putSettingValue("isUseCache", "1");
//			mSettingsBean.save();
//			WebViewDatabase.getInstance(this).clearUsernamePassword();
//			WebViewDatabase.getInstance(this).clearFormData();
//			WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword();
//		}
		myProgressDialog = new LoadingProgressDialog(this);
		findViewById(R.id.web_finish).setOnClickListener(this);
		findViewById(R.id.web_back).setOnClickListener(this);
		findViewById(R.id.web_foward).setOnClickListener(this);
		mWebView = (WebView) findViewById(R.id.web_webview);
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setSupportZoom(true);
		WebSettings set = mWebView.getSettings();
		set.setAllowFileAccess(true);
//		if (isUseCache) {
//			mWebView.getSettings().setCacheMode(
//					WebSettings.LOAD_CACHE_ELSE_NETWORK);
//			mWebView.getSettings().setSaveFormData(true);
//			mWebView.getSettings().setSavePassword(true);
//		} else {
//
//		}
		mWebView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
		mWebView.setSaveEnabled(true);
		mWebView.setDownloadListener(this);
		mWebView.requestFocus();
		// mWebView.addJavascriptInterface(new Object() {
		// public void clickOnAndroid(String msg) { // 用于接收的方法
		// final String ms = msg;
		// mHandler.post(new Runnable() {
		// public void run() {
		// Log.v("-----------", ms);
		// if (!ms.equals("false")) {
		// Log.v("-----------", ms);
		// }
		// }
		// });
		// }
		// }, "demo");
		mWebView.addJavascriptInterface(new MyJavaScriptInterface(), "HTMLOUT");
		mWebView.setWebChromeClient(new MyWebChromeClient());
		mWebView.setWebViewClient(new MyWebViewClient());
		// String wapurl = "http://bobing.xiamentd.com/?clientkey={$clientkey}";
		// if (Constans.mUserBean != null) {
		// wapurl = wapurl.replace("{$clientkey}",
		// Constans.mUserBean.sessionid);
		// }
		// mWebView.loadUrl(wapurl);
	}

	private void initUrl() {
		String wapurl = getIntent().getStringExtra("url");
		if (wapurl == null || wapurl.equals("")) {
			BaseApp.showToast("网页地址不存在");
		}
		LogUtil.e("load url---->" + wapurl);
		mWebView.loadUrl(wapurl);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (mWebView.canGoBack() && event.getKeyCode() == KeyEvent.KEYCODE_BACK
				&& event.getRepeatCount() == 0) {
			if (myProgressDialog.isShowing()) {
				myProgressDialog.dismiss();
			} else {
				mWebView.goBack();
			}
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	class MyWebViewClient extends WebViewClient {
		String loginCookie;

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			// TODO Auto-generated method stub
			LogUtil.e("shouldOverrideUrlLoading-->" + url);
			if (URLUtil.isNetworkUrl(url)) {

				mWebView.loadUrl(url);
			} else {
				return super.shouldOverrideUrlLoading(view, url);
			}
			return true;
		}

		@Override
		public void onLoadResource(WebView view, String url) {
			// TODO Auto-generated method stub
			// CookieManager cookieManager = CookieManager.getInstance();
			// loginCookie = cookieManager.getCookie(url);
			LogUtil.e("onLoadResource-->" + url);
			super.onLoadResource(view, url);
		}

		@Override
		public void onFormResubmission(WebView view, Message dontResend,
				Message resend) {
			// TODO Auto-generated method stub
			LogUtil.e("onFormResubmission-->" + resend.what);
			super.onFormResubmission(view, dontResend, resend);
		}

		@Override
		public void onReceivedHttpAuthRequest(WebView view,
				HttpAuthHandler handler, String host, String realm) {
			// TODO Auto-generated method stub
			LogUtil.e("onReceivedHttpAuthRequest-->" + realm);
			super.onReceivedHttpAuthRequest(view, handler, host, realm);
		}

		@Override
		public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
			// TODO Auto-generated method stub
			return super.shouldOverrideKeyEvent(view, event);
		}

		@Override
		public void onPageFinished(WebView view, String url) {
			// TODO Auto-generated method stub
			// CookieManager cookieManager = CookieManager.getInstance();
			// cookieManager.setCookie(url, loginCookie);
			LogUtil.e("onPageFinished-->" + url);
			if (myProgressDialog != null) {
				myProgressDialog.dismiss();
			}
			// mWebView.loadUrl("javascript:window.HTMLOUT.showHTML('<head>'+document.getElementsById('username')[0].innerHTML+'</head>');");
			
			if (url.equals(LoginBean.getInstance().xphoneUrl) && isAutoLogin) {
				MySharedPreferences sp = new MySharedPreferences(
						WebViewActivity.this);
				if (sp.getEmailName() != null) {
					mWebView.loadUrl("javascript:document.getElementById('username').value='"
							+ sp.getEmailName() + "';");
					mWebView.loadUrl("javascript:document.getElementById('password').value='"
							+ sp.getEmailPassword() + "';");

					mWebView.loadUrl("javascript:document.forms[0].submit();");
				}
				isAutoLogin = false;
			}
			super.onPageFinished(view, url);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// TODO Auto-generated method stub
			LogUtil.e("onPageStarted-->" + url);
			if (myProgressDialog != null && !WebViewActivity.this.isFinishing()) {
				myProgressDialog.show();
			}
			if (url.equals("http://mail.chinacdc.com/coremail/login.jsp")){
				mWebView.loadUrl("javascript:window.HTMLOUT.showHTML(document.getElementById('username').value+';'+document.getElementById('password').value);");
			}
			// mWebView.loadUrl("javascript:window.HTMLOUT.showHTML('<head>'+document.getElementsByTagName('html')[0].innerHTML+'</head>');");
			super.onPageStarted(view, url, favicon);
		}

		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler,
				SslError error) {
			// TODO Auto-generated method stub
			super.onReceivedSslError(view, handler, error);
		}

	}

	private class MyWebChromeClient extends WebChromeClient {

		public MyWebChromeClient() {
			super();
		}

		@Override
		public boolean onJsAlert(WebView view, String url, String message,
				JsResult result) {
			// TODO Auto-generated method stub
			LogUtil.e("onJsAlert--->" + url + "  message-》" + message
					+ "  result-->" + result);
			return super.onJsAlert(view, url, message, result);
		}

		@Override
		public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
			// TODO Auto-generated method stub
			LogUtil.e("onConsoleMessage---》" + consoleMessage.message());
			return super.onConsoleMessage(consoleMessage);
		}

		@Override
		public void onConsoleMessage(String message, int lineNumber,
				String sourceID) {
			// TODO Auto-generated method stub
			LogUtil.e("onConsoleMessage---》" + message);
			super.onConsoleMessage(message, lineNumber, sourceID);
		}

		@Override
		public boolean onJsBeforeUnload(WebView view, String url,
				String message, JsResult result) {
			// TODO Auto-generated method stub
			LogUtil.e("onJsBeforeUnload--->" + url + "  message-》" + message
					+ "  result-->" + result);
			return super.onJsBeforeUnload(view, url, message, result);
		}

		@Override
		public boolean onJsConfirm(WebView view, String url, String message,
				JsResult result) {
			// TODO Auto-generated method stub
			LogUtil.e("onJsConfirm--->" + url + "  message-》" + message
					+ "  result-->" + result);
			return super.onJsConfirm(view, url, message, result);
		}

		@Override
		public boolean onJsPrompt(WebView view, String url, String message,
				String defaultValue, JsPromptResult result) {
			// TODO Auto-generated method stub
			LogUtil.e("onJsPrompt--->" + url + "  message-》" + message
					+ "  result-->" + result);
			return super.onJsPrompt(view, url, message, defaultValue, result);
		}

	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.web_finish:
			mWebView.setWebViewClient(null);
			mWebView.destroy();
			finish();
			break;
		case R.id.web_back:
			mWebView.goBack();
			break;
		case R.id.web_foward:
			if (mWebView.canGoForward())
				mWebView.goForward();
			break;
		default:
			break;
		}
	}

	class MyJavaScriptInterface

	{

		@SuppressWarnings("unused")
		public void showHTML(String str) {
			// new AlertDialog.Builder(WebViewActivity.this).setTitle("HTML")
			// .setMessage(str)
			// .setPositiveButton(android.R.string.ok, null)
			// .setCancelable(false).create().show();
			try {
				String[] strs = str.split(";");
				// BaseApp.showToast("账户："+strs[0] + "\n"+"密码" +strs[1]);
				MySharedPreferences sp = new MySharedPreferences(
						WebViewActivity.this);
				sp.putEmailName(strs[0]);
				sp.putEmailPassword(strs[1]);
			} catch (Exception e) {
			}

		}

	}

	@Override
	public void onDownloadStart(String url, String userAgent, String contentDisposition,
			String mimetype, long contentLength) {
		// TODO Auto-generated method stub
//		Uri uri = Uri.parse(url);
		LogUtil.e("url--------->"+ url);
		LogUtil.e("contentLength--------->"+ contentLength);
		LogUtil.e("contentDisposition--------->"+ contentDisposition);
		LogUtil.e("userAgent--------->"+ userAgent);
//		Intent intent = new Intent(Intent.ACTION_VIEW, uri);
//		intent.putExtra(mimetype, mimetype);
//		intent.putExtra(userAgent, userAgent);
//		intent.putExtra(contentDisposition, contentDisposition);
//		intent.putExtra("contentLength", contentDisposition);
//		startActivity(intent);
		String fileName =  contentDisposition.substring(contentDisposition.indexOf("filename=\"")+10, contentDisposition.indexOf("\"", contentDisposition.indexOf("filename=")+11));
		LogUtil.e("fileName---->" + fileName);
		String path = Constans.DOWNLOAD_DIR+fileName;
		startDownloadFile(url,path);
	}
	
	private void startDownloadFile(String url,String path){
		myProgressDialog.show();
		new FileDownloadThread(mHandler, url, path, HANDLER_FILEDOWNLOAD).start();
	}

}
