package com.suncco.chinacdc.login;

import java.text.MessageFormat;

import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.SettingsBean;
import com.suncco.chinacdc.menu.MenuActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.SystemParamsUtils;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;

/**
 * 登录
 * 
 * @author suncco 10036 2012-10-11
 */
public class LoginActivity extends BaseActivity implements OnClickListener,
		OnCheckedChangeListener, OnCancelListener {

	EditText mUserText;
	EditText mPasswordText;
	LoadingProgressDialog mProgress;
	ChinacdcThread mChinacdcThread;

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			mProgress.dismiss();
			LoginBean bean = (LoginBean) msg.obj;
			if (bean == null) {
				BaseApp.showToast(R.string.app_load_exc);
			} else {
				if (bean.code == 0) {
					onLoginSucceed(bean);
				} else {
					BaseApp.showToast(bean.message);
				}
			}
		};
	};

	protected void onCreate(android.os.Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_activity);
		prepareView();
	}

	private void prepareView() {
		findViewById(R.id.login_button).setOnClickListener(this);
		mUserText = (EditText) findViewById(R.id.login_user);
		mPasswordText = (EditText) findViewById(R.id.login_password);
		mProgress = new LoadingProgressDialog(this);
		mProgress.setOnCancelListener(this);
		initCacheValue();
	}

	private void initCacheValue() {
		boolean isRememberPassword = Constans.TRUE.equals(SettingsBean
				.getInstance()
				.getSettingValueByName(Constans.REMEMBER_PASSWORD));
		boolean isAutoLogin = Constans.TRUE.equals(SettingsBean.getInstance()
				.getSettingValueByName(Constans.AUTO_LOGIN));
		isRememberPassword = true;
		isAutoLogin = false;
		CheckBox remember = ((CheckBox) findViewById(R.id.login_remember));
		remember.setChecked(isRememberPassword);
		remember.setOnCheckedChangeListener(this);
		CheckBox auto = ((CheckBox) findViewById(R.id.login_auto));
		auto.setChecked(isAutoLogin);
		auto.setOnCheckedChangeListener(this);
		if (isAutoLogin || isRememberPassword) {
			String userName = SettingsBean.getInstance().getSettingValueByName(
					Constans.USER_NAME);
			String password = SettingsBean.getInstance().getSettingValueByName(
					Constans.PASSWORD);
			mUserText.setText(userName);
//			mPasswordText.setText(password);
		}
	}

	private void onLoginSucceed(LoginBean bean) {
		BaseApp.showToast(MessageFormat.format(
				getString(R.string.app_login_succeed_msg), bean.name));
		boolean isRememberPassword = Constans.TRUE.equals(SettingsBean
				.getInstance()
				.getSettingValueByName(Constans.REMEMBER_PASSWORD));
		boolean isAutoLogin = Constans.TRUE.equals(SettingsBean.getInstance()
				.getSettingValueByName(Constans.AUTO_LOGIN));
		isRememberPassword = true;
		isAutoLogin = false;
		if (isRememberPassword || isAutoLogin) {
			SettingsBean.getInstance().putSettingValue(Constans.USER_NAME,
					mUserText.getText().toString().trim());
			SettingsBean.getInstance().putSettingValue(Constans.PASSWORD,
					mPasswordText.getText().toString());
		}
		SettingsBean.save();
		Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
		startActivity(intent);
		finish();
	}

	public void onClick(View v) {
		if (v.getId() == R.id.login_button) {
			String user = mUserText.getText().toString().trim();
			String password = mPasswordText.getText().toString();
			if (TextUtils.isEmpty(user)) {
				BaseApp.showToast(R.string.login_exc1);
			} else if (TextUtils.isEmpty(password)) {
				BaseApp.showToast(R.string.login_exc2);
			} else {
				WebServiceParamsUtils utils = new WebServiceParamsUtils();
				utils.addNameAndValue("username", user);
				utils.addNameAndValue("password", password);
				utils.addNameAndValue("uuid", BaseApp.sOnlyMark);
				utils.addNameAndValue("model", SystemParamsUtils.getPhoneModel()+"");
				utils.addNameAndValue("systemVersion", SystemParamsUtils.getPhoneRelease()+"");
				mProgress.show();
				mChinacdcThread = new ChinacdcThread(LoginBean.class,
						utils.formatParams(), mHandler, 0);
				mChinacdcThread.start();
			}
		}
	};

	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (buttonView.getId() == R.id.login_remember) {
			SettingsBean.getInstance().putSettingValue(
					Constans.REMEMBER_PASSWORD,
					isChecked ? Constans.TRUE : Constans.FLASE);
		} else {
			SettingsBean.getInstance().putSettingValue(Constans.AUTO_LOGIN,
					isChecked ? Constans.TRUE : Constans.FLASE);
		}
		SettingsBean.save();
		boolean isRememberPassword = Constans.TRUE.equals(SettingsBean
				.getInstance()
				.getSettingValueByName(Constans.REMEMBER_PASSWORD));
		boolean isAutoLogin = Constans.TRUE.equals(SettingsBean.getInstance()
				.getSettingValueByName(Constans.AUTO_LOGIN));
		if (!isAutoLogin && !isRememberPassword) {
			SettingsBean.getInstance().delSettingValue(Constans.USER_NAME);
			SettingsBean.getInstance().delSettingValue(Constans.PASSWORD);
			SettingsBean.save();
		}
	}

	public void onCancel(DialogInterface dialog) {
		if (mChinacdcThread != null) {
			mChinacdcThread.cancel();
		}
	}
}
