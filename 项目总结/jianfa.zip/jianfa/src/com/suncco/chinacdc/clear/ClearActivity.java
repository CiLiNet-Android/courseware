package com.suncco.chinacdc.clear;

import java.io.File;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ListView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ChannelListBean;
import com.suncco.chinacdc.bean.ClearFileBean;
import com.suncco.chinacdc.bean.DownloadListBean;
import com.suncco.chinacdc.bean.FavourListBean;
import com.suncco.chinacdc.bean.FavourListBeanMarket;
import com.suncco.chinacdc.bean.FavourListBeanOffice;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.MagazineListBean;
import com.suncco.chinacdc.bean.OrganizationListBean;
import com.suncco.chinacdc.utils.ImageLoader;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.MySharedPreferences;
import com.suncco.chinacdc.widget.LoadingProgressDialog;

@SuppressLint("HandlerLeak")
public class ClearActivity extends BaseActivity implements OnClickListener {

	ListView mListView;
	LoadingProgressDialog mProgress;
	ClearFileAdapter mAdapter;
	ArrayList<ClearFileBean> mFileBeans;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.clear_activity);
		prepareView();
//		getFilesInfo();
		setListView();
	}

//	private Thread mThread;

//	private void getFilesInfo() {
//		mProgress.show();
//		mThread = new Thread(new Runnable() {
//
//			@Override
//			public void run() {
//				ArrayList<FileBean> fileBeans = new ArrayList<FileBean>();
//				File file = new File(Constans.DOWNLOAD_DIR);
//				if (file.exists() && file.isDirectory()) {
//					for (File f : file.listFiles()) {
//						FileBean bean = FileBean.parseFileBean(f);
//						if (bean != null) {
//							fileBeans.add(bean);
//						}
//					}
//				}
//				Message msg = new Message();
//				msg.obj = fileBeans;
//				mHandler.sendMessage(msg);
//			}
//		});
//		mThread.start();
//	}

//	private FileAdapter mFileAdapter;

	private  Handler mHandler = new Handler() {
		@SuppressLint("HandlerLeak")
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			mProgress.dismiss();
			if (msg.what == 101) {
//				setListView();
				BaseApp.showToast("清除缓存成功");
				finish();
			} else {
//				mFileBeans = (ArrayList<FileBean>) msg.obj;
//				mFileAdapter = new FileAdapter(ClearActivity.this, mFileBeans);
//				mListView.setAdapter(mFileAdapter);
			}
		};
	};

	private void prepareView() {
		mListView = (ListView) findViewById(R.id.file_list);
		mProgress = new LoadingProgressDialog(this);
		findViewById(R.id.clear_cancel).setOnClickListener(this);
		findViewById(R.id.clear_delete).setOnClickListener(this);
		setTitleColor(getResources().getColor(R.color.black));
		TextView title = (TextView)findViewById(R.id.clear_title);
		title.setText("请选择要清除的缓存选项");
	}

	private void deleteFiles() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				for (ClearFileBean bean : mFileBeans) {
					if (bean.isClear) {
						if(bean.name.equals("收藏")){
							deleteFile(new File(FavourListBeanMarket.FILE_CACHE
									+ FavourListBeanMarket.class.getSimpleName().hashCode()));
							deleteFile(new File(FavourListBean.FILE_CACHE
									+ FavourListBean.class.getSimpleName().hashCode()));
							deleteFile(new File(FavourListBean.FILE_CACHE
									+ FavourListBeanOffice.class.getSimpleName().hashCode()));
						}else if(bean.name.equals("订阅")){
							deleteFile(new File(ChannelListBean.FILE_CACHE_SUB
									+ ("" + LoginBean.getInstance().userId).hashCode()));
							deleteFile(new File(MagazineListBean.FILE_CACHE_SUB
									+ ("" + LoginBean.getInstance().userId).hashCode()));
						}else if(bean.name.equals("邮件账号")){
							MySharedPreferences sp = new MySharedPreferences(ClearActivity.this);
							sp.putEmailName(null);
							sp.putEmailPassword(null);
						}else if(bean.name.equals("通讯录")){
							deleteFile(new File(bean.path));
							OrganizationListBean.deleteAll();
						}else if(bean.path.equals(Constans.IMG_DIR)){
							deleteFile(new File(bean.path));
							ImageLoader.getInstance().clearCache();
							LogUtil.e("删除---》" +bean.path);
						}else if(bean.path.equals(Constans.DOWNLOAD_DIR)){
							deleteFile(new File(bean.path));
							FavourListBean.getInstance().getFavourMagazineBeans().clear();
							FavourListBean.save();
							DownloadListBean.getInstance().mDownloadlist.clear();
							File file = new File(Constans.DOWNLOAD_DIR);
							if (!file.isDirectory()) {
								file.mkdirs();
							}
						}else{
							deleteFile(new File(bean.path));
						}
					}
				}
				mHandler.sendEmptyMessage(101);
			}
		}).start();
	}
 
	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.clear_delete) {
			if (mAdapter.isSelected()) {
				mProgress.show();
				deleteFiles();
			}else{
				BaseApp.showToast("您未选择要清除的项目");
			}
		} else {
			finish();
		}
	}

	private void deleteFile(File file) {
		if (file.exists()) {
			if (file.isFile()) {
				file.delete();
			} else if (file.isDirectory()) {
				File files[] = file.listFiles();
				for (int i = 0; i < files.length; i++) {
					this.deleteFile(files[i]);
				}
			}
			file.delete();
			System.out.println("删除文件！" + file.getName()+'\n');
		} else {
			System.out.println("所删除的文件不存在！" + '\n');
		}
	} 
	
	private void setListView(){
		mFileBeans = new ArrayList<ClearFileBean>();
//		mFileBeans.add(new ClearFileBean("通讯录",CareListBean.FILE_CACHE));
		mFileBeans.add(new ClearFileBean("资讯中心",Constans.IMG_DIR));
//		mFileBeans.add(new ClearFileBean("杂志",Constans.DOWNLOAD_DIR));
		mFileBeans.add(new ClearFileBean("内部报刊",Constans.DOWNLOAD_DIR));
		mFileBeans.add(new ClearFileBean("通讯录",Constans.IMG_DIR));
		mFileBeans.add(new ClearFileBean("订阅",ChannelListBean.FILE_CACHE_SUB));
		mFileBeans.add(new ClearFileBean("收藏",FavourListBean.FILE_CACHE));
		mFileBeans.add(new ClearFileBean("邮件账号"," "));
		mAdapter = new ClearFileAdapter(this,mFileBeans);
		mListView.setAdapter(mAdapter);
		
		
	}
}
