package com.suncco.chinacdc.clear;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ClearFileBean;

public class ClearFileAdapter extends BaseAdapter implements OnCheckedChangeListener {

	private Context mContext;
	private ArrayList<ClearFileBean> mFileBeans;

	public ClearFileAdapter(Context context, ArrayList<ClearFileBean> bean) {
		this.mContext = context;
		this.mFileBeans = bean;
		
	}

	@Override
	public int getCount() {
		return mFileBeans == null ? 0 : mFileBeans.size();
	}

	@Override
	public ClearFileBean getItem(int position) {
		return mFileBeans.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public boolean isSelected(){
		boolean isSelected = false;
		for(int i = 0,l = mFileBeans.size();i < l; i ++){
			if(mFileBeans.get(i).isClear){
				isSelected = true;
			}
		}
		return isSelected;
	}

	static class ViewHolder {
		TextView name;
//		TextView size;
		CheckBox box;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.file_item, null);
			holder = new ViewHolder();
			holder.name = (TextView) convertView.findViewById(R.id.file_name);
			holder.box = (CheckBox) convertView.findViewById(R.id.file_del_box);
//			holder.size = (TextView) convertView.findViewById(R.id.file_size);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		ClearFileBean bean = getItem(position);
		holder.name.setText(bean.name);
		holder.box.setOnCheckedChangeListener(null);
		holder.box.setChecked(bean.isClear);
		holder.box.setTag(bean);
		holder.box.setOnCheckedChangeListener(this);
//		holder.size.setText(bean.size);
		return convertView;
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		ClearFileBean bean = (ClearFileBean) buttonView.getTag();
		bean.isClear = isChecked;
	}

}
