package com.suncco.chinacdc.information;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ArticleBean;
import com.suncco.chinacdc.bean.ArticleListBean;
import com.suncco.chinacdc.utils.TimeUtils;

public class ArticleAdapter extends BaseAdapter {

	private Context mContext;
	private ArticleListBean mArticleListBean;

	public ArticleAdapter(Context context, ArticleListBean bean) {
		this.mContext = context;
		this.mArticleListBean = bean;
	}

	public int getCount() {
		return mArticleListBean == null ? 0 : mArticleListBean.mArticleBeans
				.size();
	}

	public ArticleBean getItem(int position) {
		return mArticleListBean.mArticleBeans.get(position);
	}

	public long getItemId(int position) {
		return 0;
	}

	static class ViewHolder {
		TextView title, descript,time;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.article_item, null);
			holder = new ViewHolder();
			holder.title = (TextView) convertView
					.findViewById(R.id.article_title);
			holder.descript = (TextView) convertView
					.findViewById(R.id.article_descript);
			holder.time = (TextView)convertView.findViewById(R.id.article_time);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		ArticleBean bean = getItem(position);
		holder.title.setText(bean.title);
		if(bean.descript == null || bean.descript.equals("")){
			holder.descript.setVisibility(View.GONE);
		}else{
			holder.descript.setVisibility(View.VISIBLE);
			holder.descript.setText(bean.descript);
		}
		holder.time.setText(bean.time);
		if(TimeUtils.getCurrentDay().equals(bean.time)){
			holder.time.setTextColor(Color.parseColor("#ff0000"));
		}else{
			holder.time.setTextColor(Color.parseColor("#aeaeae"));
		}
		return convertView;
	}

}
