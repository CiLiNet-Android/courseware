package com.suncco.chinacdc.information;

import java.io.File;
import java.util.HashMap;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.webkit.WebView.HitTestResult;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.ScrollView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ArticleDetailBean;
import com.suncco.chinacdc.bean.FavourListBean;
import com.suncco.chinacdc.bean.FavourListBeanMarket;
import com.suncco.chinacdc.bean.FavourListBeanOffice;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.SettingsBean;
import com.suncco.chinacdc.emailprocess.WebViewActivity;
import com.suncco.chinacdc.magazine.PhotoBrowseActivity;
import com.suncco.chinacdc.magazine.PhotoBrowseActivity2;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.FileDownloadThread;
import com.suncco.chinacdc.utils.FileUtils;
import com.suncco.chinacdc.utils.ImageLoader;
import com.suncco.chinacdc.utils.ImagesThread;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.umeng.analytics.MobclickAgent;

public class ArticleDetailActivity extends BaseActivity implements
		OnClickListener, OnCheckedChangeListener, OnLongClickListener {

	private static final int HANDLER_DETAIL_WHAT = 100;
	private static final int HANDLER_IMG = 101;
	private static final int HANDLER_FILEDOWNLOAD = 102;

	private PopupWindow mPopupMenuWindow;
	private View mTitleBar;
	private boolean mMenuPopVisbility;
	private LoadingProgressDialog mProgress;
	private LoadingProgressDialog mLoadingProgressDialog;
	private WebView mWebView;

	private int mDefaultTextSize = 14;
	private int mSizeLimt = 4;
	private int mCurrentTextSize;
	private ArticleDetailBean mArticleDetailBean;

	private ImagesThread mImagesThread;
	private boolean isLoading;

	WebSettings mWebSettings;
	int fontSize = 0;

	ScrollView mScrollView;

	String channelId;
	String belong = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.article_detail_activity);
		mProgress = new LoadingProgressDialog(this);
		prepareView();
		getArticleDetail();
	}

	private void prepareView() {
		mLoadingProgressDialog = new LoadingProgressDialog(this);
		channelId = getIntent().getStringExtra("channelId");
		if (channelId == null)
			channelId = "0";
		belong = getIntent().getStringExtra("belong") + "";
		mTitleBar = findViewById(R.id.article_title_frame);
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.font_but).setOnClickListener(this);
		mWebView = (WebView) findViewById(R.id.article_content);
		// mWebView = (WebView) findViewById(R.id.web_webview);
		mWebView.setOnClickListener(mWebViewOnClickListener);
//		mWebView.setDownloadListener(this);
		mWebView.setOnLongClickListener(this);
		mCurrentTextSize = SettingsBean.getInstance().getSettingValueByName(
				Constans.DETAIL_TEXT_SIZE, mDefaultTextSize);
		mScrollView = (ScrollView) findViewById(R.id.article_scroll);
		// mContentText.setTextSize(mCurrentTextSize);
	}

	private void changMenuPopState(View v) {
		mMenuPopVisbility = !mMenuPopVisbility;
		if (mMenuPopVisbility) {
			popMenuWindow(v);
		} else {
			if (mPopupMenuWindow != null) {
				mPopupMenuWindow.dismiss();
			}
		}
	}

	private void changeTextSize(boolean largeOrSmall) {
		if (largeOrSmall) {
			// ++
			// if (mCurrentTextSize < (mDefaultTextSize + mSizeLimt)) {
			// mCurrentTextSize++;
			// }
			fontSize++;

			if (fontSize > 5) {
				fontSize = 5;
				return;
			}

		} else {
			// --
			// if (mCurrentTextSize > (mDefaultTextSize - mSizeLimt)) {
			// mCurrentTextSize--;
			// }
			fontSize--;

			if (fontSize <= 0) {
				fontSize = 1;
				return;
			}
		}
		// mContentText.setTextSize(mCurrentTextSize);
		setFontSize();
		// mWebView.refreshDrawableState();
		// mWebView.invokeZoomPicker();
		// mWebView.destroyDrawingCache();
		// mWebView.refreshDrawableState();
		// mWebView.clearView();
		// mWebView.reload();
		setContentView(R.layout.article_detail_activity);
		prepareView();
		setDetailView();
		LogUtil.e("webview size--> " + mWebView.getHeight());
		LogUtil.e("mScrollView size--> " + mScrollView.getHeight());
		LogUtil.e("mScrollView size--> "
				+ mWebView.getZoomControls().getHeight());
		// SettingsBean.getInstance().putSettingValue(Constans.DETAIL_TEXT_SIZE,
		// mCurrentTextSize + "");
		// SettingsBean.save();
	}

	private void popMenuWindow(View parent) {
		mMenuPopVisbility = true;
		if (mPopupMenuWindow == null) {
			View popView = LayoutInflater.from(this).inflate(
					R.layout.font_view, null);
			popView.findViewById(R.id.font_big).setOnClickListener(this);
			popView.findViewById(R.id.font_small).setOnClickListener(this);
			mPopupMenuWindow = new PopupWindow(popView,
					(int) (BaseApp.sScreenWidth / 2.5),
					(int) (BaseApp.sScreenHeight / 6f));
			mPopupMenuWindow.setTouchInterceptor(new OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
						mPopupMenuWindow.dismiss();
						return true;
					}
					return false;
				}
			});
			mPopupMenuWindow.setOnDismissListener(new OnDismissListener() {

				public void onDismiss() {
					mMenuPopVisbility = false;
				}
			});
		}
		ColorDrawable cd = new ColorDrawable(-0000);
		mPopupMenuWindow.setBackgroundDrawable(cd);
		mPopupMenuWindow.update();
		mPopupMenuWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
		mPopupMenuWindow.setTouchable(true);
		mPopupMenuWindow.setOutsideTouchable(true);
		mPopupMenuWindow.setFocusable(true);
		mPopupMenuWindow.showAtLocation(parent,
				Gravity.TOP,
				(int) (BaseApp.sScreenWidth *3/ 5),
				(int) (1.35f * mTitleBar.getBottom()));
//		mPopupMenuWindow.showAtLocation(parent,
//				(Gravity.BOTTOM - parent.getHeight()) | Gravity.LEFT,
//				(int) (BaseApp.sScreenWidth / 1.55),
//				(int) (1.35f * mTitleBar.getBottom()));
	}

	private void getArticleDetail() {
		mProgress.show();
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		utils.addNameAndValue("id", getIntent().getStringExtra("id"));
		new ChinacdcThread(ArticleDetailBean.class, utils.formatParams(),
				mHandler, HANDLER_DETAIL_WHAT).start();
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_DETAIL_WHAT) {
				mProgress.dismiss();
				mArticleDetailBean = (ArticleDetailBean) msg.obj;
				if (mArticleDetailBean == null) {
					BaseApp.showToast(R.string.app_net_exc);
				} else {
					if (mArticleDetailBean.code == 0) {
						mArticleDetailBean.belong = belong;
						if (mArticleDetailBean.content.contains("<img")) {
							 mArticleDetailBean.content =
							 mArticleDetailBean.content.replaceAll("<img",
							 "<img onclick=\"window.demo.clickOnAndroid(this.src)\" ");
						}

						LogUtil.e("content--->" + mArticleDetailBean.content);
						// mArticleDetailBean.content =
						// Html.fromHtml(mArticleDetailBean.content).toString();
						setDetailView();
						HashMap<String, String> maps = new HashMap<String, String>();
						maps.put("资讯新闻名",mArticleDetailBean.title+"");
						maps.put("资讯新闻id", mArticleDetailBean.id+"");
						MobclickAgent.onEvent(ArticleDetailActivity.this, UmengEvent.intoInfoNewEvent, maps);
					} else {
						// BaseApp.showToast(mArticleDetailBean.message);
						BaseApp.showSessionnDialog(ArticleDetailActivity.this,
								mArticleDetailBean);
						// mArticleDetailBean = null;
					}
				}
			} else if (msg.what == HANDLER_IMG) {
				isLoading = false;
				setDetailView();
			}else if(msg.what == HANDLER_FILEDOWNLOAD){
				String path = (String) msg.obj;
				 File file = new File(path);
				 if(file.exists()){
					 FileUtils.openFile(file, ArticleDetailActivity.this);
				 }else{
					 BaseApp.showToast("文件下载失败");
				 }
				 mLoadingProgressDialog.dismiss();
			}
		};
	};

	private void setDetailView() {
		// mWebView.loadData(
		// Html.toHtml(Html.fromHtml(Html.fromHtml(
		// mArticleDetailBean.content).toString())), "text/html",
		// HTTP.DEFAULT_CONTENT_TYPE);
		// try {
		// mWebView.loadData(
		// Html.toHtml(text)Html.fromHtml(Html.toHtml(Html.fromHtml(
		// mArticleDetailBean.content))), "utf-8")
		// , "text/html",
		// HTTP.UTF_8);
		// } catch (UnsupportedEncodingException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		TextView title = (TextView) findViewById(R.id.article_title);
		title.setText(mArticleDetailBean.title);
		setFavCheck();

		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setSupportZoom(true);
		mWebSettings = mWebView.getSettings();
		if (fontSize == 0) {
			initFontSize();
		} else {
			setFontSize();
		}
		mWebSettings.setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		mWebSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
		mWebView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
		mWebView.setBackgroundColor(Color.parseColor("#f5f5f5"));
		mWebView.setSaveEnabled(true);
		mWebView.requestFocus();
		mWebView.setWebChromeClient(new MyWebChromeClient());
		mWebView.setWebViewClient(new MyWebViewClient());
		
		// mContentText.setText(Html
		// .fromHtml(mArticleDetailBean.content,mImageGetter, null));
		// mContentText.setMovementMethod(LinkMovementMethod.getInstance());
		// mContentText.setOnLongClickListener(new OnLongClickListener() {
		// public boolean onLongClick(View v) {
		// // TODO Auto-generated method stub
		// HitTestResult hitTestResult = ((WebView)v).getHitTestResult();
		// if(hitTestResult.getType() == HitTestResult.IMAGE_TYPE ||
		// hitTestResult.getType() == HitTestResult.IMAGE_ANCHOR_TYPE ||
		// hitTestResult.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE){
		// // showPopupWindow(hitTestResult);
		// }
		// return true;
		// return false;
		// }
		// });
		mWebView.loadDataWithBaseURL(null,
				(Html.fromHtml(mArticleDetailBean.content).toString()),
				"text/html", "utf-8", null);
		mWebView.addJavascriptInterface(new Object() {
			public void clickOnAndroid(final String str) {
				mHandler.post(new Runnable() {
					public void run() {
//						BaseApp.showToast("调用了---》" + str);
						String path = str;
						Intent intent = new Intent(ArticleDetailActivity.this,
								PhotoBrowseActivity2.class);
						intent.putExtra("url", path);
						startActivity(intent);
					}
				});
			}
		}, "demo");
	}

	ImageGetter mImageGetter = new ImageGetter() {

		public Drawable getDrawable(String arg0) {
			arg0 = arg0.trim();
			if (arg0.startsWith(".")) {
				arg0 = arg0.substring(1);
			}
			String path = Constans.IMG_DIR + arg0.hashCode();
			File file = new File(path);
			if (file.exists()) {
				Bitmap bmp = ImageLoader.getInstance().loadBitmapByPath(path);
				BitmapDrawable bitmapDrawable = new BitmapDrawable(bmp);
				Drawable drawable = (Drawable) bitmapDrawable;
				if (drawable != null) {
					if (Build.VERSION.SDK_INT < 14) {
						int w = drawable.getIntrinsicWidth();
						int h = drawable.getIntrinsicHeight();
						int sw = BaseApp.sScreenWidth;
						int tmp = (int) ((float) h * ((float) sw / (float) w));
						drawable.setBounds(0, 0, sw, tmp);
					} else {
						int w = drawable.getIntrinsicWidth();
						int h = drawable.getIntrinsicHeight();
						int sw = BaseApp.sScreenWidth;
						int tmp = (int) ((float) h * ((float) sw / (float) w));
						drawable.setBounds(0, 0, sw * 9 / 10, tmp * 9 / 10);
					}
				}
				return drawable;
			} else {
				if (isLoading) {

				} else {
					if (mImagesThread != null)
						mImagesThread.mIsCancel = true;
					mImagesThread = new ImagesThread(mHandler, arg0,
							HANDLER_IMG);
					mImagesThread.start();
					isLoading = true;
				}
			}
			return null;
		}
	};

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.font_but:
			changMenuPopState(v);
			break;
		case R.id.back:
			finish();
			break;
		case R.id.font_big:
			changeTextSize(true);
			break;
		case R.id.font_small:
			changeTextSize(false);
			break;
		default:
			break;
		}
	}

	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (mArticleDetailBean != null) {
			if (channelId.equals("6")) {
				if (isChecked) {
					FavourListBeanMarket.getInstance().addFavourArticleBean(
							mArticleDetailBean);
					BaseApp.showToast(R.string.app_favour_succeed);
				} else {
					FavourListBeanMarket.getInstance().removeFavourArticleBean(
							mArticleDetailBean.id);
					BaseApp.showToast("已取消收藏");
				}

				// FavourListBean.save();
			} else if (channelId.equals("11")) {
				if (isChecked) {
					FavourListBeanOffice.getInstance().addFavourArticleBean(
							mArticleDetailBean);
					BaseApp.showToast(R.string.app_favour_succeed);
				} else {
					FavourListBeanOffice.getInstance().removeFavourArticleBean(
							mArticleDetailBean.id);
					BaseApp.showToast("已取消收藏");
				}

				// FavourListBean.save();
			} else {
				if (isChecked) {
					FavourListBean.getInstance().addFavourArticleBean(
							mArticleDetailBean);
					BaseApp.showToast(R.string.app_favour_succeed);
				} else {
					FavourListBean.getInstance().removeFavourArticleBean(
							mArticleDetailBean.id);
					BaseApp.showToast("已取消收藏");
				}

				// FavourListBean.save();
			}
		}
	}

	class MyWebViewClient extends WebViewClient {
		String loginCookie;

		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			// TODO Auto-generated method stub
			// mWebView.loadUrl(url);
			LogUtil.e("overriderUrlLoading-->" + url);
			String homeMode = android.os.Build.MODEL;
			LogUtil.e("" + homeMode);
			if (url != null && "tel".equals(url.substring(0, 3))
					&& !url.substring(4).startsWith("1")) {
				String phoneNumber = url.substring(4);
				url = "tel:" + "1" + phoneNumber;
			}
			
			url = url.toLowerCase();
			
			String fileTypes = "doc docx xls xlsx ppt pptx pps vsd jpg gif png tif bmp txt pdf rar zip";
			
			if( url.contains(".") && fileTypes.contains(url.substring(url.lastIndexOf(".")+1))){
				String fileName =  url.substring(0,url.lastIndexOf(".")).hashCode() + url.substring(url.lastIndexOf("."));
				LogUtil.e("fileName---->" + fileName);
				String path = Constans.DOWNLOAD_DIR+fileName;
				startDownloadFile(url,path);
			}else{
				Intent intent = new Intent();
				intent.setAction(Intent.ACTION_DEFAULT);
				intent.setData(Uri.parse(url));
				startActivity(Intent.createChooser(intent, "请选择打开的程序"));
				
			}
			
			// startActivity(intent);
			return true;
		}

		@Override
		public void onLoadResource(WebView view, String url) {
			// TODO Auto-generated method stub
			// CookieManager cookieManager = CookieManager.getInstance();
			// loginCookie = cookieManager.getCookie(url);
			LogUtil.e("onLoadResource-->" + url);
			super.onLoadResource(view, url);
		}

		@Override
		public void onPageFinished(WebView view, String url) {
			// TODO Auto-generated method stub
			// CookieManager cookieManager = CookieManager.getInstance();
			// cookieManager.setCookie(url, loginCookie);
			super.onPageFinished(view, url);
			LogUtil.e("onPageFinished-->" + url);
			
//			mWebView.loadUrl("javascript:(function(){document.getElementsByTagName('img').onclick=function(){window.demo.clickOnAndroid(2);}})()");
			if (mProgress != null) {
				mProgress.dismiss();
				mProgress = null;
			}
			// if (url.equals(LoginBean.getInstance().xphoneUrl)) {
			// BaseApp.showToast("add js---->");
			// mWebView.loadUrl("javascript:window.HTMLOUT.showHTML('<head>'+document.getElementsByTagName('html')[0].innerHTML+'</head>');");
			// }
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// TODO Auto-generated method stub
			LogUtil.e("onPageStarted-->" + url);
			if (mProgress != null && !ArticleDetailActivity.this.isFinishing()) {
				mProgress.show();
			}
			super.onPageStarted(view, url, favicon);
		}

		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler,
				SslError error) {
			// TODO Auto-generated method stub
			super.onReceivedSslError(view, handler, error);
		}

	}

	class MyWebChromeClient extends WebChromeClient {

		@Override
		public boolean onJsAlert(WebView view, String url, String message,
				JsResult result) {
			// TODO Auto-generated method stub
			// BaseApp.showToast("on jsAlert--->" + message);
			return super.onJsAlert(view, url, message, result);
		}

		@Override
		public void onReceivedIcon(WebView view, Bitmap icon) {
			// TODO Auto-generated method stub
			super.onReceivedIcon(view, icon);
		}

		@Override
		public void onReceivedTouchIconUrl(WebView view, String url,
				boolean precomposed) {
			// TODO Auto-generated method stub
			BaseApp.showToast("onReceivedTouch--->" + url);
			super.onReceivedTouchIconUrl(view, url, precomposed);
		}

	}

	private void initFontSize() {
		if (mWebSettings.getTextSize() == WebSettings.TextSize.SMALLEST) {
			fontSize = 1;
		} else if (mWebSettings.getTextSize() == WebSettings.TextSize.SMALLER) {
			fontSize = 2;
		} else if (mWebSettings.getTextSize() == WebSettings.TextSize.NORMAL) {
			fontSize = 3;
		} else if (mWebSettings.getTextSize() == WebSettings.TextSize.LARGER) {
			fontSize = 4;
		} else if (mWebSettings.getTextSize() == WebSettings.TextSize.LARGEST) {
			fontSize = 5;
		}
	}

	private void setFontSize() {
		switch (fontSize) {

		case 1:
			mWebSettings.setTextSize(WebSettings.TextSize.SMALLEST);
			break;
		case 2:
			mWebSettings.setTextSize(WebSettings.TextSize.SMALLER);
			break;
		case 3:
			mWebSettings.setTextSize(WebSettings.TextSize.NORMAL);
			break;
		case 4:
			mWebSettings.setTextSize(WebSettings.TextSize.LARGER);
			break;
		case 5:
			mWebSettings.setTextSize(WebSettings.TextSize.LARGEST);
			break;
		}
		// setDetailView();

		// mWebView.requestLayout();
		// mWebView.reload();
	}

	private OnClickListener mWebViewOnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			HitTestResult hitTestResult = ((WebView) v).getHitTestResult();
			LogUtil.e(hitTestResult.getType() + hitTestResult.getExtra());
			if (hitTestResult.getType() == HitTestResult.IMAGE_TYPE
					|| hitTestResult.getType() == HitTestResult.IMAGE_ANCHOR_TYPE
					|| hitTestResult.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
				LogUtil.e("onLongClick--->" + hitTestResult.getExtra());
				LogUtil.e("onLongClick--->" + hitTestResult.getType());
				String path = Constans.IMG_DIR
						+ hitTestResult.getExtra().hashCode();
				Intent intent = new Intent(ArticleDetailActivity.this,
						PhotoBrowseActivity.class);
				intent.putExtra("path", path);
				startActivity(intent);
			}
			// return true;
		}
	};

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		HitTestResult hitTestResult = ((WebView) v).getHitTestResult();
		LogUtil.e(hitTestResult.getType() + hitTestResult.getExtra());
		if (hitTestResult.getType() == HitTestResult.IMAGE_TYPE
				|| hitTestResult.getType() == HitTestResult.IMAGE_ANCHOR_TYPE
				|| hitTestResult.getType() == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
			String path = hitTestResult.getExtra();
			Intent intent = new Intent(ArticleDetailActivity.this,
					PhotoBrowseActivity2.class);
			intent.putExtra("url", path);
			startActivity(intent);
		}
		return true;
	}
	
	private void setFavCheck(){
		CheckBox box = (CheckBox) findViewById(R.id.favour_check_box);
		box.setOnCheckedChangeListener(null);
		if (mArticleDetailBean != null) {
			if (channelId.equals("6")) {
				box.setChecked(FavourListBeanMarket
						.getInstance().hasArticleBean(
								mArticleDetailBean.id));
			} else if (channelId.equals("11")) {
				box.setChecked(FavourListBeanOffice
						.getInstance().hasArticleBean(
								mArticleDetailBean.id));
			} else {
				box.setChecked(FavourListBean.getInstance()
						.hasArticleBean(mArticleDetailBean.id));
			}
		}
		box.setOnCheckedChangeListener(ArticleDetailActivity.this);
	}
	
	private void startDownloadFile(String url,String path){
		mLoadingProgressDialog.show();
		new FileDownloadThread(mHandler, url, path, HANDLER_FILEDOWNLOAD).start();
	}

}
