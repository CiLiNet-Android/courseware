package com.suncco.chinacdc.information;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ArticleBean;
import com.suncco.chinacdc.bean.ArticleListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.XListView;
import com.suncco.chinacdc.widget.XListView.IXListViewListener;

public class ArticleListActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener, IXListViewListener {

	private static final int HANDLER_ARTICLE_WHAT = 100;

	private LoadingProgressDialog mProgress;
	private ChinacdcThread mChinacdcThread;
	private ArticleAdapter mArticleAdapter;
	private XListView mArticleListView;
	private ArticleListBean mArticleListBean;
	String channelId = "0";
	String titleName = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.article_list_activity);
		prepareView();
		mProgress.show();
		getArticleList(1);
	}

	private void prepareView() {
		channelId = getIntent().getStringExtra("id");
		TextView title = (TextView) findViewById(R.id.channel_title);
		titleName = getIntent().getStringExtra("channel")+"";
		title.setText(titleName);
		mProgress = new LoadingProgressDialog(this);
		findViewById(R.id.back).setOnClickListener(this);
		mArticleListView = (XListView) findViewById(R.id.article_list);
		mArticleListView.setXListViewListener(this);
		mArticleListView.setPullLoadEnable(true);
		mArticleListView.setPullRefreshEnable(true);
		mArticleListView.setOnItemClickListener(this);
	}

	private void getArticleList(int page) {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		utils.addNameAndValue("page", page + "");
		utils.addNameAndValue("numPerPage", Constans.PAGE_SIZE + "");
		utils.addNameAndValue("channelId",channelId);
		mChinacdcThread = new ChinacdcThread(ArticleListBean.class,
				utils.formatParams(), mHandler, HANDLER_ARTICLE_WHAT);
		mChinacdcThread.start();
	}
 
	private void hasNextPage() {
		mArticleListView.stopRefresh();
		mArticleListView.stopLoadMore();
		if (mArticleListBean != null && !mArticleListBean.hasNextPage() ) {
			LogUtil.i("没下一页了");
			mArticleListView.setPullLoadEnable(false);
		} else {
			LogUtil.i("还有下一页");
		}
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_ARTICLE_WHAT) {
				mProgress.dismiss();
				ArticleListBean bean = (ArticleListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_net_exc);
				} else {
					if (bean.code == 0) {
						if (mArticleListBean == null) {
							mArticleListBean = bean;
							mArticleAdapter = new ArticleAdapter(
									ArticleListActivity.this, mArticleListBean);
							mArticleListView.setAdapter(mArticleAdapter);
							SimpleDateFormat formatter = new SimpleDateFormat(
									"hh:mm:ss");
							mArticleListView.setRefreshTime(formatter
									.format(new Date()));
						} else {
							// 分页添加
							mArticleListBean.addPage(bean);
							mArticleAdapter.notifyDataSetChanged();
						}
					} else {
//						BaseApp.showToast(bean.message);
						BaseApp.showSessionnDialog(ArticleListActivity.this, bean);
					}
				}
				hasNextPage();
			}
		};
	};

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		ArticleBean bean = mArticleAdapter.getItem(position - 1);
		Intent intent = new Intent(this, ArticleDetailActivity.class);
		intent.putExtra("id", bean.id);
		intent.putExtra("belong", titleName);
		if(channelId.equals("6") || channelId.equals("11")){
			intent.putExtra("channelId", channelId);
		}
		startActivity(intent);
	}

	public void onRefresh() {
		mArticleListBean = null;
		mArticleListView.setPullLoadEnable(true);
		getArticleList(1);
	}

	public void onLoadMore() {
		if(mArticleListBean != null)
		getArticleList(mArticleListBean.getCurrentPage());
	}

}
