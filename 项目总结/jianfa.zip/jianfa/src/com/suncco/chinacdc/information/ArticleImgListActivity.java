package com.suncco.chinacdc.information;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ArticleBean;
import com.suncco.chinacdc.bean.ArticleListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ImagesThread;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.ScrollLayout;
import com.suncco.chinacdc.widget.ScrollLayout.PageListener;

public class ArticleImgListActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener, PageListener {

	private static final int HANDLER_ARTICLE_WHAT = 100;
	
	private static final int HANDLER_ARTICLE_IMG = 101;

	private LoadingProgressDialog mProgress;
	private ChinacdcThread mChinacdcThread;
	private ArticleListBean mArticleListBean;

	/** 总页数. */
	private int PageCount;
	/** 当前页码. */
	private int PageCurrent;
	/** 每页显示的数量，Adapter保持一致. */
	private static final float PAGE_SIZE = 12.0f;
	/** GridView. */
	private GridView gridView;
	/** 自定义的左右滑动. */
	private ScrollLayout curPage;
	TextView mPageText;
	
	String channelId;
	String titleName = "";
	
	AticleImgGridAdapter[] adapters;
	ImagesThread mImagesThread;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.article_img_grid_activity);
		prepareView();
		mProgress.show();
		getArticleList(1);
	}

	private void prepareView() {
		channelId = getIntent().getStringExtra("id");
		if(channelId == null)channelId = "0";
		TextView title = (TextView) findViewById(R.id.channel_title);
		titleName = getIntent().getStringExtra("channel")+"";
		title.setText(titleName);
		mProgress = new LoadingProgressDialog(this);
		mPageText = (TextView)findViewById(R.id.title_page_text);
		findViewById(R.id.title_but1).setOnClickListener(this);
		curPage = (ScrollLayout) findViewById(R.id.article_scroll);
		curPage.getLayoutParams().height = BaseApp.sScreenHeight * 4 / 5;
		curPage.setPageListener(this);
	}

	private void getArticleList(int page) {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		utils.addNameAndValue("page", page + "");
		utils.addNameAndValue("numPerPage", "1000");
		utils.addNameAndValue("channelId", getIntent().getStringExtra("id"));
		mChinacdcThread = new ChinacdcThread(ArticleListBean.class,
				utils.formatParams(), mHandler, HANDLER_ARTICLE_WHAT);
		mChinacdcThread.start();
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_ARTICLE_WHAT) {
				mProgress.dismiss();
				ArticleListBean bean = (ArticleListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_net_exc);
				} else {
					if (bean.code == 0) {
						mArticleListBean = bean;
						setGrid();
						mImagesThread = new ImagesThread(mHandler, mArticleListBean.getImages(), HANDLER_ARTICLE_IMG);
						mImagesThread.start();
					} else {
						BaseApp.showSessionnDialog(ArticleImgListActivity.this, bean);
//						BaseApp.showToast(bean.message);
					}
				}
			}else if(msg.what == HANDLER_ARTICLE_IMG){
				setNotifyDatesetChang();
			}
		};
	};

	public void onClick(View v) {
		if (v.getId() == R.id.title_but1) {
			finish();
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		 ArticleBean bean = (ArticleBean) view.getTag(R.id.article_img);
		 Intent intent = new Intent(this, ArticleDetailActivity.class);
		 intent.putExtra("id", bean.id);
		 intent.putExtra("channelId", channelId);
		 intent.putExtra("belong", titleName);
		 startActivity(intent);
//		 BaseApp.showToast("--"+ bean.title);
	}

	/**
	 * 添加GridView
	 */
	private void setGrid() {

		PageCount = (int) Math.ceil(mArticleListBean.mArticleBeans.size() / PAGE_SIZE);
		if (gridView != null) {
			curPage.removeAllViews();
		}
		adapters = new AticleImgGridAdapter[PageCount];
		
		for (int i = 0; i < PageCount; i++) {
			gridView = new GridView(this);
			adapters[i] = new AticleImgGridAdapter(this, mArticleListBean, i);
			gridView.setAdapter(adapters[i]);
			gridView.setNumColumns(3);
//			gridView.setHorizontalSpacing(20);
			gridView.setVerticalSpacing(8);
			// 去掉点击时的黄色背景
			gridView.setSelector(R.drawable.transparent);
			gridView.setOnItemClickListener(this);
			curPage.addView(gridView);
		}
		curPage.snapToScreen(0);
	}
	
	private void setNotifyDatesetChang(){
		if (adapters != null){
			for(int i = 0 , l = adapters.length ; i < l ; i ++){
				adapters[i].notifyDataSetChanged();
			}
		}
		
	}

	@Override
	public void page(int page) {
		PageCurrent = page;
		if(PageCount > 1){
			mPageText.setText(PageCurrent+1 + "");
			mPageText.setVisibility(View.VISIBLE);
		}else{
			mPageText.setVisibility(View.INVISIBLE);
		}
	}

}
