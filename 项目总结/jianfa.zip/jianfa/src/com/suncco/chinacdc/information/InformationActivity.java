package com.suncco.chinacdc.information;

import java.util.HashMap;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ChannelBean;
import com.suncco.chinacdc.bean.ChannelListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.magazine.JournalActivity;
import com.suncco.chinacdc.subscription.SubDetailActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.DensityUtil;
import com.suncco.chinacdc.utils.ImagesThread;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.MyGridView;
import com.suncco.chinacdc.widget.ScrollLayout;
import com.suncco.chinacdc.widget.ScrollLayout.PageListener;
import com.umeng.analytics.MobclickAgent;

public class InformationActivity extends BaseActivity implements
		OnClickListener, OnItemClickListener, PageListener {

	private static final int HANDLER_CHANNEL_WHAT = 100;
	private static final int HANDLER_CHANNEL_IMG_WHAT = 101;
	
	private static final int REQUEST_SUB = 33;

	private LoadingProgressDialog mProgress;
//	private InformationAdapter mInformationAdapter;
	ChannelListBean mChannelListBean;
	ChannelGridAdapter[] mAdapters;
	

	/** 总页数. */
	private int PageCount;
	/** 当前页码. */
	private int PageCurrent;
	/** 每页显示的数量，Adapter保持一致. */
	private static final float PAGE_SIZE = 6.0f;
	/** GridView. */
	private GridView gridView;
	/** 自定义的左右滑动. */
	private ScrollLayout curPage;
	TextView mPageText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.information_activity);
		prepareView();
		getChannelList();
		MobclickAgent.onEvent(this, UmengEvent.intoInfoEvent);
	}

	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.title_but2).setOnClickListener(this);
		mPageText = (TextView) findViewById(R.id.infomation_page_text);
		mProgress = new LoadingProgressDialog(this);
		curPage = (ScrollLayout) findViewById(R.id.infomation_scroll);
		curPage.getLayoutParams().height = BaseApp.sScreenHeight * 4/ 5;
//		curPage.getLayoutParams().width = BaseApp.sScreenWidth * 2 / 3;
		curPage.setPageListener(this);
	}

	private void getChannelList() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		new ChinacdcThread(ChannelListBean.class, utils.formatParams(),
				mHandler, HANDLER_CHANNEL_WHAT).start();
		mProgress.show();
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_CHANNEL_WHAT) {
				mProgress.dismiss();
				ChannelListBean bean = (ChannelListBean) msg.obj;
				if (bean != null) {
					if (bean.code == 0) {
						bean = ChannelListBean.getSubNowListBean(bean);
						mChannelListBean = bean;
						setGrid();
						new ImagesThread(mHandler, bean.getImageUrls(),
								HANDLER_CHANNEL_IMG_WHAT).start();
					} else {
						BaseApp.showSessionnDialog(InformationActivity.this, bean);
//						BaseApp.showToast(bean.message);
					}
				} else {
					BaseApp.showToast(R.string.app_net_exc);
				}
			} else if (msg.what == HANDLER_CHANNEL_IMG_WHAT) {
//				mInformationAdapter.notifyDataSetChanged();
				setAdapterNotify();
				
			}
		};
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode){
		case REQUEST_SUB:
			getChannelList();
			break;
		}
	}
	
	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		}else if(v.getId() == R.id.title_but2){
			Intent intent = new Intent(this, SubDetailActivity.class);
			intent.putExtra("type", 0);
			startActivityForResult(intent, REQUEST_SUB);
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		ChannelBean bean = (ChannelBean) view.getTag(R.id.information_icon);
		Intent intent = new Intent(this, ArticleListActivity.class);
		intent.putExtra("channel", bean.name);
		intent.putExtra("id", bean.id);
		HashMap<String, String> maps = new HashMap<String, String>();
		maps.put("资讯类别名称",bean.name+"");
		maps.put("资讯类别id", bean.id+"");
		MobclickAgent.onEvent(InformationActivity.this, UmengEvent.intoInfoCategoryEvent, maps);
		startActivity(intent);
	}
	
	/**
	 * 添加GridView
	 */
	private void setGrid() {

		PageCount = (int) Math.ceil(mChannelListBean.mChannelBeans.size() / PAGE_SIZE);
//		PageCount = 10;
		if (gridView != null) {
			curPage.removeAllViews();
		}
		mAdapters = new ChannelGridAdapter[PageCount];
		for (int i = 0; i < PageCount; i++) {
			gridView = new GridView(this);
			mAdapters[i] = new ChannelGridAdapter(this, mChannelListBean, i,gridView);
			gridView.setAdapter(mAdapters[i]);
			gridView.setNumColumns(2);
			gridView.setHorizontalSpacing(20);
			gridView.setVerticalSpacing(20);
//			gridView.setColumnWidth(BaseApp.sScreenWidth);
			gridView.setPadding(40, 0, 40, 0);
			// 去掉点击时的黄色背景
//			gridView.setSelector(R.drawable.transparent);
//			gridView.setStretchMode(GridView.NO_STRETCH);
			gridView.setOnItemClickListener(this);
			curPage.addView(gridView);
			
//			lp.height = android.view.ViewGroup.LayoutParams.FILL_PARENT;
//			curPage.getLayoutParams().height = gridView.getHeight();
//			gridView.setGravity(Gravity.CENTER_VERTICAL);
		}
		curPage.snapToScreen(0);
	}
	
	private void setAdapterNotify(){
		for(int i = 0, l = mAdapters.length; i < l ; i ++){
			mAdapters[i].notifyDataSetChanged();
		}
		
	}

	@Override
	public void page(int page) {
		PageCurrent = page;
		if(PageCount > 1){
			mPageText.setText(PageCurrent+1 + "");
			mPageText.setVisibility(View.VISIBLE);
		}else{
			mPageText.setVisibility(View.INVISIBLE);
		}
	}

}
