package com.suncco.chinacdc.information;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ArticleBean;
import com.suncco.chinacdc.bean.ArticleListBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageLoader;

public class AticleImgGridAdapter extends BaseAdapter {

	private Context context;
	/** 列表. */
	private ArticleListBean bean;
	private ArrayList<ArticleBean> mList;

	// 每页显示的Item个数
	public static final int SIZE = 12;

	public AticleImgGridAdapter(Context mContext, ArticleListBean bean, int page) {
		this.context = mContext;
		this.bean = bean;
		int i = page * SIZE;
		int iEnd = i + SIZE;
		mList = new ArrayList<ArticleBean>();
		while ((i < bean.mArticleBeans.size()) && (i < iEnd)) {
			mList.add(bean.mArticleBeans.get(i));
			i++;
		}
	}

	static class ViewHolder {
		ImageView img;
		TextView title;
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(
					R.layout.article_grid_item, null);
			holder = new ViewHolder();
			holder.img = (ImageView) convertView.findViewById(R.id.article_img);
			holder.title = (TextView) convertView
					.findViewById(R.id.article_title);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		ArticleBean bean = mList.get(position);
		holder.title.setText(bean.title);
//		Bitmap bm = ImageLoader.getInstance().loadBitmapByUrl(bean.titleImg);
		Bitmap bm =  BitmapLoader.getInstance().loadBitmapByPath(bean.titleImg, BaseApp.sScreenWidth/3, BaseApp.sScreenWidth/3);
		convertView.setTag(R.id.article_img, bean);
		if (bm != null) {
			holder.img.setImageBitmap(bm);
		} else {
			holder.img.setImageResource(R.drawable.menu_business);
		}

		return convertView;
	}

}
