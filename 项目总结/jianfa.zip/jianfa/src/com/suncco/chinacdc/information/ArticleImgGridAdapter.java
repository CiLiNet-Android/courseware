package com.suncco.chinacdc.information;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.MagazineBean;
import com.suncco.chinacdc.bean.MagazineListBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageLoader;

public class ArticleImgGridAdapter extends BaseAdapter {

	private Context mContext;
	private MagazineListBean mMagazineListBean;

	public ArticleImgGridAdapter(Context context, MagazineListBean bean) {
		this.mContext = context;
		this.mMagazineListBean = bean;
	}

	public int getCount() {
		return mMagazineListBean == null ? 0 : mMagazineListBean.mMagazineBeans
				.size();
	}

	public MagazineBean getItem(int arg0) {
		return mMagazineListBean.mMagazineBeans.get(arg0);
	}

	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		ImageView logo;
		TextView name;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.magazine_item, null);
			holder = new ViewHolder();
			holder.logo = (ImageView) convertView
					.findViewById(R.id.magazine_logo);
			holder.name = (TextView) convertView
					.findViewById(R.id.magazine_name);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		MagazineBean bean = getItem(position);
		holder.name.setText(bean.name);
		Bitmap bm = BitmapLoader.getInstance().loadBitmapByPath(bean.logoImg, BaseApp.sScreenWidth/3, BaseApp.sScreenWidth/3);
//		Bitmap bm = ImageLoader.getInstance().loadBitmapByUrl(bean.logoImg);
		if (bm != null) {
			holder.logo.setImageBitmap(bm);
		} else {
//			holder.logo.setImageResource(R.drawable.magazine_dufault_img);
		}

		return convertView;
	}
}
