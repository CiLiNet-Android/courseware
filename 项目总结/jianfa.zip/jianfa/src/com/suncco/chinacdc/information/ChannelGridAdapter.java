package com.suncco.chinacdc.information;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ChannelBean;
import com.suncco.chinacdc.bean.ChannelListBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageLoader;

public class ChannelGridAdapter extends BaseAdapter {

	private Context context;
	/** 列表. */
//	private ChannelListBean bean;
	private ArrayList<ChannelBean> mList;

	// 每页显示的Item个数
	public static final int SIZE = 6;
	
	GridView mGridView;

	public ChannelGridAdapter(Context mContext, ChannelListBean bean, int page,GridView grid) {
		this.context = mContext;
		mGridView = grid;
//		this.bean = bean;
		int i = page * SIZE;
		int iEnd = i + SIZE;
		mList = new ArrayList<ChannelBean>();
		while ((i < bean.mChannelBeans.size()) && (i < iEnd)) {
			mList.add(bean.mChannelBeans.get(i));
			i++;
		}
	}

	static class ViewHolder {
		ImageView icon;
		TextView title;
		TextView updateNum;
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public ChannelBean getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(
					R.layout.information_item, null);
			holder = new ViewHolder();
			holder.icon = (ImageView) convertView
					.findViewById(R.id.information_icon);
			holder.title = (TextView) convertView
					.findViewById(R.id.information_title);
			holder.updateNum = (TextView)convertView.findViewById(R.id.information_update_count);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		ChannelBean bean = getItem(position);
		convertView.setTag(R.id.information_icon, bean);
		holder.title.setText(bean.name);
		if(holder.title.getLineCount() > 2){
			holder.title.setText(bean.name.substring(0, bean.name.length()/2)+"/n" +bean.name.substring(bean.name.length()/2) );
		}
		if(bean.updateNum != null && !bean.updateNum.equals("0")){
			holder.updateNum.setVisibility(View.VISIBLE);
			holder.updateNum.setText(bean.updateNum);
		}else{
			holder.updateNum.setVisibility(View.INVISIBLE);
		}
		
//		Bitmap bm = ImageLoader.getInstance().loadBitmapByUrl(bean.imgUrl);
		Bitmap bm =  BitmapLoader.getInstance().loadBitmapByPath(bean.imgUrl, BaseApp.sScreenWidth/3, BaseApp.sScreenWidth/3);
		if (bm != null) {
			holder.icon.setImageBitmap(bm);
		} else {
//			holder.icon.setImageResource(R.drawable.channell_default_img);
		}
		return convertView;
	}

}
