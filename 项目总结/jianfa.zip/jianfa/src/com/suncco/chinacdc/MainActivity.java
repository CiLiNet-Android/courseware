package com.suncco.chinacdc;

import android.app.Activity;

/**
 * 
 * @author suncco 10036  2012-10-11
 */
public class MainActivity extends Activity {

}
