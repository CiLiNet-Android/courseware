package com.suncco.chinacdc.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.utils.LogUtil;

public class MenuAdapter extends BaseAdapter {

	private static int[] MENU_ICON = new int[] { R.drawable.menu_cms,
			R.drawable.menu_magazin, R.drawable.menu_contacts,
			R.drawable.menu_email, R.drawable.menu_maket,
			R.drawable.menu_business,R.drawable.icon_phone_newspaper };

	private static int[] MENU_NAME = new int[] { R.string.menu_cms,
			R.string.menu_magazin, R.string.menu_contacts, R.string.menu_email,
			R.string.menu_maket,R.string.menu_office,R.string.phone_newspaper };

	private Context mContext;

	public MenuAdapter(Context context) {
		this.mContext = context;
	}

	public int getCount() {
		LogUtil.e("showId---->"+LoginBean.getInstance().showId);
		if(LoginBean.getInstance().showId == 1){
			return MENU_ICON.length-1;
		}else{
			return MENU_ICON.length;
		}
//		return MENU_ICON.length;
	}

	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		ImageView icon;
		TextView name;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.menu_item, null);
			holder = new ViewHolder();
			holder.icon = (ImageView) convertView.findViewById(R.id.menu_icon);
			holder.name = (TextView) convertView.findViewById(R.id.menu_name);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.icon.setImageResource(MENU_ICON[position]);
		holder.name.setText(MENU_NAME[position]);
		return convertView;
	}
}
