package com.suncco.chinacdc.menu;

import java.text.MessageFormat;
import java.util.HashMap;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.cdc.android.app.news.MainActivity;
import com.cdc.android.app.news.NewsPaperBaseActivity;
import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.UpdataLoaderService;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.SettingsBean;
import com.suncco.chinacdc.bean.UpdateVersionBean;
import com.suncco.chinacdc.clear.ClearActivity;
import com.suncco.chinacdc.contacts.ContactTabActivity;
import com.suncco.chinacdc.emailprocess.WebViewActivity;
import com.suncco.chinacdc.favour.FavourMenuActivity;
import com.suncco.chinacdc.information.ArticleImgListActivity;
import com.suncco.chinacdc.information.ArticleListActivity;
import com.suncco.chinacdc.information.InformationActivity;
import com.suncco.chinacdc.login.LoginActivity;
import com.suncco.chinacdc.magazine.MagazineActivity;
import com.suncco.chinacdc.settings.SettingsActivity;
import com.suncco.chinacdc.subscription.SubscriptionActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.NetUtils;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.umeng.analytics.MobclickAgent;

public class MenuActivity extends BaseActivity implements OnClickListener,
		OnItemClickListener {

	private static final int HANDLER_WHAT_VERSION = 100;
	
	private static final int REQUEST_NEWSPAPER = 20;

	private int mKeyBackNumber;
	private LoadingProgressDialog mProgrees;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.menu_activity);
		prepareView();
		checkVersion();
//		getPhotoBean();
		if(LoginBean.getInstance() != null && LoginBean.getInstance().showId == 2){
			Intent intent = new Intent(this, MainActivity.class);
			NewsPaperBaseActivity.isExist = false;
			NewsPaperBaseActivity.isLogin = true;
			startActivityForResult(intent, REQUEST_NEWSPAPER);	
		}
	}

	private void prepareView() {
		GridView gridView = (GridView) findViewById(R.id.menu_grid);
		gridView.setOnItemClickListener(this);
		gridView.setAdapter(new MenuAdapter(this));
		findViewById(R.id.menu_settings).setOnClickListener(this);
		findViewById(R.id.menu_add).setOnClickListener(this);
		findViewById(R.id.menu_del).setOnClickListener(this);
		findViewById(R.id.menu_favour).setOnClickListener(this);
		TextView name = (TextView) findViewById(R.id.menu_name);
		name.setText(MessageFormat.format(getString(R.string.menu_name),
				LoginBean.getInstance().name));
		mProgrees = new LoadingProgressDialog(this);
	}

//	private void getPhotoBean() {
////		String id = "10005981";
//		WebServiceParamsUtils utils = new WebServiceParamsUtils();
//		utils.addNameAndValue("imageId", LoginBean.getInstance().photoId);
//		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
//		new ChinacdcThread(PhotoBean.class, utils.formatParams(), mHandler, 103)
//				.start();
//	}

	private void checkVersion() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		new ChinacdcThread(UpdateVersionBean.class, utils.formatParams(),
				mHandler, HANDLER_WHAT_VERSION).start();
	}

	private String getVersionName() {
		try {
			PackageManager packageManager = getPackageManager();
			PackageInfo packInfo = packageManager.getPackageInfo(
					getPackageName(), 0);
			String version = packInfo.versionName;
			return version;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return "1.0.0";
	}

	private void startUpdate(UpdateVersionBean bean) {
		Intent intent = new Intent(this, UpdataLoaderService.class);
		intent.putExtra("url", bean.url);
		intent.putExtra("version", bean.versionName);
		startService(intent);
	}

	private void showUpdateDialog(final UpdateVersionBean bean) {
		DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if (which == DialogInterface.BUTTON_NEGATIVE) {
					SettingsBean.getInstance().putSettingValue(
							Constans.UPDATE_PROMPT_TIME,
							System.currentTimeMillis() + "");
					SettingsBean.save();
				} else {
					if(NetUtils.isWifiConnected(MenuActivity.this)){
						startUpdate(bean);
					}else{
						AlertDialog.Builder builder = new AlertDialog.Builder(MenuActivity.this);
						builder.setTitle("警告");
						builder.setMessage("您未使用WIFI，请确认是否下载更新");
						DialogInterface.OnClickListener l = new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								if(which == DialogInterface.BUTTON_POSITIVE){
									startUpdate(bean);
								}
							}
						};
						builder.setPositiveButton("更新", l);
						builder.setNegativeButton("取消", null);
						builder.create().show();
						
					}
				}
			}
		};
		new AlertDialog.Builder(this).setTitle(R.string.app_prompt)
				.setMessage(bean.info)
				.setPositiveButton(R.string.app_update, listener)
				.setNegativeButton(R.string.app_Ignore_update, listener).show();
	}

	@Override
	protected void onResume() {
		super.onResume();
		mKeyBackNumber = 0;
		if(!NewsPaperBaseActivity.isLogin){
			NewsPaperBaseActivity.isLogin = true;
			Intent intent = new Intent(this, LoginActivity.class);
			startActivity(intent);
			finish();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 100 && resultCode == 1) {
			Intent intent = new Intent(this, LoginActivity.class);
			startActivity(intent);
			finish();
		}else if(requestCode == REQUEST_NEWSPAPER){
			if(!NewsPaperBaseActivity.isLogin){
				Intent intent = new Intent(this, LoginActivity.class);
				startActivity(intent);
				finish();
				return;
			}
			if(resultCode == NewsPaperBaseActivity.RESULT_NOTLOGIN){
				Intent intent = new Intent(this, LoginActivity.class);
				startActivity(intent);
				finish();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (mKeyBackNumber == 0) {
				mKeyBackNumber++;
				BaseApp.showToast(R.string.app_exit_msg);
			} else {
				showLogoutDialog();
//				finish();
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	public void onClick(View v) {
		if (v.getId() == R.id.menu_settings) {
			Intent intent = new Intent(this, SettingsActivity.class);
			startActivityForResult(intent, 100);
		} else if (v.getId() == R.id.menu_favour) {
//			Intent intent = new Intent(this, PhotoBrowseActivity2.class);
			Intent intent = new Intent(this, FavourMenuActivity.class);
			startActivity(intent);
		} else if (v.getId() == R.id.menu_add) {
			Intent intent = new Intent(this, SubscriptionActivity.class);
			startActivity(intent);
		} else if (v.getId() == R.id.menu_del) {
			Intent intent = new Intent(this, ClearActivity.class);
			startActivity(intent);
			mKeyBackNumber = 0;
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		if (position == 0) {
			Intent intent = new Intent(this, InformationActivity.class);
			startActivity(intent);
		} else if (position == 1) {
			Intent intent = new Intent(this, MagazineActivity.class);
			startActivity(intent);
		} else if (position == 2) {
			Intent intent = new Intent(this, ContactTabActivity.class);
//			intent.putExtra("org_id", 0 + "");
//			intent.putExtra("org_name", getString(R.string.app_jianfa));
			startActivity(intent);
		} else if(position == 3){
			Intent intent = new Intent(this,WebViewActivity.class);
			intent.putExtra("url", LoginBean.getInstance().xphoneUrl);
			startActivity(intent);
		} else if(position == 4){
			Intent intent = new Intent(this, ArticleListActivity.class);
			intent.putExtra("channel", "内部商城");
			intent.putExtra("id", "6");
			HashMap<String, String> maps = new HashMap<String, String>();
			maps.put("资讯类别名称","内部商城"+"");
			maps.put("资讯类别id", 6 +"");
			MobclickAgent.onEvent(MenuActivity.this, UmengEvent.intoInfoCategoryEvent, maps);
			startActivity(intent);
		}else if(position == 5){
			Intent intent = new Intent(this, ArticleImgListActivity.class);
			intent.putExtra("channel", "办事指南");
			intent.putExtra("id", "11");
			HashMap<String, String> maps = new HashMap<String, String>();
			maps.put("资讯类别名称","办事指南"+"");
			maps.put("资讯类别id", 11 +"");
			MobclickAgent.onEvent(MenuActivity.this, UmengEvent.intoInfoCategoryEvent, maps);
			startActivity(intent);
		}else if(position == 6){
			Intent intent = new Intent(this, MainActivity.class);
			NewsPaperBaseActivity.isExist = false;
			NewsPaperBaseActivity.isLogin = true;
			startActivityForResult(intent, REQUEST_NEWSPAPER);	
		}
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_WHAT_VERSION) {
				UpdateVersionBean bean = (UpdateVersionBean) msg.obj;
				if (bean != null && bean.code == 0) {
					String version = getVersionName();
					if (!version.equals(bean.versionName)) {
						String timeString = SettingsBean.getInstance()
								.getSettingValueByName(
										Constans.UPDATE_PROMPT_TIME);
//						timeString = null;
						boolean timeOut = (timeString == null);
						if (!timeOut) {
							long time = Long.valueOf(timeString);
							long span = System.currentTimeMillis() - time;
							timeOut = (span > Constans.UPDATE_IGNORE_TIME);
						}
						if (timeOut) {
							showUpdateDialog(bean);
						}
					}
				}
			} else if (msg.what == 104) {
				mProgrees.dismiss();
			}
		};
	};
	
	private void showLogoutDialog() {
		new AlertDialog.Builder(this)
				.setTitle(R.string.app_prompt)
				.setMessage(R.string.settings_logout_message)
				.setPositiveButton(R.string.app_ok,
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								BaseApp mBaseApp = (BaseApp) getApplication();
								mBaseApp.setIsProgramExist(true);
								finish();
							}
						}).setNegativeButton(R.string.app_cancel, null).show();
	}
	
}