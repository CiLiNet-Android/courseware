﻿package com.suncco.chinacdc.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.scheme.SocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.util.Log;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;

/**
 * 获取网络图片各种操作
 * 
 * @author user
 * 
 */
public class WebResourceUtils {

	public static final int CONNECTION_VALUE = 40 * 1000;
	public static final int TIME_OUT_VALUE = 80 * 1000;
	public static final String PARAMS_NAME = "name";
	public static final String PARAMS_VALUE = "value";
	public static final String POST = "POST";
	public static final String GET = "GET";

	/**
	 * 从指定URL中获取json数据 params 参数
	 * 
	 * @param url
	 * @return
	 */
	public static String getJsonData(String url,
			ArrayList<HashMap<String, String>> params) {

		if (Constans.DEBUG) {
			Log.i("Sportica Http", url + "");
		}

		DefaultHttpClient client = getHttpClient();
		HttpPost post = new HttpPost(url);
		List<NameValuePair> pair = new ArrayList<NameValuePair>();
		pair.add(new BasicNameValuePair("IMEI", BaseApp.sOnlyMark + ""));
		if (params != null) {
			int len = params.size();
			for (int i = 0; i < len; i++) {
				HashMap<String, String> map = params.get(i);

				String value = map.get(PARAMS_VALUE);
				if (value != null) {
					try {
						value = new String(map.get(PARAMS_VALUE).getBytes(
								HTTP.UTF_8), HTTP.ISO_8859_1);
						pair.add(new BasicNameValuePair(map.get(PARAMS_NAME),
								value));
						LogUtil.i("getJsonData : url " + url + "  name : "
								+ map.get(PARAMS_NAME) + ", value: "
								+ map.get(PARAMS_VALUE));
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			try {
				post.setEntity(new UrlEncodedFormEntity(pair));
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				if (Constans.DEBUG)
					e1.printStackTrace();
				return null;
			}
		} else {
			try {
				post.setEntity(new UrlEncodedFormEntity(pair));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				if (Constans.DEBUG)
					e.printStackTrace();
				return null;
			}
		}

		int statusCode = -1;
		try {
			HttpResponse response = client.execute(post);
			statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				if (Constans.DEBUG) {
					System.out.println("--url:" + url + ", error statusCode="
							+ statusCode);
				}
				return null;
			}
			InputStream is = response.getEntity().getContent();
			BufferedReader br = new BufferedReader(new InputStreamReader(is,
					HTTP.UTF_8));
			StringBuffer sb = new StringBuffer();
			String tmp = null;
			while ((tmp = br.readLine()) != null) {
				sb.append(tmp);
				sb.append("\n");
			}
			return sb.toString();
		} catch (Exception e) {
			if (Constans.DEBUG) {
				Log.i("Sportica Http Exception", url + ", statusCode="
						+ statusCode);
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * 小图片下载(无缓存)
	 * 
	 * @param weatherId
	 * @return
	 */
	public static Bitmap downloadImage(String imgUrl) {
		if (Constans.DEBUG)
			Log.i("mantou", "开始加载图片");
		if (imgUrl == null)
			return null;
		String defaultHost = Proxy.getDefaultHost();
		int defaultPort = Proxy.getDefaultPort();
		ConnectivityManager connectivityManager = (ConnectivityManager) BaseApp.sContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		int type = activeNetworkInfo == null ? 0 : activeNetworkInfo.getType();
		if (type == ConnectivityManager.TYPE_MOBILE && defaultHost != null
				&& defaultPort != -1) {
			imgUrl = imgUrl.substring(7);
			String host = imgUrl.substring(0, imgUrl.indexOf("/"));
			imgUrl = imgUrl.substring(imgUrl.indexOf("/"));
			imgUrl = "http://" + defaultHost + ":80" + imgUrl;
			URL url;
			try {
				url = new URL(imgUrl);
				HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
				conn.setRequestProperty("X-Online-Host", host);
				InputStream is = conn.getInputStream();
				Bitmap bm = BitmapFactory.decodeStream(is);
				is.close();
				return bm;
			} catch (MalformedURLException e) {
				if (Constans.DEBUG)
					e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		} else {
			try {
				URL aryURI = new URL(imgUrl);
				URLConnection conn = aryURI.openConnection();
				conn.connect();
				InputStream is = conn.getInputStream();
				Bitmap bm = BitmapFactory.decodeStream(is);
				is.close();
				return bm;
			} catch (IOException e) {
				if (Constans.DEBUG) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * 图片加载,本地缓存
	 * 
	 * @param url
	 * @param url
	 * @return 0 failed 1 succeed 2 exists
	 */
	public static int downloadObj(String url) {
		if (Constans.DEBUG) {
			Log.i("图片加载", url + "");
		}
		if (url == null)
			return 0;
		File file = new File(Constans.IMG_DIR);
		if (!file.isDirectory()) {
			file.mkdirs();
		}
		String path = Constans.IMG_DIR + url.hashCode();
		File f = new File(path);
		if (f.exists())
			return 2;

		InputStream in = null;
		FileOutputStream out = null;
		byte[] buf = new byte[2048];

		String defaultHost = Proxy.getDefaultHost();
		int defaultPort = Proxy.getDefaultPort();
		ConnectivityManager connectivityManager = (ConnectivityManager) BaseApp.sContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		int type = activeNetworkInfo == null ? 0 : activeNetworkInfo.getType();
		if (type == ConnectivityManager.TYPE_MOBILE && defaultHost != null
				&& defaultPort != -1) {
			url = url.substring(7);
			String host = url.substring(0, url.indexOf("/"));
			url = url.substring(url.indexOf("/"));
			url = "http://" + defaultHost + ":80" + url;
			URL myUrl;
			try {
				myUrl = new URL(url);
				HttpURLConnection conn = (HttpURLConnection) myUrl
						.openConnection();
				conn.setRequestProperty("X-Online-Host", host);
				in = conn.getInputStream();
				out = new FileOutputStream(path);
				int i;
				while ((i = in.read(buf)) != -1) {
					out.write(buf, 0, i);
				}
				return 1;
			} catch (Exception e) {
				if (Constans.DEBUG)
					if (Constans.DEBUG) {
						Log.i("exception", " url" + url);
					}
				if (f.exists())
					f.delete();
			} finally {
				if (out != null)
					try {
						out.close();
					} catch (IOException e) {
						if (Constans.DEBUG)
							Log.i("exception", " url: " + url);
					}
			}
		} else {

			try {
				URL u = new URL(url);
				URLConnection conn = u.openConnection();
				in = conn.getInputStream();
				out = new FileOutputStream(f);
				int i;
				while ((i = in.read(buf)) != -1) {
					out.write(buf, 0, i);
				}
				return 1;
			} catch (Exception e) {
				if (f.exists())
					f.delete();
				if (Constans.DEBUG)
					if (Constans.DEBUG) {
						Log.i("exception", " url: " + url);
					}
			} finally {
				if (out != null)
					try {
						out.close();
					} catch (IOException e) {
						if (Constans.DEBUG)
							Log.i("exception", " url: " + url);
					}
			}
		}

		return 0;
	}
	
	/**
	 * 下载文件到本地
	 * 
	 * @param url
	 * @param url
	 * @return 0 failed 1 succeed 2 exists
	 */
	public static int downloadFile(String url,String path) {
		if (Constans.DEBUG) {
			Log.i("下载文件", url + "");
		}
		if (url == null)
			return 0;
//		String path = Constans.IMG_DIR + url.hashCode();
		File f = new File(path);
		if (f.exists())
			return 2;

		InputStream in = null;
		FileOutputStream out = null;
		byte[] buf = new byte[2048];

		String defaultHost = Proxy.getDefaultHost();
		int defaultPort = Proxy.getDefaultPort();
		ConnectivityManager connectivityManager = (ConnectivityManager) BaseApp.sContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		int type = activeNetworkInfo == null ? 0 : activeNetworkInfo.getType();
		if (type == ConnectivityManager.TYPE_MOBILE && defaultHost != null
				&& defaultPort != -1) {
			url = url.substring(7);
			String host = url.substring(0, url.indexOf("/"));
			url = url.substring(url.indexOf("/"));
			url = "http://" + defaultHost + ":80" + url;
			URL myUrl;
			try {
				myUrl = new URL(url);
				HttpURLConnection conn = (HttpURLConnection) myUrl
						.openConnection();
				conn.setRequestProperty("X-Online-Host", host);
				in = conn.getInputStream();
				out = new FileOutputStream(path);
				int i;
				while ((i = in.read(buf)) != -1) {
					out.write(buf, 0, i);
				}
				return 1;
			} catch (Exception e) {
				if (Constans.DEBUG)
					if (Constans.DEBUG) {
						Log.i("exception", " url" + url);
					}
				if (f.exists())
					f.delete();
			} finally {
				if (out != null)
					try {
						out.close();
					} catch (IOException e) {
						if (Constans.DEBUG)
							Log.i("exception", " url: " + url);
					}
			}
		} else {

			try {
				URL u = new URL(url);
				URLConnection conn = u.openConnection();
				in = conn.getInputStream();
				out = new FileOutputStream(f);
				int i;
				while ((i = in.read(buf)) != -1) {
					out.write(buf, 0, i);
				}
				return 1;
			} catch (Exception e) {
				if (f.exists())
					f.delete();
				if (Constans.DEBUG)
					if (Constans.DEBUG) {
						Log.i("exception", " url: " + url);
					}
			} finally {
				if (out != null)
					try {
						out.close();
					} catch (IOException e) {
						if (Constans.DEBUG)
							Log.i("exception", " url: " + url);
					}
			}
		}

		return 0;
	}

	public static DefaultHttpClient getHttpClient() {

		// Shamelessly cribbed from AndroidHttpClient
		HttpParams params = new BasicHttpParams();

		// Turn off stale checking. Our connections break all the time anyway,
		// and it's not worth it to pay the penalty of checking every time.
		HttpConnectionParams.setStaleCheckingEnabled(params, false);

		// Default connection and socket timeout of 10 seconds. Tweak to taste.
		HttpConnectionParams.setConnectionTimeout(params, CONNECTION_VALUE);
		HttpConnectionParams.setSoTimeout(params, TIME_OUT_VALUE);
		HttpConnectionParams.setSocketBufferSize(params, 8192);

		// Sets up the http part of the service.
		final SchemeRegistry supportedSchemes = new SchemeRegistry();

		// Register the "http" protocol scheme, it is required
		// by the default operator to look up socket factories.
		final SocketFactory sf = PlainSocketFactory.getSocketFactory();
		supportedSchemes.register(new Scheme("http", sf, 80));

		final ClientConnectionManager ccm = new ThreadSafeClientConnManager(
				params, supportedSchemes);
		DefaultHttpClient httpClient = new DefaultHttpClient(ccm, params);

		// -----for proxy
		String defaultHost = Proxy.getDefaultHost();
		int defaultPort = Proxy.getDefaultPort();
		ConnectivityManager connectivityManager = (ConnectivityManager) BaseApp.sContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		int type = activeNetworkInfo == null ? 0 : activeNetworkInfo.getType();
		if (type == ConnectivityManager.TYPE_MOBILE && defaultHost != null
				&& defaultPort != -1) {
			HttpHost proxy = new HttpHost(defaultHost, defaultPort);
			httpClient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,
					proxy);
			if (Constans.DEBUG) {
				Log.i("getData", "代理");
			}
		} else {
			if (Constans.DEBUG) {
				Log.i("getData", "无代理");
			}
		}
		// -----for proxy end

		return httpClient;
	}

	/**
	 * @param String
	 *            url
	 * @param String
	 *            int requestMethodType 0 GET 非0 POST
	 * @param String
	 *            HashMap<String, String> requestPropertys 头参数 HashMap<String
	 *            field, String newValue>
	 */
	public static HttpURLConnection getHttpURLConnection(URL url,
			String requestMethod, HashMap<String, String> requestPropertys) {
		HttpURLConnection http;
		try {
			http = (HttpURLConnection) url.openConnection();
			http.setConnectTimeout(CONNECTION_VALUE);
			http.setRequestMethod(requestMethod);
			HttpURLConnection.setFollowRedirects(true);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		requestPropertys
				.put("Accept",
						"image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/xaml+xml, application/vnd.ms-xpsdocument, application/x-ms-xbap, application/x-ms-application, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*");
		requestPropertys.put("Accept-Language", "zh-CN");
		requestPropertys.put("Charset", "UTF-8");
		requestPropertys
				.put("User-Agent",
						"Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)");
		requestPropertys.put("Connection", "Keep-Alive");
		Iterator<Entry<String, String>> iter = requestPropertys.entrySet()
				.iterator();
		while (iter.hasNext()) {
			Entry<String, String> entry = (Entry<String, String>) iter.next();
			http.setRequestProperty(entry.getKey(), entry.getValue());
		}
		return http;
	}

}
