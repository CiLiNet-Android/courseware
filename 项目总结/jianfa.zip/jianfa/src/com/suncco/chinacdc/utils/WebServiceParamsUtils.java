package com.suncco.chinacdc.utils;

import java.util.ArrayList;
import java.util.HashMap;

public class WebServiceParamsUtils {

	ArrayList<HashMap<String, String>> mParams;

	public ArrayList<HashMap<String, String>> formatParams() {
		return mParams;
	}

	public void addNameAndValue(String name, String value) {
		if (mParams == null) {
			mParams = new ArrayList<HashMap<String, String>>();
		}
		HashMap<String, String> map = new HashMap<String, String>();
		map.put(WebService.NAME, name);
		map.put(WebService.VALUE, value);
		mParams.add(map);
	}
}
