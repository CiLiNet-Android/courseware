package com.suncco.chinacdc.utils;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.PhotoBean;
import com.suncco.chinacdc.bean.UserBean;
import com.suncco.chinacdc.downloader.ThreadPoolHelper;

public class PhotoImagesThread extends Thread {

	private final int HANDLER_PHOTOBEAN_RESULT = 101;

	private Handler mHandler;
	private String[] mImagesUrl;
	public boolean mIsCancel = false;
	private int mWhat;

	private Handler iHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case HANDLER_PHOTOBEAN_RESULT:
				final PhotoBean bean = (PhotoBean) msg.obj;
				if (bean == null) {
				} else {
					LogUtil.e("下载到图片啦！！！");
					Bitmap bitmap = ImageUtils.stringtoBitmap(bean.photo);
					if (bitmap != null) {
						ImageUtils.saveMyBitmap(bitmap, Constans.IMG_DIR
								+ bean.id);
						bitmap.recycle();
						mHandler.sendEmptyMessage(PhotoImagesThread.this.mWhat);
					} else {
					}

				}
				break;

			}
		}

	};

	/**
	 * 多张张图片下载 handler。what 100
	 * 
	 * @param handler
	 * @param img
	 */
	public PhotoImagesThread(Handler handler, String[] imgs, int what) {
		this.mHandler = handler;
		this.mImagesUrl = imgs;
		this.mWhat = what;
	}

	/**
	 * 单独一张图片下载 handler。what 101
	 * 
	 * @param handler
	 * @param img
	 */
	public PhotoImagesThread(Handler handler, String img, int what) {
		this.mHandler = handler;
		this.mImagesUrl = new String[] { img };
		this.mWhat = what;
	}

	@Override
	public void run() {
		super.run();
		if (Constans.DEBUG) {
			Log.i("ImagesThread", "start");
		}
		if (mImagesUrl != null) {
			int len = mImagesUrl.length;
			Bitmap bm;
			for (int i = 0; i < len; i++) {
				if (mIsCancel) {
					break;
				}
				
				bm = ImageUtils.getBitmap(Constans.IMG_DIR + mImagesUrl[i]);
				if (bm != null) {

				} else {
					WebServiceParamsUtils utils = new WebServiceParamsUtils();
					utils.addNameAndValue("imageId", mImagesUrl[i]+"");
					utils.addNameAndValue("sessionId",
							LoginBean.getInstance().sessionId + "");
					new ChinacdcThread(PhotoBean.class, utils.formatParams(),
							iHandler, HANDLER_PHOTOBEAN_RESULT).start();
				}
				
			}
		}
	}
}
