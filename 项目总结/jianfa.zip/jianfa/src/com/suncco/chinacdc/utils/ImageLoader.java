package com.suncco.chinacdc.utils;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import android.graphics.Bitmap;
import android.util.Log;

import com.suncco.chinacdc.Constans;

/**
 * 已下载好图片的读取 弱引用 单例
 * 
 * @author suncco10036
 * 
 */
public class ImageLoader {

	private static ImageLoader sImageLoader;

	private Map<String, WeakReference<Bitmap>> mImageCacheMap = new HashMap<String, WeakReference<Bitmap>>();
	private Map<String, WeakReference<Bitmap>> mImageCacheMapOrg = new HashMap<String, WeakReference<Bitmap>>();
	private ImageLoader() {

	}

	public static synchronized ImageLoader getInstance() {
		if (sImageLoader == null) {
			sImageLoader = new ImageLoader();
		}
		return sImageLoader;
	}

	/**
	 * 
	 * @param url
	 *            以图片的Constans.IMG_DIR + url.hashCode来确定图片本地地址
	 * @return
	 */
	public Bitmap loadBitmapByUrl(final String url) {
		if (url == null) {
			return null;
		}
		String path = Constans.IMG_DIR + url.hashCode();
		if (mImageCacheMap.containsKey(path)) {
			WeakReference<Bitmap> softReference = mImageCacheMap.get(path);
			if (softReference.get() != null) {
				return softReference.get();
			}
		}
		if (new File(path).exists()) {
			Bitmap bm = ImageUtils.getBitmap(path);
			if(bm != null){
				WeakReference<Bitmap> softReference1 = new WeakReference<Bitmap>(
						bm);
				mImageCacheMap.put(path, softReference1);
				return softReference1.get();
			}else{
				return ImageUtils.getBitmapHalf(path);
			}
		}
		if (Constans.DEBUG)
			Log.i("图片缓存", getSize() + "");
		return null;
	}
	
	public Bitmap loadBitmapOrgByUrl(final String url) {
		if (url == null) {
			return null;
		}
		String path = Constans.IMG_DIR + url.hashCode();
		if (mImageCacheMapOrg.containsKey(path)) {
			WeakReference<Bitmap> softReference = mImageCacheMapOrg.get(path);
			if (softReference.get() != null) {
				return softReference.get();
			}
		}
		if (new File(path).exists()) {
			Bitmap bm = ImageUtils.getBitmapOrg(path);
			if(bm != null){
				WeakReference<Bitmap> softReference1 = new WeakReference<Bitmap>(
						bm);
				mImageCacheMapOrg.put(path, softReference1);
				return softReference1.get();
			}else{
				return ImageUtils.getBitmapHalf(path);
			}
		}
		if (Constans.DEBUG)
			Log.i("图片缓存", getSize() + "");
		return null;
	}
	

	public Bitmap loadBitmapByPath(final String path) {
		if (path == null) {
			return null;
		}
		if (mImageCacheMap.containsKey(path)) {
			WeakReference<Bitmap> softReference = mImageCacheMap.get(path);
			if (softReference.get() != null) {
				return softReference.get();
			}
		}
		if (new File(path).exists()) {
			Bitmap bm = ImageUtils.getBitmap(path);
			if(bm != null){
				WeakReference<Bitmap> softReference1 = new WeakReference<Bitmap>(
						bm);
				mImageCacheMap.put(path, softReference1);
				return softReference1.get();
			}else{
				return ImageUtils.getBitmapHalf(path);
			}
		}
		return null;
	}
	
	public Bitmap loadBitmapOrgByPath(final String path) {
		if (path == null) {
			return null;
		}
		if (mImageCacheMapOrg.containsKey(path)) {
			WeakReference<Bitmap> softReference = mImageCacheMapOrg.get(path);
			if (softReference.get() != null) {
				return softReference.get();
			}
		}
		if (new File(path).exists()) {
			Bitmap bm = ImageUtils.getBitmapOrg(path);
			if(bm != null){
				WeakReference<Bitmap> softReference1 = new WeakReference<Bitmap>(
						bm);
				mImageCacheMapOrg.put(path, softReference1);
				return softReference1.get();
			}else{
				return ImageUtils.getBitmapHalf(path);
			}
		}
		return null;
	}

	public int getSize() {
		int size = 0;
		Set<String> sets = mImageCacheMap.keySet();
		Iterator<String> iterator = sets.iterator();
		while (iterator.hasNext()) {
			WeakReference<Bitmap> ref = mImageCacheMap.get(iterator.next());
			if (ref == null) {
				continue;
			}
			Bitmap bitmap = ref.get();
			if (bitmap != null) {
				size++;
			}
		}
		return size;
	}
	
	public void clearCache(){
		if(mImageCacheMap != null)
		mImageCacheMap.clear();
		if(mImageCacheMapOrg != null)
			mImageCacheMapOrg.clear();
	}
}
