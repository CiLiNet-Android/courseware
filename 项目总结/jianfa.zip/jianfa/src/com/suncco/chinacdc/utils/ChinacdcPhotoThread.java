package com.suncco.chinacdc.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.PhotoBean;

public class ChinacdcPhotoThread extends Thread {

	public static final int THREAD_CANCEL_RESULT = 404;
	private static final String SERVER_URL = "serverUrl";
	private static final String NAME_SPACE = "nameSpace";
	private static final String METHOD_NAME = "methodName";
	private boolean mIsCancel;
	private ArrayList<HashMap<String, String>> params;
	private Handler mHandler;
	private int mWhat = -1;
	private Class<?> mBaseBeanClass;
	
	private String[] imgs;
	private Bitmap bm;

	/**
	 * <name,value>
	 * 
	 * @param params
	 * @param c
	 * @param handler
	 * @param what
	 */
	public ChinacdcPhotoThread(Class<?> baseBean,
			String[] imgs, Handler handler, int what) {
//		this.params = params;
		this.imgs = imgs;
		this.mBaseBeanClass = baseBean;
		this.mHandler = handler;
		this.mWhat = what;
	}

	public void cancel() {
		mIsCancel = true;
	}

	@Override
	public void run() {
		super.run();
		String serverUrl = getValue(mBaseBeanClass, SERVER_URL);
		String nameSpace = getValue(mBaseBeanClass, NAME_SPACE);
		String methodName = getValue(mBaseBeanClass, METHOD_NAME);
		
		for(int i = 0 ,l = imgs.length; i < l ; i ++){
			bm = ImageUtils.getBitmap(Constans.IMG_DIR + imgs[i]);
			if (bm != null) {
			} else {
			WebServiceParamsUtils utils = new WebServiceParamsUtils();
			utils.addNameAndValue("imageId", imgs[i] + "");
			utils.addNameAndValue("sessionId",
					LoginBean.getInstance().sessionId + "");
			params = utils.formatParams();
			SoapObject SoapObject = WebService.getInfo(serverUrl, nameSpace,
					methodName, params);
			LogUtil.i("method_name : " + methodName + "  SoapObje : "
					+ (SoapObject == null ? "null" : "头像下载成功"));
			if (mHandler != null) {
				if (mIsCancel) {
					mHandler.sendEmptyMessage(THREAD_CANCEL_RESULT);
					return;
				}
				Object obj = invokeStaticMethod(mBaseBeanClass, SoapObject);
				if(obj != null){
					PhotoBean bean = (PhotoBean)obj;
					Bitmap bitmap = ImageUtils.stringtoBitmap(bean.photo);
					if (bitmap != null) {
						ImageUtils.saveMyBitmap(bitmap, Constans.IMG_DIR
								+ bean.id);
						ImageLoader.getInstance().loadBitmapByPath(Constans.IMG_DIR
								+ bean.id);
						bitmap.recycle();
						mHandler.sendEmptyMessage(mWhat);
					} else {
					}
				}
//				mHandler.sendEmptyMessage(mWhat);
			}
			}
		}
	}

	private Object invokeStaticMethod(Class<?> c, SoapObject SoapObject) {
		String methodName = "parse" + c.getSimpleName();
		Method method;
		try {
			method = c.getMethod(methodName, SoapObject.class);
			return method.invoke(null, SoapObject);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getValue(Class<?> c, String fieldName) {
		try {
			Field f = c.getField(fieldName);
			return f.get(null).toString();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
}
