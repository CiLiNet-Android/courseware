package com.suncco.chinacdc.utils;

import java.util.ArrayList;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Contacts.People;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.CommonDataKinds.StructuredName;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.RawContacts;
import android.text.TextUtils;
import android.util.Log;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.UserBean;

public class ContactUtils {

	/**
	 * 首先向RawContacts.CONTENT_URI执行一个空值插入，目的是获取系统返回的rawContactId
	 * 这时后面插入data表的依据，只有执行空值插入，才能使插入的联系人在通讯录里面可见
	 */
	public static boolean insertContact(UserBean user) throws Exception {
//		if (contactsExit(user.name)) {
//			return false;
//		}
		ContentValues values = new ContentValues();
		// 首先向RawContacts.CONTENT_URI执行一个空值插入，目的是获取系统返回的rawContactId
		Uri rawContactUri = BaseApp.sContext.getContentResolver().insert(
				RawContacts.CONTENT_URI, values);
		long rawContactId = ContentUris.parseId(rawContactUri);
		// 往data表入姓名数据
		values.clear();
		values.put(Data.RAW_CONTACT_ID, rawContactId);
		values.put(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE);// 内容类型
		values.put(StructuredName.GIVEN_NAME, user.name);
//		values.put(People.NAME, user.name);
		
		try {
			BaseApp.sContext.getContentResolver().insert(
					android.provider.ContactsContract.Data.CONTENT_URI, values);
		} catch (Exception e) {
			values.clear();
			values.put(Data.RAW_CONTACT_ID, rawContactId);
			values.put(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE);// 内容类型
			values.put(StructuredName.DISPLAY_NAME, user.name);
			try {
				BaseApp.sContext.getContentResolver().insert(
						android.provider.ContactsContract.Data.CONTENT_URI, values);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		
		}
		// 往data表入电话数据
		if (!TextUtils.isEmpty(user.phone1)) {
			values.clear();
			values.put(Data.RAW_CONTACT_ID, rawContactId);
			values.put(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE);
			values.put(Phone.NUMBER, user.phone1);
			values.put(Phone.TYPE, Phone.TYPE_MOBILE);
			BaseApp.sContext.getContentResolver().insert(
					android.provider.ContactsContract.Data.CONTENT_URI, values);
		}
		// 固定电话
		if (!TextUtils.isEmpty(user.telephone)) {
			values.clear();
			values.put(Data.RAW_CONTACT_ID, rawContactId);
			values.put(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE);
			values.put(Phone.NUMBER, user.telephone);
			values.put(Phone.TYPE, Phone.TYPE_HOME);
			BaseApp.sContext.getContentResolver().insert(
					android.provider.ContactsContract.Data.CONTENT_URI, values);
		}
		
		// 往data表入Email数据
		if (!TextUtils.isEmpty(user.email)) {
			values.clear();
			values.put(Data.RAW_CONTACT_ID, rawContactId);
			values.put(Data.MIMETYPE, Email.CONTENT_ITEM_TYPE);
			values.put(Email.DATA, user.email);
			values.put(Email.TYPE, Email.TYPE_WORK);
			BaseApp.sContext.getContentResolver().insert(
					android.provider.ContactsContract.Data.CONTENT_URI, values);
		}
		return true;
	}
	
	public static long insertContactFirest(UserBean user){
		ContentValues values = new ContentValues();
		// 首先向RawContacts.CONTENT_URI执行一个空值插入，目的是获取系统返回的rawContactId
		Uri rawContactUri = BaseApp.sContext.getContentResolver().insert(
				RawContacts.CONTENT_URI, values);
		long rawContactId = ContentUris.parseId(rawContactUri);
		// 往data表入姓名数据
		values.clear();
		values.put(Data.RAW_CONTACT_ID, rawContactId);
		values.put(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE);// 内容类型
		values.put(StructuredName.GIVEN_NAME, user.name);
//		values.put(People.NAME, user.name);
		
		try {
			BaseApp.sContext.getContentResolver().insert(
					android.provider.ContactsContract.Data.CONTENT_URI, values);
		} catch (Exception e) {
			values.clear();
			values.put(Data.RAW_CONTACT_ID, rawContactId);
			values.put(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE);// 内容类型
			values.put(StructuredName.DISPLAY_NAME, user.name);
			try {
				BaseApp.sContext.getContentResolver().insert(
						android.provider.ContactsContract.Data.CONTENT_URI, values);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		
		}
		return rawContactId;
	}

	/**
	 * 通过姓名(uName)来查找通讯录，返回一个list。 其中"display_name"保存姓名,"phone_number"保存电话
	 */
	public static int getContactsByName(String uName) {
		// 查询条件，SQL是的Where语句的后部分
		String selection = ContactsContract.CommonDataKinds.StructuredName.GIVEN_NAME
				+ "='" + uName + "'";
		// System.out.println("Query For Some--" + selection);
		try {
			// 根据姓名查询出完整姓名和通讯录ID
			Uri uri = Uri.parse("content://com.android.contacts/data/phones");
			ContentResolver resolver = BaseApp.sContext.getContentResolver();
			Cursor cursor = resolver
					.query(uri,
							new String[] {
									ContactsContract.Data.RAW_CONTACT_ID,
									ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME },
							selection, null, null);
			while (cursor.moveToNext()) {
				LogUtil.i(".....查询结果");
			}
			return cursor.getCount();
			// 根据通讯录ID，查找对应的电话号码的查询条件，主要用于cn游标
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	/**
	 * 从通讯录获取联系人
	 * 
	 * @throws Throwable
	 */
	public static boolean contactsExit(String name) {
		ContentResolver resolver = BaseApp.sContext.getContentResolver();
		String selection = Phone.DISPLAY_NAME + "='" + name + "'";
		Cursor cursor = resolver.query(Phone.CONTENT_URI, null, selection,
				null, null);
		boolean exit = !cursor.isAfterLast();
		cursor.close();
		return exit;
	}

	/**
	 * 发送短信
	 * 
	 * @param msg
	 *            短信内容
	 */
	public static void sendSMS(Context context, String number, String body) {
		try {
			String head = "smsto://";
			if (number.contains(";")) {
				head = "smsto:";
			}
			LogUtil.e("number ---->" + number);
			Uri smsToUri = Uri.parse(head + number);
			Intent mIntent = new Intent(android.content.Intent.ACTION_SENDTO,
					smsToUri);
			mIntent.putExtra("sms_body", body);
			mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			// Intent mIntent = new Intent(Intent.ACTION_VIEW);
			// mIntent.putExtra("address", number);
			// mIntent.setType("vnd.android-dir/mms-sms");
			context.startActivity(mIntent);
		} catch (Exception e) {
			BaseApp.showToast(R.string.contact_msm_exc);
		}
	}

	public static void call(Context context, String number) {
		try {
			Intent intent = new Intent();
			intent.setAction("android.intent.action.CALL");
			intent.setData(Uri.parse("tel:" + number));
			context.startActivity(intent);
		} catch (Exception e) {
			BaseApp.showToast(R.string.contact_call_exc);
		}
	}

	public static void sendEmial(Context context, String emial) {
		Intent mEmailIntent = new Intent(android.content.Intent.ACTION_SEND);
		mEmailIntent.setType("plain/text");
		String[] strEmailReceive = new String[] { emial };
		mEmailIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		mEmailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
				strEmailReceive);
		mEmailIntent.putExtra(android.content.Intent.EXTRA_CC, "");
		mEmailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
		mEmailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
		context.startActivity(Intent.createChooser(mEmailIntent, "Send Email"));
	}

	public static void bitchSendMSM(Context context, ArrayList<UserBean> beans) {
		ArrayList<UserBean> userBeans = new ArrayList<UserBean>();

		for (UserBean bean : beans) {
			if(userBeans.size() == 0){
				userBeans.add(bean);
			}else{
				boolean isRepeat = false;
				for (int i=0,l = userBeans.size() ; i < l ;i++) {
					if (bean.phone1.equals(userBeans.get(i).phone1)) {
						isRepeat = true;
					}
				}
				if(!isRepeat)userBeans.add(bean);
			}
		}

		StringBuffer buf = new StringBuffer();
		String homeMode = android.os.Build.MODEL;
		LogUtil.e("phone---->" + homeMode);
		for (int i = 0, l = userBeans.size(); i < l; i++) {
			UserBean bean = userBeans.get(i);
			buf.append(bean.phone1);
			// 正对移动i9108单独适配
			if (homeMode != null && (homeMode.equals("GT-I9108") || homeMode.equals("SCH-i929") || homeMode.equals("GT-I9300"))) {
				buf.append(",");
			} else {
//				buf.append(",");
				buf.append(";");
			}
		}
		// for (UserBean bean : beans) {
		// Log.e("append phone-->", bean.phone1);
		// if(bean.phone1.startsWith("//")){
		// bean.phone1 = bean.phone1.substring(2);
		// }
		// buf.append(bean.phone1.trim().toString());
		// // 正对移动i9108单独适配
		// if(beans.indexOf(bean) != beans.size()-1){
		// if (homeMode != null && homeMode.equals("GT-I9108")) {
		// buf.append(",");
		// } else {
		// buf.append(";");
		// }
		// }
		// }
		Log.e("buf string -->", buf.toString());
		buf.substring(0, buf.length() - 1);
		// String temp = "15880214363;15880289776;15880214363";
		sendSMS(context, buf.toString(), "");
	}
}
