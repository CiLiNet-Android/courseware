package com.suncco.chinacdc.utils;

import android.util.Log;

import com.suncco.chinacdc.Constans;

public class LogUtil {

	private static final String TAG = "COM.SUNCCO";

	public static void i(String message) {
		if (Constans.DEBUG) {
			Log.i(TAG, message);
		}
	}

	public static void i(String tag, String message) {
		if (Constans.DEBUG) {
			Log.i(tag, message);
		}
	}

	public static void e(String message) {
		Log.e(TAG, message);
	}
}
