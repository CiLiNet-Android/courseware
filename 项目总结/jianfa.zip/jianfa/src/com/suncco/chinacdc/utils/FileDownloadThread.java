package com.suncco.chinacdc.utils;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.suncco.chinacdc.Constans;

public class FileDownloadThread extends Thread {

	private Handler mHandler;
	private String url;
	private String path;
	public boolean mIsCancel = false;
	private int mWhat;

	/**
	 * 多张张图片下载 handler。what 100
	 * 
	 * @param handler
	 * @param img
	 */
	public FileDownloadThread(Handler handler, String url, String path, int what) {
		this.mHandler = handler;
		this.url = url;
		this.path = path;
		this.mWhat = what;
	}

	@Override
	public void run() {
		super.run();
		if (Constans.DEBUG) {
			Log.i("ImagesThread", "start");
		}
		if (url != null) {
			if (mIsCancel) {
				return;
			}
			int status = WebResourceUtils.downloadFile(url, path);
			if (status != 0) {
				Message msg = new Message();
				msg.what = mWhat;
				msg.obj = path;
				mHandler.handleMessage(msg);
			}
		}
	}
}
