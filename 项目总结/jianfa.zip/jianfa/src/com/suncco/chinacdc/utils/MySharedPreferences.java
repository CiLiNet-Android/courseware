package com.suncco.chinacdc.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class MySharedPreferences {
	final String SP_NAME = "suncco";
	final String SP_KEY_USER = "user";
	final String SP_KEY_PASSWORD = "password";
	final String SP_KEY_AUTOUPDATE = "auto_update";
	final String SP_KEY_AUTOLOGIN = "auto_login";
	final String SP_TOKEN = "token";
	final String SP_SEX = "sex";
	final String SP_EMAIL_NAME = "emailname";
	final String SP_EMAIL_PASSWORD= "emailpassword";
	

	private SharedPreferences mSharedPreferences;

	public MySharedPreferences(Context context) {
		mSharedPreferences = context.getSharedPreferences(SP_NAME,
				Context.MODE_PRIVATE);
	}

	private String getString(String key) {
		return mSharedPreferences.getString(key, null);
	}

	private void putString(String key, String value) {
		mSharedPreferences.edit().putString(key, value).commit();
	}
	
	@SuppressWarnings("unused")
	private int getInt(String key,int defaultValue) {
		return mSharedPreferences.getInt(key, defaultValue);
	}

	private void putInt(String key, int value) {
		mSharedPreferences.edit().putInt(key, value).commit();
	}

	public boolean getBoolean(String key) {
		return mSharedPreferences.getBoolean(key, false);
	}

	private void putBoolean(String key, boolean value) {
		mSharedPreferences.edit().putBoolean(key, value).commit();
	}

	public String getUser() {
		return getString(SP_KEY_USER);
	}

	public String getPassword() {
		return getString(SP_KEY_PASSWORD);
	}

	public void putUser(String user) {
		putString(SP_KEY_USER, user);
	}

	public void putPassword(String password) {
		putString(SP_KEY_PASSWORD, password);
	}

	public void clearUserPassword() {
		putUser(null);
		putPassword(null);
	}

	public boolean getAutoUpdate() {
		return mSharedPreferences.getBoolean(SP_KEY_AUTOUPDATE, true);
	}

	public void putAutoUpdate(boolean autoupdate) {
		putBoolean(SP_KEY_AUTOUPDATE, autoupdate);
	}

	public boolean getAutoLogin() {
		return mSharedPreferences.getBoolean(SP_KEY_AUTOLOGIN, true);
	}

	public void putAutoLogin(boolean autologin) {
		putBoolean(SP_KEY_AUTOLOGIN, autologin);
	}
	
	public String getEmailName() {
		return getString(SP_EMAIL_NAME);
	}

	public String getEmailPassword() {
		return getString(SP_EMAIL_PASSWORD);
	}

	public void putEmailName(String user) {
		putString(SP_EMAIL_NAME, user);
	}

	public void putEmailPassword(String password) {
		putString(SP_EMAIL_PASSWORD, password);
	}
	
	public void clearEmailUserPassword() {
		putEmailName(null);
		putEmailPassword(null);
	}
}
