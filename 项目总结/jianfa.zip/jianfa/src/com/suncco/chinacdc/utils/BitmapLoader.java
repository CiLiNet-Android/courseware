package com.suncco.chinacdc.utils;

import java.io.File;
import java.lang.ref.SoftReference;
import java.util.LinkedHashMap;

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.util.Log;

import com.suncco.chinacdc.Constans;

public class BitmapLoader {
	//开辟10M硬缓存空间  
    private final int hardCachedSize = 10*1024*1024; 
    
    private static BitmapLoader sBitmapLoader;
    
    private BitmapLoader() {

	}
    
    public static synchronized BitmapLoader getInstance() {
		if (sBitmapLoader == null) {
			sBitmapLoader = new BitmapLoader();
		}
		return sBitmapLoader;
	}

    
    //hard cache  
    private final LruCache<String, Bitmap> sHardBitmapCache = new LruCache<String, Bitmap>(hardCachedSize){  
        @Override 
        public int sizeOf(String key, Bitmap value){  
            return value.getRowBytes() * value.getHeight();  
        }  
        @Override  
        protected void entryRemoved(boolean evicted, String key, Bitmap oldValue, Bitmap newValue){  
            Log.v("tag", "hard cache is full , push to soft cache");  
            //硬引用缓存区满，将一个最不经常使用的oldvalue推入到软引用缓存区  
            sSoftBitmapCache.put(key, new SoftReference<Bitmap>(oldValue));  
        }  
    };
    
    //软引用  
    private static final int SOFT_CACHE_CAPACITY = 40; 
    
    private final static LinkedHashMap<String, SoftReference<Bitmap>> sSoftBitmapCache =   
        new  LinkedHashMap<String, SoftReference<Bitmap>>(SOFT_CACHE_CAPACITY, 0.75f, true){
			@Override
			public void clear() {
				// TODO Auto-generated method stub
				super.clear();
			}

			@Override
			public boolean containsValue(Object value) {
				// TODO Auto-generated method stub
				return super.containsValue(value);
			}

			@Override
			public SoftReference<Bitmap> get(Object key) {
				// TODO Auto-generated method stub
				return super.get(key);
			}

			@Override
			protected boolean removeEldestEntry(
					Entry<String, SoftReference<Bitmap>> eldest) {
				// TODO Auto-generated method stub
				if(size() > SOFT_CACHE_CAPACITY){  
	                Log.v("tag", "Soft Reference limit , purge one");  
	                return true;  
	            }  
				return super.removeEldestEntry(eldest);
			}  
    };
    
    
    
//    /**
//	 * 
//	 * @param url
//	 *            以图片的Constans.IMG_DIR + url.hashCode来确定图片本地地址
//	 * @return
//	 */
//	public Bitmap loadBitmapByUrl(final String url,int maxWith,int maxHeight) {
//		if (url == null) {
//			return null;
//		}
//		String path = Constans.IMG_DIR + url.hashCode();
//		String key = generateKey(path, maxWith, maxHeight);
//		Bitmap bitmap;
//		LogUtil.e("loadBitmapByUrl" + " maxWith:" + maxWith +"maxHeight:" +maxHeight);
//
//		bitmap = getBitmap(key);
//		if(bitmap!= null){
//			LogUtil.e("get bm" + " width:" + bitmap.getWidth() +"height:" +bitmap.getHeight());
//			return bitmap;
//		}
//		
//		if (new File(path).exists()) {
//			bitmap = ImageUtils.getBitmapBySize(path,maxWith,maxHeight);
//			if(bitmap != null){
//				putBitmap(key, bitmap);
//				return bitmap;
//			}
//			SoftReference<Bitmap> softReference  = sSoftBitmapCache.get(key);
//			if(softReference != null)
//				return softReference.get();
//			return ImageUtils.getFitSizeImg(path);	
//		}
//		if (Constans.DEBUG)
//			Log.i("图片缓存",url + "");
//		return null;
//	}
    
	/**
	 * 
	 * @param url
	 *            以图片的Constans.IMG_DIR + url.hashCode来确定图片本地地址
	 * @return
	 */
	public Bitmap loadBitmapByPath(String path,int maxWith,int maxHeight) {
		if (path == null) {
			return null;
		}
		if(path.startsWith("http"))
		path = Constans.IMG_DIR + path.hashCode();
		String key = generateKey(path, maxWith, maxHeight);
		Bitmap bitmap;
		LogUtil.e("loadBitmapBypath" + " maxWith:" + maxWith +"maxHeight:" +maxHeight);
		bitmap = getBitmap(key);
		if(bitmap!= null){
			return bitmap;
		}
		sHardBitmapCache.evictAll();
		if (new File(path).exists()) {
			bitmap = ImageUtils.getBitmapBySize(path,maxWith,maxHeight);
			LogUtil.e("getBitmapBySize" + " maxWith:" + maxWith +"maxHeight:" +maxHeight);
			if(bitmap != null){
				putBitmap(key, bitmap);
				return bitmap;
			}
			LogUtil.e("getBitmapbyHalf" + " maxWith:" + maxWith +"maxHeight:" +maxHeight);
			bitmap = ImageUtils.getBitmapHalf(path);
			if(bitmap != null){
				putBitmap(key, bitmap);
				return bitmap;
			}
			LogUtil.e("getBitmapByFitSize" + " maxWith:" + maxWith +"maxHeight:" +maxHeight);
			bitmap = ImageUtils.getFitSizeImg(path);
			if(bitmap != null)
			return bitmap;	
		}
		if (Constans.DEBUG)
			Log.i("图片缓存",path + "");
		return null;
	}
    
    
    
  //缓存bitmap  
    public boolean putBitmap(String key, Bitmap bitmap){  
        if(bitmap != null){  
            synchronized(sHardBitmapCache){  
                sHardBitmapCache.put(key, bitmap);  
            }  
            return true;  
        }         
        return false;  
    }  
    //从缓存中获取bitmap  
    public Bitmap getBitmap(String key){  
        synchronized(sHardBitmapCache){  
            final Bitmap bitmap = sHardBitmapCache.get(key);  
            if(bitmap != null)  
                return bitmap;  
        }  
        //硬引用缓存区间中读取失败，从软引用缓存区间读取  
        synchronized(sSoftBitmapCache){  
            SoftReference<Bitmap> bitmapReference = sSoftBitmapCache.get(key);  
            if(bitmapReference != null){  
                final Bitmap bitmap2 = bitmapReference.get();  
                if(bitmap2 != null)  
                    return bitmap2;  
                else{  
                    Log.v("tag", "soft reference 已经被回收");  
                    sSoftBitmapCache.remove(key);  
                }  
            }  
        }  
        return null;  
    }  
    
    private static String generateKey(String fileId, int width, int height) {         
        String ret = fileId + "_" + Integer.toString(width) + "x" + Integer.toString(height);  
        return ret;  
    }  
    
    
    
    
}
