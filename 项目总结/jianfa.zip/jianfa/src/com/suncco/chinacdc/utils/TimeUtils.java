package com.suncco.chinacdc.utils;

import java.text.SimpleDateFormat;
import java.util.Date;


public class TimeUtils {
	public static String getCurrentDay(){
		  SimpleDateFormat format =   new SimpleDateFormat( "yyyy-MM-dd" );
	       Long time=new Long(new Date().getTime());
	       String d = format.format(time);
	       return d;
	}
}
