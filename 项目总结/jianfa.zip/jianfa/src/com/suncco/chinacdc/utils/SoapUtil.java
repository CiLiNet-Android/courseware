package com.suncco.chinacdc.utils;

import org.ksoap2.serialization.SoapObject;

import android.text.TextUtils;

import com.suncco.chinacdc.Constans;

public class SoapUtil {
	public static boolean isEmpty(SoapObject obj) {
		return (obj == null || TextUtils.isEmpty(obj.toString()) || Constans.SOAP_NULL
				.equals(obj.toString()));
	}
}
