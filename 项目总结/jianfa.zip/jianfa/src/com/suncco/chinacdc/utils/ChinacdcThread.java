package com.suncco.chinacdc.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Handler;
import android.os.Message;

public class ChinacdcThread extends Thread {

	public static final int THREAD_CANCEL_RESULT = 404;
	private static final String SERVER_URL = "serverUrl";
	private static final String NAME_SPACE = "nameSpace";
	private static final String METHOD_NAME = "methodName";
	private boolean mIsCancel;
	private ArrayList<HashMap<String, String>> params;
	private Handler mHandler;
	private int mWhat = -1;
	private Class<?> mBaseBeanClass;

	/**
	 * <name,value>
	 * 
	 * @param params
	 * @param c
	 * @param handler
	 * @param what
	 */
	public ChinacdcThread(Class<?> baseBean,
			ArrayList<HashMap<String, String>> params, Handler handler, int what) {
		this.params = params;
		this.mBaseBeanClass = baseBean;
		this.mHandler = handler;
		this.mWhat = what;
	}

	public void cancel() {
		mIsCancel = true;
	}

	@Override
	public void run() {
		super.run();
		String serverUrl = getValue(mBaseBeanClass, SERVER_URL);
		String nameSpace = getValue(mBaseBeanClass, NAME_SPACE);
		String methodName = getValue(mBaseBeanClass, METHOD_NAME);
		SoapObject SoapObject = WebService.getInfo(serverUrl, nameSpace,
				methodName, params);
		LogUtil.i("method_name : " + methodName + "  SoapObje : "
				+ (SoapObject == null ? "null" : SoapObject.toString()));
		if (mHandler != null) {
			if (mIsCancel) {
				mHandler.sendEmptyMessage(THREAD_CANCEL_RESULT);
				return;
			}
			Object obj = invokeStaticMethod(mBaseBeanClass, SoapObject);
			Message msg = new Message();
			msg.what = mWhat;
			try {
				msg.obj = obj;
			} catch (Exception e) {
				e.printStackTrace();
			}
			mHandler.sendMessage(msg);
		}
	}

	private Object invokeStaticMethod(Class<?> c, SoapObject SoapObject) {
		String methodName = "parse" + c.getSimpleName();
		Method method;
		try {
			method = c.getMethod(methodName, SoapObject.class);
			return method.invoke(null, SoapObject);
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getValue(Class<?> c, String fieldName) {
		try {
			Field f = c.getField(fieldName);
			return f.get(null).toString();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
}
