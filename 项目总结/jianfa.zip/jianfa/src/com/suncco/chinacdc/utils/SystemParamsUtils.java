package com.suncco.chinacdc.utils;

import java.io.File;
import java.lang.reflect.Field;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

import com.suncco.chinacdc.BaseApp;

/**
 * 获取一些系统的参数
 * 
 */
public class SystemParamsUtils {
	public static int getWindowsDimensionSize() {
		Class<?> c = null;
		Object obj = null;
		Field field = null;
		int x = 0, sbar = 0;
		try {
			c = Class.forName("com.android.internal.R$dimen");
			obj = c.newInstance();
			field = c.getField("status_bar_height");
			x = Integer.parseInt(field.get(obj).toString());
			sbar = BaseApp.sContext.getResources().getDimensionPixelSize(x);
			return sbar;
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return 0;
	}

	public static int getScreenHeight() {
		final WindowManager windowManager = (WindowManager) BaseApp.sContext
				.getSystemService(Context.WINDOW_SERVICE);
		final Display display = windowManager.getDefaultDisplay();
		boolean isPortrait = display.getWidth() < display.getHeight();
		return isPortrait ? display.getHeight() : display.getWidth();
	}

	public static int getScreenWidth() {
		final WindowManager windowManager = (WindowManager) BaseApp.sContext
				.getSystemService(Context.WINDOW_SERVICE);
		final Display display = windowManager.getDefaultDisplay();
		boolean isPortrait = display.getWidth() < display.getHeight();
		return isPortrait ? display.getWidth() : display.getHeight();
	}

	public static String getIMEI() {
		TelephonyManager telephonyManager = (TelephonyManager) BaseApp.sContext
				.getSystemService(Context.TELEPHONY_SERVICE);
		try {
			return telephonyManager.getDeviceId().toLowerCase();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return getLocalMacAddress();
	}
	
	public static String getIMEI(Context context) {
		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		return tm.getDeviceId();
	}

	public static String getIMSI(Context context) {
		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		return tm.getSubscriberId();
	}

	public static String getPhoneNumber(Context context) {
		TelephonyManager tm = (TelephonyManager) context
				.getSystemService(Context.TELEPHONY_SERVICE);
		return tm.getLine1Number();
	}

	public static String getAndroidID(Context context) {

		return Secure
				.getString(context.getContentResolver(), Secure.ANDROID_ID);
	}

	public static String getLocalMacAddress() {
		StringBuffer result = new StringBuffer(15);
		WifiManager wifi = (WifiManager) BaseApp.sContext
				.getSystemService(Context.WIFI_SERVICE);
		WifiInfo info = wifi.getConnectionInfo();
		String[] address = info.getMacAddress().split(":");
		for (int i = 0; i < address.length; i++) {
			result.append(address[i]);
		}
		return result.toString() + "000";
	}

	/**
	 * 0：准备SD卡中 1：SD 可用 -1:SD卡不可用
	 * 
	 * @return
	 */
	public static boolean SDEnable() {
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state)) {
			return true;
		}
		return false;
	}

	public static long getSDCardAvailableMemory() {
		long availableMemory = 0;
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state)) {
			File sdcardDir = Environment.getExternalStorageDirectory();
			StatFs statFs = new StatFs(sdcardDir.getPath());
			availableMemory = (long) statFs.getBlockSize()
					* (long) statFs.getAvailableBlocks();
		}
		return availableMemory;
	}
	
	/**
	 * 
	 * @author sky
	 * 
	 *         Email vipa1888@163.com
	 * 
	 *         QQ:840950105
	 * 
	 *         获取当前的网络状态 -1：没有网络 1：WIFI网络2：wap网络3：net网络
	 * 
	 * @param context
	 * 
	 * @return
	 */
	public static final int CMNET = 3;
	public static final int CMWAP = 2;
	public static final int WIFI = 1;
	public static final int NONET = -1;
	

	public static int getAPNType(Context context) {

		int netType = -1;

		ConnectivityManager connMgr = (ConnectivityManager) context
				.getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

		if (networkInfo == null) {

			return netType;

		}

		int nType = networkInfo.getType();

		if (nType == ConnectivityManager.TYPE_MOBILE) {

			Log.e("networkInfo.getExtraInfo()",
					"networkInfo.getExtraInfo() is "
							+ networkInfo.getExtraInfo());

			if (networkInfo.getExtraInfo().toLowerCase().equals("cmnet")) {

				netType = CMNET;

			}

			else {

				netType = CMWAP;

			}

		}

		else if (nType == ConnectivityManager.TYPE_WIFI) {

			netType = WIFI;

		}

		return netType;

	}
	
	/**
	 * 判断是否有网络连接
	 * */
	public static boolean isNetworkConnected(Context context) {  
	     if (context != null) {  
	         ConnectivityManager mConnectivityManager = (ConnectivityManager) context  
	                 .getSystemService(Context.CONNECTIVITY_SERVICE);  
	         NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();  
	         if (mNetworkInfo != null) {  
	             return mNetworkInfo.isAvailable();  
	         }  
	     }  
	     return false;  
	 }
	
	/**
	 * 判断WIFI网络是否可用
	 * */
	public static boolean isWifiConnected(Context context) {  
	     if (context != null) {  
	         ConnectivityManager mConnectivityManager = (ConnectivityManager) context  
	                 .getSystemService(Context.CONNECTIVITY_SERVICE);  
	         NetworkInfo mWiFiNetworkInfo = mConnectivityManager  
	                 .getNetworkInfo(ConnectivityManager.TYPE_WIFI);  
	         if (mWiFiNetworkInfo != null) {  
	             return mWiFiNetworkInfo.isAvailable();  
	         }  
	     }  
	     return false;  
	 }
	
	/**
	 * 判断MOBILE网络是否可用
	 * */
	public static boolean isMobileConnected(Context context) {  
	     if (context != null) {  
	         ConnectivityManager mConnectivityManager = (ConnectivityManager) context  
	                 .getSystemService(Context.CONNECTIVITY_SERVICE);  
	         NetworkInfo mMobileNetworkInfo = mConnectivityManager  
	                 .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);  
	         if (mMobileNetworkInfo != null) {  
	             return mMobileNetworkInfo.isAvailable();  
	         }  
	     }  
	     return false;  
	 }
	
	/**
	 * 获取手机 型号
	 * */
	public static String getPhoneModel(){
		 String mtype = android.os.Build.MODEL; // 手机型号  
		 return mtype;
	}
	
	/**
	 * 获取android 系统版本号
	 * */
	public static String getPhoneRelease(){
		String release=android.os.Build.VERSION.RELEASE;  // android系统版本号
		 return release;
	}
	
}
