package com.suncco.chinacdc.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.SoapFault;
import org.ksoap2.serialization.MarshalBase64;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;

import com.suncco.chinacdc.BaseApp;

public class WebService {

	public static final String NAME = "name";
	public static final String VALUE = "value";

	/**
	 * 
	 * @param method_name
	 *            方法名
	 * @param soap_action
	 *            方法提交URL
	 * @param prams
	 *            提交参数，不同方法具体各异
	 * @return String XML
	 */
	public static SoapObject getInfo(String serverUrl, String nameSpace,
			String methodName, ArrayList<HashMap<String, String>> params) {

		SoapObject soapObject = new SoapObject(nameSpace, methodName);
		if (params != null) {
			int len = params.size();
			HashMap<String, String> hashMap;
			for (int i = 0; i < len; i++) {
				hashMap = params.get(i);
				soapObject.addProperty(hashMap.get(NAME), hashMap.get(VALUE));
				LogUtil.i(hashMap.get(NAME) + " " + hashMap.get(VALUE));
			}
		}
		SoapSerializationEnvelope soapSerializationEnvelope = new SoapSerializationEnvelope(
				SoapEnvelope.VER10);
		soapSerializationEnvelope.setOutputSoapObject(soapObject);
		(new MarshalBase64()).register(soapSerializationEnvelope);
		try {
			HttpTransportSE httpTransportSE = new HttpTransportSE(serverUrl);
			httpTransportSE.debug = true;
			httpTransportSE.call(nameSpace + methodName,
					soapSerializationEnvelope);
			return (SoapObject) soapSerializationEnvelope.getResponse();
		} catch (SoapFault e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static boolean isWap() {
		String defaultHost = Proxy.getDefaultHost();
		int defaultPort = Proxy.getDefaultPort();
		ConnectivityManager connectivityManager = (ConnectivityManager) BaseApp.sContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		int type = activeNetworkInfo == null ? 0 : activeNetworkInfo.getType();
		return (type == ConnectivityManager.TYPE_MOBILE && defaultHost != null && defaultPort != -1);
	}
}