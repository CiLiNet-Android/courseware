package com.suncco.chinacdc.utils;

import android.os.Handler;
import android.util.Log;

import com.suncco.chinacdc.Constans;

public class ImagesThread extends Thread {

	private Handler mHandler;
	private String[] mImagesUrl;
	public boolean mIsCancel = false;
	private int mWhat;

	/**
	 * 多张张图片下载 handler。what 100
	 * 
	 * @param handler
	 * @param img
	 */
	public ImagesThread(Handler handler, String[] imgs, int what) {
		this.mHandler = handler;
		this.mImagesUrl = imgs;
		this.mWhat = what;
	}

	/**
	 * 单独一张图片下载 handler。what 101
	 * 
	 * @param handler
	 * @param img
	 */
	public ImagesThread(Handler handler, String img, int what) {
		this.mHandler = handler;
		this.mImagesUrl = new String[] { img };
		this.mWhat = what;
	}

	@Override
	public void run() {
		super.run();
		if (Constans.DEBUG) {
			Log.i("ImagesThread", "start");
		}
		if (mImagesUrl != null) {
			int len = mImagesUrl.length;
			for (int i = 0; i < len; i++) {
				if (mIsCancel) {
					break;
				}
				int status = WebResourceUtils.downloadObj(mImagesUrl[i]);
				if (len > 1) {
					if (status == 1) {
						mHandler.sendEmptyMessage(mWhat);
					}
				} else {
					if (status != 0) {
						mHandler.sendEmptyMessage(mWhat);
					}
				}
			}
		}
	}
}
