package com.suncco.chinacdc.utils;

public class UmengEvent {
	public static String downMagazineEvent ="downMagazineEvent";
	public static String intoAddressBookEvent = "intoAddressBookEvent";
	public static String intoCoreMailEvent = "intoCoreMailEvent";
	public static String intoInfoCategoryEvent = "intoInfoCategoryEvent";
	public static String intoInfoEvent = "intoInfoEvent";
	public static String intoInfoNewEvent = "intoInfoNewEvent";
	public static String intoMagazineCategoryEvent = "intoMagazineCategoryEvent";
	public static String intoMagazineEvent = "intoMagazineEvent";
	public static String intoMagazineNewEvent = "intoMagazineNewEvent";
	public static String intoMagazineTermEvent = "intoMagazineTermEvent";
}
