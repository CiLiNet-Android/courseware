package com.suncco.chinacdc;

import android.os.Environment;

public class Constans {

	public static final boolean DEBUG = true;

	public static final String TEST_ACCOUNT = "hr10006013";

	public static final String DIR = Environment.getExternalStorageDirectory()
			+ "/.chinacdc/";

	public static final String IMG_DIR = DIR + "images/";

	public static String DOWNLOAD_DIR = DIR + "download/";

	public static final String CACHE_DIR = "/data/data/com.suncco.chinacdc/";

	// public static final String NAME_SPACE =
	// "http://m.chinacdc.com:80/jianfa";
	// public static final String NAME_SPACE = "http://wap.j.suncco.com:88/09";
	// public static final String NAME_SPACE =
	// "http://172.19.32.15:8080/jianfa";
	// public static final String NAME_SPACE =
	// "http://wap.j.suncco.com:88/61";
	public static final String NAME_SPACE = "http://218.5.66.44:9090/jianfa";
//	public static final String NAME_SPACE = "http://218.5.66.44:9080/jianfa";
	
	

	public static final String ORGANIZATION_SERVICE_URL = NAME_SPACE
			+ "/ws/organizationservice?wsdl";
	public static final String CUSTOMORGANIZATION_SERVICE_URL = NAME_SPACE
			+ "/ws/customorganizationservice?wsdl";

	public static final String SETTING_SERVICE_URL = NAME_SPACE
			+ "/ws/settingservice?wsdl";

	public static final String CHANNEL_SERVICE = NAME_SPACE
			+ "/ws/channelservice?wsdl";

	public static final String ARTICLE_SERVICE = NAME_SPACE
			+ "/ws/articleservice?wsdl";

	public static final String JOURNAL_SERVICE = NAME_SPACE
			+ "/ws/journalservice?wsdl";

	public static final String UPDATE_PROMPT_TIME = "update_prompt_time";

	public static final int UPDATE_IGNORE_TIME = 1000 * 60 * 60 * 24 * 7;

	public static final int PAGE_SIZE = 10;

	public static final String SOAP_NULL = "anyType{}";

	// 本地缓存数据 name
	public static final String REMEMBER_PASSWORD = "remember_password";
	public static final String AUTO_LOGIN = "auto_login";
	public static final String USER_NAME = "user_name";
	public static final String PASSWORD = "password";
	public static final String DETAIL_TEXT_SIZE = "detail_text_size";

	public static final String TRUE = "true";
	public static final String FLASE = "false";
}
