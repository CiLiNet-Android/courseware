package com.suncco.chinacdc.magazine;

import java.util.ArrayList;
import java.util.Random;

import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.JournalArticleBean;

/**
 * 
 * @author suncco 10036 2012-10-22
 */
public class ViewPagerAdapter extends PagerAdapter {

	public ArrayList<View> mTemplateViews;
	private Context mContext;
	private ArrayList<ArrayList<JournalArticleBean>> mJournalArticleBeans;
	private OnClickListener mOnClickListener;

	public ViewPagerAdapter(Context context,
			ArrayList<ArrayList<JournalArticleBean>> beans,
			OnClickListener listener) {
		this.mContext = context;
		this.mJournalArticleBeans = beans;
		this.mOnClickListener = listener;
		mTemplateViews = new ArrayList<View>();
	}

	private View getTemplateView() {
		View convertView = LayoutInflater.from(mContext).inflate(
				R.layout.view_pager_item, null);
		for (int i = 0; i < 6; i++) {
			convertView.findViewById(
					mContext.getResources().getIdentifier("article" + i, "id",
							mContext.getPackageName())).setOnClickListener(
					mOnClickListener);
		}
		return convertView;
	}

	private void setValues(View convertView, int position) {
		ArrayList<JournalArticleBean> beans = getItem(position);
		int len = Math.min(beans.size(), 6);
		for (int i = 0; i < len; i++) {
			TextView textView = (TextView) convertView.findViewById(mContext
					.getResources().getIdentifier("article" + i, "id",
							mContext.getPackageName()));
			textView.setText(beans.get(i).title);
			if (i == 2) {
				textView.setBackgroundResource(new Random().nextBoolean() ? R.drawable.article_color1
						: R.drawable.article_color2);
			}
		}
		for (int i = len; i < 6; i++) {
			TextView textView = (TextView) convertView.findViewById(mContext
					.getResources().getIdentifier("article" + i, "id",
							mContext.getPackageName()));
			textView.setText("");
			if (i == 2) {
				textView.setBackgroundResource(new Random().nextBoolean() ? R.drawable.article_color1
						: R.drawable.article_color2);
			}
		}
	}

	public ArrayList<JournalArticleBean> getItem(int position) {
		return mJournalArticleBeans.get(position);
	}

	@Override
	public void destroyItem(View arg0, int arg1, Object arg2) {
		View view = (View) arg2;
		((ViewPager) arg0).removeView(view);
		mTemplateViews.add(view);
	}

	@Override
	public void finishUpdate(View arg0) {
	}

	@Override
	public int getCount() {
		return mJournalArticleBeans == null ? 0 : mJournalArticleBeans.size();
	}

	@Override
	public Object instantiateItem(View view, int position) {
		ViewPager viewPager = (ViewPager) view;
		View convertView;
		if (mTemplateViews.size() == 0) {
			convertView = getTemplateView();
		} else {
			convertView = mTemplateViews.get(0);
			mTemplateViews.remove(0);
		}
		setValues(convertView, position);
		viewPager.addView(convertView);
		return convertView;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == (arg1);
	}

	@Override
	public void restoreState(Parcelable arg0, ClassLoader arg1) {
	}

	@Override
	public Parcelable saveState() {
		return null;
	}

	@Override
	public void startUpdate(View arg0) {
	}

	@Override
	public int getItemPosition(Object object) {
		return POSITION_NONE;
	}
}
