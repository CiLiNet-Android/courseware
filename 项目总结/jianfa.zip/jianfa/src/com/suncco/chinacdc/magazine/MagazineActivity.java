package com.suncco.chinacdc.magazine;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.MagazineBean;
import com.suncco.chinacdc.bean.MagazineListBean;
import com.suncco.chinacdc.information.ArticleImgListActivity;
import com.suncco.chinacdc.subscription.SubDetailActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ImagesThread;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.ScrollLayout;
import com.suncco.chinacdc.widget.ScrollLayout.PageListener;
import com.umeng.analytics.MobclickAgent;

/**
 * 杂志
 * 
 * @author whyhappy
 * @date 2012-10-12
 */
public class MagazineActivity extends BaseActivity implements OnClickListener,
		OnItemClickListener, PageListener {

	private static final int HANDLER_MAGAZINE_WHAT = 100;
	private static final int HANDLER_MAGAZINE_IMG_WHAT = 101;
	
	private static final int REQUEST_SUB = 33;
	
	

	private LoadingProgressDialog mProgress;
	MagazineListBean mListBean;
	MagazineGridAdapter[] mAdapters;
	

	/** 总页数. */
	private int PageCount;
	/** 当前页码. */
	private int PageCurrent;
	/** 每页显示的数量，Adapter保持一致. */
	private static final float PAGE_SIZE = 9.0f;
	/** GridView. */
	private GridView gridView;
	/** 自定义的左右滑动. */
	private ScrollLayout curPage;
	TextView mPageText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.magazine_activity);
		prepareView();
		
		getMagazineList();
		MobclickAgent.onEvent(this, UmengEvent.intoMagazineEvent);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.title_but2).setOnClickListener(this);
		mPageText = (TextView)findViewById(R.id.title_page_text);
		mProgress = new LoadingProgressDialog(this);
		curPage = (ScrollLayout) findViewById(R.id.magazine_scroll);
		curPage.getLayoutParams().height = BaseApp.sScreenHeight * 4 / 5;
		curPage.setPageListener(this);
	}

	private void getMagazineList() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		mProgress.show();
		new ChinacdcThread(MagazineListBean.class, utils.formatParams(),
				mHandler, HANDLER_MAGAZINE_WHAT).start();

	}

	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_MAGAZINE_WHAT) {
				mProgress.dismiss();
				MagazineListBean bean = (MagazineListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_load_exc);
				} else {
					if (bean.code == 0) {
						bean = MagazineListBean.getSubNowListBean(bean);
						mListBean = bean;
						setGrid();
//						mMagazineAdapter = new MagazineAdapter2(
//								MagazineActivity.this, bean);
//						GridView gridView = (GridView) findViewById(R.id.magazine_grid);
//						gridView.setAdapter(mMagazineAdapter);
//						gridView.setOnItemClickListener(MagazineActivity.this);
						new ImagesThread(mHandler, bean.getImageUrls(),
								HANDLER_MAGAZINE_IMG_WHAT).start();
					} else {
//						BaseApp.showToast(bean.message);
						BaseApp.showSessionnDialog(MagazineActivity.this, bean);
					}
				}
			} else if (msg.what == HANDLER_MAGAZINE_IMG_WHAT) {
//				mMagazineAdapter.notifyDataSetChanged();
				setAdapterNotify();
			}
		};
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode){
		case REQUEST_SUB:
			getMagazineList();
			break;
		}
	}

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		}else if(v.getId() == R.id.title_but2){
			Intent intent = new Intent(this, SubDetailActivity.class);
			intent.putExtra("type", 1);
			startActivityForResult(intent, REQUEST_SUB);
			
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		MagazineBean bean = (MagazineBean) view.getTag(R.id.magazine_logo);
		Intent intent = new Intent(this, JournalTabActivity.class);
		intent.putExtra("id", bean.id);
		intent.putExtra("name", bean.name);
		startActivity(intent);
	}
	
	/**
	 * 添加GridView
	 */
	private void setGrid() {

		PageCount = (int) Math.ceil(mListBean.mMagazineBeans.size() / PAGE_SIZE);
		if (gridView != null) {
			curPage.removeAllViews();
		}
		mAdapters = new MagazineGridAdapter[PageCount];
		for (int i = 0; i < PageCount; i++) {
			gridView = new GridView(this);
			mAdapters[i] = new MagazineGridAdapter(this, mListBean, i);
			gridView.setAdapter(mAdapters[i]);
			gridView.setNumColumns(3);
			gridView.setHorizontalSpacing(30);
			gridView.setVerticalSpacing(30);
			gridView.setPadding(15, 0, 15, 0);
			// 去掉点击时的黄色背景
			gridView.setSelector(R.drawable.transparent);
			gridView.setOnItemClickListener(this);
			curPage.addView(gridView);
		}
		curPage.snapToScreen(0);
	}
	
	private void setAdapterNotify(){
		for(int i = 0, l = mAdapters.length; i < l ; i ++){
			mAdapters[i].notifyDataSetChanged();
		}
		
	}

	@Override
	public void page(int page) {
		// TODO Auto-generated method stub
		PageCurrent = page;
		if(PageCount > 1){
			mPageText.setText(PageCurrent+1 + "");
			mPageText.setVisibility(View.VISIBLE);
		}else{
			mPageText.setVisibility(View.INVISIBLE);
		}
	}
}
