package com.suncco.chinacdc.magazine;

import java.io.IOException;
import java.util.HashMap;

import org.xmlpull.v1.XmlPullParserException;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.FavourJournalBean;
import com.suncco.chinacdc.bean.FavourListBean;
import com.suncco.chinacdc.bean.JournalPhotoDetailBean;
import com.suncco.chinacdc.utils.ImageLoader;
import com.suncco.chinacdc.utils.LogUtil;

public class JournalPhotoDetailActivity extends BaseActivity implements
		OnPageChangeListener, OnClickListener, OnItemClickListener,
		OnCheckedChangeListener {

	private boolean mMenuPopVisbility;
	private PopupWindow mPopupMenuWindow;
	private View mTitleBar;
	JournalPhotoDetailBean mJournalPhotoDetailBean;
	ViewPager mViewPager;
	PhotoViewPagerAdapter mPhotoViewPagerAdapter;
	TextView mIndexText;
	String mPath;
	String belong;
	CheckBox mCheckBox;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journal_photo_detail_activity);
		mPath = getIntent().getStringExtra("path");
		belong = getIntent().getStringExtra("belong")+"";
//		LogUtil.e("mPath-->" +mPath +"\n"+"belong-->"+belong);
		try {
			mJournalPhotoDetailBean = JournalPhotoDetailBean
					.parseJournalPhotoDetailBean(mPath + "/build.xml");
			prepareView();
			mPhotoViewPagerAdapter = new PhotoViewPagerAdapter(this,
					mJournalPhotoDetailBean, mPath, this);
			mViewPager.setAdapter(mPhotoViewPagerAdapter);
			int index = getIntent().getIntExtra("index", 0);
			if (index >= 0 && index < mPhotoViewPagerAdapter.getCount()) {
				mViewPager.setCurrentItem(index);
				onPageScrolled(index,0,0);
			}else{
				mIndexText.setText(1 + "/" + mPhotoViewPagerAdapter.getCount());
			}
			
		} catch (XmlPullParserException e) {
			e.printStackTrace();
			openFailed();
		} catch (IOException e) {
			e.printStackTrace();
			openFailed();
		}
	}

	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}


	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		ImageLoader.getInstance().clearCache();
	}


	private void openFailed() {
		new AlertDialog.Builder(this).setTitle(R.string.app_warn)
				.setMessage(R.string.magazine_open_exc)
				.setOnCancelListener(new DialogInterface.OnCancelListener() {

					public void onCancel(DialogInterface dialog) {
						finish();
					}
				}).show();
	}

	private String getTile() {
		if (mJournalPhotoDetailBean != null) {
			return mJournalPhotoDetailBean.magazineName + "_"
					+ mJournalPhotoDetailBean.journalName + "第 " + (mViewPager.getCurrentItem()+1) + " 页";
		}
		return "";
	}

	private void prepareView() {
		TextView title = (TextView) findViewById(R.id.journal_title);
		title.setText(mJournalPhotoDetailBean.magazineName);
		mViewPager = (ViewPager) findViewById(R.id.aritcle_Pager);
		mViewPager.setOnPageChangeListener(this);
		mIndexText = (TextView) findViewById(R.id.photo_index);
		findViewById(R.id.page_but).setOnClickListener(this);
		mTitleBar = findViewById(R.id.article_title_frame);
		findViewById(R.id.back).setOnClickListener(this);
		mCheckBox = (CheckBox)findViewById(R.id.favour_check_box);
	}

	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub

	}

	public void onPageScrolled(int page, float arg1, int arg2) {
		
	}

	public void onPageSelected(int page) {
		// TODO Auto-generated method stub
		mIndexText
		.setText((page + 1) + "/" + mPhotoViewPagerAdapter.getCount());
		setCheckBoxView();
//		ImageLoader.getInstance().loadBitmapByPath(mPhotoViewPagerAdapter.getItem(page));
//		mPhotoViewPagerAdapter.notifyDataSetChanged();
//		mPhotoViewPagerAdapter.checkPageContent(page);
	}

	private void popMenuWindow(View parent) {
		mMenuPopVisbility = true;
		if (mPopupMenuWindow == null) {
			View popView = LayoutInflater.from(this).inflate(
					R.layout.photo_page_pop_view, null);
			ListView listView = (ListView) popView.findViewById(R.id.page_list);
			listView.setAdapter(new PhotoPageAdapter(this,
					mJournalPhotoDetailBean.mPageList));
			listView.setOnItemClickListener(this);
			mPopupMenuWindow = new PopupWindow(popView,
					(int) (BaseApp.sScreenWidth *4/ 5),
					(int) (BaseApp.sScreenHeight *4/ 5));
			mPopupMenuWindow.setTouchInterceptor(new OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
						mPopupMenuWindow.dismiss();
						return true;
					}
					return false;
				}
			});
			mPopupMenuWindow.setOnDismissListener(new OnDismissListener() {

				public void onDismiss() {
					mMenuPopVisbility = false;
				}
			});
		}
		ColorDrawable cd = new ColorDrawable(-0000);
		mPopupMenuWindow.setBackgroundDrawable(cd);
		mPopupMenuWindow.update();
		mPopupMenuWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
		mPopupMenuWindow.setTouchable(true);
		mPopupMenuWindow.setOutsideTouchable(true);
		mPopupMenuWindow.setFocusable(true);
//		mPopupMenuWindow.showAtLocation(parent,
//				(Gravity.BOTTOM - parent.getHeight()) | Gravity.LEFT,
//				(int) (BaseApp.sScreenWidth / 5),
//				(int) (1.35f * mTitleBar.getBottom()));
		mPopupMenuWindow.showAtLocation(parent,
				Gravity.TOP,
				(int) (BaseApp.sScreenWidth *1/ 5),
				(int) (1.35f * mTitleBar.getBottom()));
		LogUtil.e("parent.getHeight:" + parent.getHeight() + "\nx:"+BaseApp.sScreenWidth / 5 +"\ny:"+1.35f * mTitleBar.getBottom());
	}

	private void changMenuPopState(View v) {
		mMenuPopVisbility = !mMenuPopVisbility;
		if (mMenuPopVisbility) {
			popMenuWindow(v);
		} else {
			if (mPopupMenuWindow != null) {
				mPopupMenuWindow.dismiss();
			}
		}
	}

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		} else if (v.getId() == R.id.page_but) {
			changMenuPopState(v);
		} else {
			int position = mViewPager.getCurrentItem();
			String path = mPhotoViewPagerAdapter.getItem(position);
			Intent intent = new Intent(this, PhotoBrowseActivity2.class);
			intent.putExtra("url", path);
			startActivity(intent);
		}
	}

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		HashMap<String, String> map = mJournalPhotoDetailBean.mPageList
				.get(position);
		int index = Integer.valueOf(map.get("index")) - 1;
		mViewPager.setCurrentItem(index, true);
//		mViewPager.setCurrentItem(index);
		changMenuPopState(view);
	}

	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (!isChecked) {
			FavourListBean.getInstance().removeFavourMaazineBean(1, getTile(),
					mPath);
			BaseApp.showToast("已取消收藏");
		} else {
			FavourJournalBean bean = new FavourJournalBean(getTile(), mPath,belong,mViewPager.getCurrentItem());
			FavourListBean.getInstance().addFavourMagazineBean(bean);
			BaseApp.showToast("收藏成功");
		}
		FavourListBean.save();
	}
	
	private void setCheckBoxView(){
		mCheckBox.setOnCheckedChangeListener(null);
		mCheckBox.setChecked(FavourListBean.getInstance().hasJournalBean(1,
				getTile(), mPath));
		mCheckBox.setOnCheckedChangeListener(this);
		
	}
	
}
