package com.suncco.chinacdc.magazine;

import android.app.TabActivity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;


public class JournalTabActivity extends TabActivity implements OnClickListener {
	/** Called when the activity is first created. */
	public static final String TAB_TAG_HOME = "home";
	public static final String TAB_TAG_NEWS = "home2";
	public static final String TAB_TAG_DISCOUNT = "home3";
	public static final String TAB_TAG_MORE = "more";

	public static final int REQUEST_LOGIN = 11;

	// mTitleBut2 tag 0: 登录 1：筛选
	public Button mTitleBut1, mTitleBut2;
	public TabHost mTabHost;
	public ViewFlipper mViewFlipper; // 标题图片logo和标题文字切换特效
	public TextView mTitlleText; // 标题文字
	public ImageView mTitleLogo; // 标题logo
	private Animation left_in, left_out;
	private Animation right_in, right_out;

	Intent mFirstIntent, mSecondIntent;
	public View mMainTabBut1, mMainTabBut2;
	public View mMainTabBgView , main_bar;

	public static int temp_1 = 0;
	public static int mCurTag = 0;
	int width = 0;
	Resources rs;
	int weather;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journal_tab_activity);
		prepareView();
		width = BaseApp.sScreenWidth / 2;
	}
	
	

	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		
		BaseApp mBaseApp = (BaseApp) getApplication();
//		if (mBaseApp.getIsProgramExist()) {
//			finish();
//		}
	}

	private void prepareView() {
		rs = this.getResources();
		IntentFilter filter = new IntentFilter();
		String name = getIntent().getStringExtra("name");
		String id = getIntent().getStringExtra("id");
		mFirstIntent = new Intent(this, JournalActivity.class);
		mFirstIntent.putExtra("name", name);
		mFirstIntent.putExtra("id", id);
		mFirstIntent.putExtra("type", 0);
		mSecondIntent = new Intent(this, JournalActivity.class);
		mSecondIntent.putExtra("name", name);
		mSecondIntent.putExtra("id", id);
		mSecondIntent.putExtra("type", 1);
		setupIntent();
		mMainTabBut1 = findViewById(R.id.main_tab_but_1);
		mMainTabBut1.setOnClickListener(this);
		mMainTabBut2 = findViewById(R.id.main_tab_but_2);
		mMainTabBut2.setOnClickListener(this);

		mTitleBut1 = (Button) findViewById(R.id.title_but1);
		mTitleBut2 = (Button) findViewById(R.id.title_but2);
		main_bar = findViewById(R.id.main_bar);
		mMainTabBgView = findViewById(R.id.scroll_bg);
		mViewFlipper = (ViewFlipper) findViewById(R.id.title_flipper);
		mTitlleText = (TextView) findViewById(R.id.title_text);
		mTitlleText.setText(name);
		mTitleLogo = (ImageView) findViewById(R.id.title_logo);
		
		findViewById(R.id.title_but1).setOnClickListener(this);
		
		left_in = AnimationUtils.loadAnimation(this, R.anim.left_in);
		left_out = AnimationUtils.loadAnimation(this, R.anim.left_out);

		right_in = AnimationUtils.loadAnimation(this, R.anim.right_in);
		right_out = AnimationUtils.loadAnimation(this, R.anim.right_out);
	}

	private void setupIntent() {
		mTabHost = getTabHost();
		mTabHost.addTab(buildTabSpec(TAB_TAG_HOME, R.string.app_name,
				R.drawable.ic_launcher, mFirstIntent));
		mTabHost.addTab(buildTabSpec(TAB_TAG_NEWS, R.string.app_name,
				R.drawable.ic_launcher, mSecondIntent));
	}

	private TabHost.TabSpec buildTabSpec(String tag, int resLabel, int resIcon,
			final Intent content) {
		return mTabHost
				.newTabSpec(tag)
				.setIndicator(getString(resLabel),
						getResources().getDrawable(resIcon))
				.setContent(content);
	}

	public void onClick(final View v) {
		// TODO Auto-generated method stub
		// BaseApp.showToast(v.getTag() + "");
		final int temp = mCurTag;
		temp_1 = temp;
		switch (v.getId()) {
		case R.id.title_but1:
			finish();
			break;
		case R.id.main_tab_but_1:
			mCurTag = 0;
			setCurrentTabForTag(TAB_TAG_HOME, mCurTag > temp);
			((ImageView)findViewById(R.id.main_tab_img_1)).setImageResource(R.drawable.icon_img_type_select);
			
//			main_bar.setBackgroundDrawable(rs.getDrawable(R.drawable.title_bg));
//			mMainTabBgView.setBackgroundColor(rs.getColor(R.color.white));
			break;
		case R.id.main_tab_but_2:
			mCurTag = 1;
			setCurrentTabForTag(TAB_TAG_NEWS, mCurTag > temp);
			((ImageView)findViewById(R.id.main_tab_img_2)).setImageResource(R.drawable.icon_text_type_selected);

			break;
//		case R.id.main_tab_but_3:
//			mCurTag = 2;
//			setCurrentTabForTag(TAB_TAG_DISCOUNT, mCurTag > temp);
//			break;
		default:
			break;
		}
		TranslateAnimation translate = new TranslateAnimation(temp * width,
				mCurTag * width, 0, 0);
		translate.setFillAfter(true);
		translate.setDuration(200);
		mMainTabBgView.startAnimation(translate);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
//		if (resultCode == 1) {
//			mMainTabBut4.performClick();
//		} else {
//			mMainTabBut1.performClick();
//		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
			int index = intent.getIntExtra("index", 1);
			switch (index) {
			case 1:
				mMainTabBut1.performClick();
				break;
			case 2:
				mMainTabBut2.performClick();
				break;
			default:break;
		
		}
	}

	public void setCurrentTabForTag(String tag, boolean dire) {
		if (mTabHost.getCurrentTabTag().equals(tag)) {
			return;
		}
		if (tag == null)
			return;
		
		((ImageView)findViewById(R.id.main_tab_img_1)).setImageResource(R.drawable.icon_img_type_normal);
		((ImageView)findViewById(R.id.main_tab_img_2)).setImageResource(R.drawable.icon_text_type_normal);

		if (dire) {
			mTabHost.getCurrentView().startAnimation(left_out);
		} else {
			mTabHost.getCurrentView().startAnimation(right_out);
		}
		mTabHost.setCurrentTabByTag(tag);
		if (dire) {
			mTabHost.getCurrentView().startAnimation(left_in);
		} else {
			mTabHost.getCurrentView().startAnimation(right_in);
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		return super.onKeyDown(keyCode, event);
	}

	
	public void showTtileText(String title) {
		mTitlleText.setText(title);
		if (mTitleLogo.getVisibility() == View.VISIBLE) {
			mViewFlipper.showNext();
		}
	}

	public void showTtileLogo() {
		if (mTitleLogo.getVisibility() != View.VISIBLE) {
			mViewFlipper.showNext();
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

}