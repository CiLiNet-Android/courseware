package com.suncco.chinacdc.magazine;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.MagazineBean;
import com.suncco.chinacdc.bean.MagazineListBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageLoader;

public class MagazineGridAdapter extends BaseAdapter {

	private Context context;
	/** 列表. */
//	private ChannelListBean bean;
	private ArrayList<MagazineBean> mList;

	// 每页显示的Item个数
	public static final int SIZE = 9;

	public MagazineGridAdapter(Context mContext, MagazineListBean bean, int page) {
		this.context = mContext;
//		this.bean = bean;
		int i = page * SIZE;
		int iEnd = i + SIZE;
		mList = new ArrayList<MagazineBean>();
		while ((i < bean.mMagazineBeans.size()) && (i < iEnd)) {
			mList.add(bean.mMagazineBeans.get(i));
			i++;
		}
	}

	static class ViewHolder {
		ImageView logo;
		TextView name;
	}
	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public MagazineBean getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(
					R.layout.magazine_item, null);
			holder = new ViewHolder();
			holder.logo = (ImageView) convertView
					.findViewById(R.id.magazine_logo);
			holder.name = (TextView) convertView
					.findViewById(R.id.magazine_name);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		MagazineBean bean = getItem(position);
		convertView.setTag(R.id.magazine_logo, bean);
		holder.name.setText(bean.name);
//		Bitmap bm = ImageLoader.getInstance().loadBitmapByUrl(bean.logoImg);
		Bitmap bm = BitmapLoader.getInstance().loadBitmapByPath(bean.logoImg, BaseApp.sScreenWidth/3, BaseApp.sScreenHeight/5);
		if (bm != null) {
			holder.logo.setImageBitmap(bm);
		} else {
//			holder.logo.setImageResource(R.drawable.magazine_dufault_img);
		}

		return convertView;
	}

}
