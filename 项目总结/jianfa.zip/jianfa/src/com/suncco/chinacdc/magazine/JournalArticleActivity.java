package com.suncco.chinacdc.magazine;

import java.io.File;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.FavourJournalBean;
import com.suncco.chinacdc.bean.FavourListBean;
import com.suncco.chinacdc.bean.SettingsBean;
import com.suncco.chinacdc.utils.ImageLoader;
import com.suncco.chinacdc.utils.LogUtil;

public class JournalArticleActivity extends BaseActivity implements
		OnClickListener, OnCheckedChangeListener {

	private View mTitleBar;
	private boolean mMenuPopVisbility;
	private PopupWindow mPopupMenuWindow;
	private TextView mContentText;
	private int mDefaultTextSize = 14;
	private int mSizeLimt = 4;
	private int mCurrentTextSize;
	private String mTitle;
	private String mDetail;
	private String mPath;
	private String belong;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journal_article_activity);
		mTitle = getIntent().getStringExtra("title");
		mDetail = getIntent().getStringExtra("detail");
		mPath = getIntent().getStringExtra("path");
		belong = getIntent().getStringExtra("belong") + "";
		if (TextUtils.isEmpty(mTitle) || TextUtils.isEmpty(mDetail)
				|| TextUtils.isEmpty(mPath)) {
			BaseApp.showToast("数据异常");
			findViewById(R.id.back).setOnClickListener(this);
		} else {
			prepareView();
		}
	}

	private void changMenuPopState(View v) {
		mMenuPopVisbility = !mMenuPopVisbility;
		if (mMenuPopVisbility) {
			popMenuWindow(v);
		} else {
			if (mPopupMenuWindow != null) {
				mPopupMenuWindow.dismiss();
			}
		}
	}

	private void changeTextSize(boolean largeOrSmall) {
		if (largeOrSmall) {
			// ++
			if (mCurrentTextSize < (mDefaultTextSize + mSizeLimt)) {
				mCurrentTextSize++;
			}
		} else {
			// --
			if (mCurrentTextSize > (mDefaultTextSize - mSizeLimt)) {
				mCurrentTextSize--;
			}
		}
		mContentText.setTextSize(mCurrentTextSize);
		SettingsBean.getInstance().putSettingValue(Constans.DETAIL_TEXT_SIZE,
				mCurrentTextSize + "");
		SettingsBean.save();
	}

	private void popMenuWindow(View parent) {
		mMenuPopVisbility = true;
		if (mPopupMenuWindow == null) {
			View popView = LayoutInflater.from(this).inflate(
					R.layout.font_view, null);
			popView.findViewById(R.id.font_big).setOnClickListener(this);
			popView.findViewById(R.id.font_small).setOnClickListener(this);
			mPopupMenuWindow = new PopupWindow(popView,
					(int) (BaseApp.sScreenWidth / 2.5),
					(int) (BaseApp.sScreenHeight / 6f));
			mPopupMenuWindow.setTouchInterceptor(new OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
						mPopupMenuWindow.dismiss();
						return true;
					}
					return false;
				}
			});
			mPopupMenuWindow.setOnDismissListener(new OnDismissListener() {

				public void onDismiss() {
					mMenuPopVisbility = false;
				}
			});
		}
		ColorDrawable cd = new ColorDrawable(-0000);
		mPopupMenuWindow.setBackgroundDrawable(cd);
		mPopupMenuWindow.update();
		mPopupMenuWindow.setInputMethodMode(PopupWindow.INPUT_METHOD_NEEDED);
		mPopupMenuWindow.setTouchable(true);
		mPopupMenuWindow.setOutsideTouchable(true);
		mPopupMenuWindow.setFocusable(true);
		mPopupMenuWindow.showAtLocation(parent,
				(Gravity.BOTTOM - parent.getHeight()) | Gravity.LEFT,
				(int) (BaseApp.sScreenWidth / 1.55),
				(int) (1.35f * mTitleBar.getBottom()));
	}

	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		mTitleBar = findViewById(R.id.article_title_frame);
		TextView title = (TextView) findViewById(R.id.article_title);
		title.setText(mTitle);
		mContentText = (TextView) findViewById(R.id.article_content);
		LogUtil.e("journalArticle--->" + mDetail);
		mContentText.setText(Html.fromHtml(mDetail, mImageGetter, null));
		findViewById(R.id.font_but).setOnClickListener(this);
		mCurrentTextSize = SettingsBean.getInstance().getSettingValueByName(
				Constans.DETAIL_TEXT_SIZE, mDefaultTextSize);
		
	}

	ImageGetter mImageGetter = new ImageGetter() {

		public Drawable getDrawable(String arg0) {
			arg0 = arg0.trim();
			if (arg0.startsWith(".")) {
				arg0 = arg0.substring(1);
			}
			String path = mPath + "/" + arg0;
			File file = new File(path);
			if (file.exists()) {
				Bitmap bmp = ImageLoader.getInstance().loadBitmapByPath(path);
				BitmapDrawable bitmapDrawable = new BitmapDrawable(bmp);
				Drawable drawable = (Drawable) bitmapDrawable;
				if (drawable != null) {
					int w = drawable.getIntrinsicWidth();
					int h = drawable.getIntrinsicHeight();
					int sw = BaseApp.sScreenWidth;
					int tmp = (int) ((float) h * ((float) sw / (float) w));
					drawable.setBounds(0, 0, sw, tmp);
				}
				return drawable;
			}
			return null;
		}
	};

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.back:
			finish();
			break;
		case R.id.font_but:
			changMenuPopState(v);
			break;
		case R.id.font_big:
			changeTextSize(true);
			break;
		case R.id.font_small:
			changeTextSize(false);
			break;
		default:
			break;
		}

	}

	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if (!isChecked) {
			FavourListBean.getInstance().removeFavourMaazineBean(0, mTitle,
					mPath);
			BaseApp.showToast("已取消收藏");
		} else {
			FavourJournalBean bean = new FavourJournalBean(mTitle, mDetail,
					mPath,belong);
			FavourListBean.getInstance().addFavourMagazineBean(bean);
			BaseApp.showToast("收藏成功");
		}
		FavourListBean.save();
	}
}
