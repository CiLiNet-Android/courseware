package com.suncco.chinacdc.magazine;

import java.util.ArrayList;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.FloatMath;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.ImagesThread;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.widget.LoadingProgressDialog;

import dalvik.system.VMRuntime;

public class PhotoBrowseActivity2 extends Activity implements OnTouchListener,
		OnClickListener {
	/*
	 * 
	 * Class Descripton goes here.
	 * 
	 * @class testactivity
	 * 
	 * @version 1.0
	 * 
	 * @author yourname
	 * 
	 * @time 2012-1-6 ����10:58:20
	 */
	// private Button big,small;
	// private Bitmap newbitmap;
	private GestureDetector mGestureDetector;
	// 动画显示
	private boolean isShowNext = true;
	Matrix savedMatrix = new Matrix();
	Matrix matrix = new Matrix();
	// Matrix savedMatrix = new Matrix();
	// 记录第一个点
	PointF first = new PointF();
	PointF start = new PointF();
	PointF mid = new PointF();
	private float oldDist;
	static final int NONE = 0;
	static final int DRAG = 1;
	static final int ZOOM = 2;
	static boolean AUTO = false;
	int mode = NONE;
	private long beginTime, endTime;
	// 禁止拖动扩大
	boolean forbidZoom = true;

	// 当前点击的是哪一张照片的位置
	private int position;
	// 所有图片列表
	private ArrayList<Bitmap> projectImageList;
	// 设备高 宽
	int dwidth, dheight;

	ImageView mImageView;
	private Bitmap mBitmap;
	private int bmWith, bmHeight;

	private float maxScale = 4.0f;
	private float minScale = 1.0f;
	private float currentScale = 1.0f;
	private float currentDx = 0.0f;
	private float currentDy = 0.0f;

	private float move_x = 5.0f;
	private float move_y = 5.0f;

	private int directDistance = 50;

	private float values[] = new float[9];

	private static final int HANDLER_IMG_WHAT = 100;

	private LoadingProgressDialog mProgressDialog;
	String mUrl;
	float TARGET_HEAP_UTILIZATION = 0.75f;
	  private final static int CWJ_HEAP_SIZE = 6* 1024* 1024 ;


	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch (msg.what) {
			case HANDLER_IMG_WHAT:
//				mBitmap = ImageLoader.getInstance().loadBitmapOrgByUrl(mUrl);
				mBitmap= BitmapLoader.getInstance().loadBitmapByPath(mUrl, BaseApp.sScreenWidth*2, BaseApp.sScreenHeight*2);
				if (mBitmap != null) {
					initScaleBitmap(mBitmap, true);
				} else {
					BaseApp.showToast("图片下载失败,请重新加载");
				}
				mProgressDialog.dismiss();
				break;
			default:
				break;

			}
		}

	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		/* display.xml Layout */
		setContentView(R.layout.photo_browse_activity);
		prepareViews();
		VMRuntime.getRuntime().setMinimumHeapSize(CWJ_HEAP_SIZE);
		VMRuntime.getRuntime()
				.setTargetHeapUtilization(TARGET_HEAP_UTILIZATION);
		// big = (Button)this.findViewById(R.id.big);
		// small = (Button)this.findViewById(R.id.small);
		//
		// big.setOnClickListener(this);
		// small.setOnClickListener(this);
		mUrl = getIntent().getStringExtra("url");
		if (mUrl == null) {
			initScaleBitmap(mBitmap, true);
			BaseApp.showToast("图片地址不存在");
			return;
		}
		LogUtil.e("browse url-->" + mUrl);
		if (mUrl.contains("http")) {
			mProgressDialog.show();
			new ImagesThread(mHandler, mUrl, HANDLER_IMG_WHAT).start();
		} else {
			// mBitmap =ImageLoader.getInstance().loadBitmapOrgByPath(mUrl);
			LogUtil.e(Runtime.getRuntime().freeMemory() + "");

//			System.gc();
//			 mBitmap =ImageUtils.getBitmapOrg(mUrl);
			mBitmap= BitmapLoader.getInstance().loadBitmapByPath(mUrl, BaseApp.sScreenWidth*2, BaseApp.sScreenHeight*2);
//			mBitmap = BitMapUtil.getBitmap(mUrl, dwidth, dheight);
//			LogUtil.e("get bm" + " width:" + mBitmap.getWidth() +"height:" +mBitmap.getHeight());
			if (mBitmap == null) {
				LogUtil.e("mBitmap fullscreen null---->" + Runtime.getRuntime().freeMemory()
						+ "");
				mBitmap = ImageUtils.getBitmapHalf(mUrl);
				if (mBitmap == null) {
//					System.gc();
					LogUtil.e("mBitmap half  null---->" + Runtime.getRuntime().freeMemory() + "");
					mBitmap = ImageUtils.getBitmapFour(mUrl);
					if (mBitmap == null) {
//						System.gc();
						LogUtil.e("mBitmap four null---->" + Runtime.getRuntime().freeMemory() + "");
						mBitmap = ImageUtils.getFitSizeImg(mUrl);
					}
				}
			}
			initScaleBitmap(mBitmap, true);
		}

		// 获取图片本身的宽 和高
		// mBitmap = BitmapFactory.decodeResource(getResources(),
		// R.drawable.loading_bg);
	}

	private void prepareViews() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		dwidth = dm.widthPixels;
		dheight = dm.heightPixels;
		mImageView = (ImageView) this.findViewById(R.id.image_view);
		mProgressDialog = new LoadingProgressDialog(this);
		mImageView = (ImageView) findViewById(R.id.image_view);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
//		if (mBitmap != null) {
//			try {
//				mBitmap.recycle();
//				System.gc();
//				// ImageLoader.getInstance().clearCache();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}

	}

	/**
	 * 
	 * <code>initScaleBitmap</code>
	 * 
	 * @description: TODO(根据图片缩放图片)
	 * @param bitmap
	 * @since 2012-1-9 liaoyp
	 */
	public void initScaleBitmap(Bitmap bitmap, boolean ishave) {
		// matrix=new Matrix();

		if (bitmap != null) {
			bmWith = bitmap.getWidth();
			bmHeight = bitmap.getHeight();

			// 获取手机屏幕的宽和高
			DisplayMetrics dm = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(dm);
			dwidth = dm.widthPixels;
			dheight = dm.heightPixels;

			LogUtil.e("bmWith" + bmWith + "\n" + "bmheight" + bmHeight + "\n"
					+ "dwith" + dwidth + "\n" + "dheight" + dheight);
			float scale;
			if (dwidth / dheight > 1) {
				scale = (float) dwidth / bmWith;
			} else {
				scale = (float) dwidth / bmWith;
			}
			// 如果宽的 比列大于搞的比列 则用高的比列 否则用宽的
			//
			// if (scaleWid > scaleHeight) {
			// scale = scaleHeight;
			// } else
			// scale = scaleWid;
			mImageView.setImageBitmap(bitmap);
			matrix = new Matrix();
			matrix.setScale(scale, scale);
			mImageView.setScaleType(ScaleType.MATRIX);

			minScale = scale;
			maxScale = 4.0f * minScale;

			matrix.getValues(values);
			currentScale = values[matrix.MSCALE_X];
			currentDx = values[matrix.MTRANS_X];
			currentDy = values[matrix.MTRANS_Y];
			if (currentScale * bmHeight < dheight) {
				values[matrix.MTRANS_Y] = (dheight - currentScale * bmHeight) / 2;
				matrix.setValues(values);
			}

			mImageView.setImageMatrix(matrix);
		} else {

			mImageView.setImageMatrix(null);
			mImageView.setScaleType(ScaleType.CENTER);
			mImageView.setImageResource(R.drawable.about_logo);
		}

		mImageView.setOnTouchListener(this);
		mImageView.setLongClickable(true);

		matrix.getValues(values);
		currentScale = values[matrix.MSCALE_X];
		currentDx = values[matrix.MTRANS_X];
		currentDy = values[matrix.MTRANS_Y];
		LogUtil.e("" + currentDx + "\n" + currentDy);
		// savedMatrix.set(matrix);
	}

	/**
	 * 
	 * <code>startShowAnimation</code>
	 * 
	 * @description: TODO(启动动画)
	 * @param isShowNext2
	 * @since 2012-1-6 liaoyp
	 */
	private void startShowAnimation(boolean isShowNext2) {
		mImageView.clearAnimation();

		if (isShowNext2) {
			mImageView.startAnimation(AnimationUtils.loadAnimation(this,
					R.anim.left_in));
			mImageView.startAnimation(AnimationUtils.loadAnimation(this,
					R.anim.left_out));
		} else {
			mImageView.startAnimation(AnimationUtils.loadAnimation(this,
					R.anim.right_in));
			mImageView.startAnimation(AnimationUtils.loadAnimation(this,
					R.anim.right_out));
		}
	}

	// 上一图片信息
	private void showPrevious() {
		// 动画标识
		isShowNext = false;

		getImageView(position - 1);
		// 初始化图片信息
		// initImageMessage();
	}

	// 下一张图片信息
	private void showNext() {
		// 动画标识
		isShowNext = true;

		getImageView(position + 1);
		// 初始化图片信息
		// initImageMessage();
	}

	private void getImageView(int Lposition) {

		position = Lposition;

		int bigSize = projectImageList.size() - 1;

		if (Lposition >= bigSize) {
			// showToast("已经是最后一张");
			position = bigSize;

		} else if (Lposition < 0) {
			// showToast("已经是第一张");
			position = 0;
		} else {// 回收图片，为什么在这里回收，我也不多讲了，因为不管是浏览上一张还是下一张
				// 都需要帮刚刚浏览的bitmap释放，否则很容易出现oo
			if (mBitmap != null) {
				mBitmap.recycle();
			}
		}
	}

	public boolean onTouch(View v, MotionEvent event) {
		if (AUTO) {
			return true;
		}
		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:

			beginTime = System.currentTimeMillis();

			mode = DRAG;
			System.out.println("down");
			first.set(event.getX(), event.getY());
			start.set(event.getX(), event.getY());
			break;
		case MotionEvent.ACTION_UP:

			endTime = System.currentTimeMillis();

			System.out.println("endTime==" + (endTime - beginTime));
			float x = event.getX(0) - first.x;
			float y = event.getY(0) - first.y;
			// 多长的距离
			float move = FloatMath.sqrt(x * x + y * y);
			// if(directionTo()){
			// return true;
			// }else{
			resetMatrix();
			// }
			System.out.println(x + " move==" + (move));
			// 方向
			// int direction = x > 0 ? 1 : -1;
			// // 计算时间和移动的距离 来判断你想要的操作
			// if (endTime - beginTime < 500 && move > 20) {
			// // 这里就是做你上一页下一页
			// // Toast.makeText(this, "----do something-----", 1000).show();
			// // 下一页
			// if (direction > 0) {
			// BaseApp.showToast("showPrevios-->");
			// // showPrevious();
			// return true;
			// }
			// // 上一页
			// if (direction < 0) {
			// BaseApp.showToast("showNext-->");
			// // showNext();
			// return true;
			// }
			//
			// }
			break;
		case MotionEvent.ACTION_MOVE:

			System.out.println("move");
			if (mode == DRAG) {
				if (forbidZoom) {
					matrix.postTranslate(event.getX() - start.x, event.getY()
							- start.y);
					matrix.getValues(values);
					float ftemp = values[matrix.MSCALE_X];
					ftemp = values[matrix.MTRANS_X];
					LogUtil.e("" + ftemp);
					ftemp = values[matrix.MTRANS_Y];
					LogUtil.e("" + ftemp);
				}
				start.set(event.getX(), event.getY());
			} else {
				LogUtil.e("point couint" + event.getPointerCount());
				if (event.getPointerCount() < 2)
					return false;
				float newDist = spacing(event);
				if (newDist > 10f) {
					// matrix.set(savedMatrix);
					float scale = newDist / oldDist;
					System.out.println("scale==" + scale);
					if (forbidZoom) {
						matrix.postScale(scale, scale, mid.x, mid.y);
					}
				}
				oldDist = newDist;
			}
			break;
		case MotionEvent.ACTION_POINTER_DOWN:
			oldDist = spacing(event);
			if (oldDist > 10f) {
				midPoint(mid, event);
				mode = ZOOM;
			}
			System.out.println("ACTION_POINTER_DOWN");
			break;
		case MotionEvent.ACTION_POINTER_UP:
			System.out.println("ACTION_POINTER_UP");
			break;
		}

		if (forbidZoom) {

			mImageView.setImageMatrix(matrix);
		}

		return false;
	}

	private void resetMatrix() {
		LogUtil.e("start resetMatrix--->");
		// mImageView.setImageBitmap(newbitmap);
		boolean done = true;
		matrix.getValues(values);
		// LogUtil.e(""+values[matrix.MSCALE_X] +"\n"+values[matrix.MSCALE_Y]
		// +"\n"+minScale+"\n"+maxScale);
		currentScale = values[matrix.MSCALE_X];

		if (currentScale < minScale) {
			done = false;
			// currentScale = ftemp;
			// currentScale += 0.05f;
			values[matrix.MSCALE_X] = minScale;
			values[matrix.MSCALE_Y] = minScale;
			matrix.setValues(values);
		} else if (currentScale > maxScale) {
			done = false;
			// currentScale = ftemp;
			// currentScale -= 0.05f;
			values[matrix.MSCALE_X] = maxScale;
			values[matrix.MSCALE_Y] = maxScale;
			matrix.setValues(values);
		}
		// mImageView.setImageMatrix(matrix);
		matrix.getValues(values);
		currentScale = values[matrix.MSCALE_X];
		currentDx = values[matrix.MTRANS_X];
		currentDy = values[matrix.MTRANS_Y];
		LogUtil.e("" + currentDx + "\n" + currentDy);
		if (currentDx > 0) {
			done = false;
			// currentDx -= move_x;
			values[matrix.MTRANS_X] = 0;
			matrix.setValues(values);
		} else if (currentDx < -(currentScale * bmWith - dwidth)) {
			done = false;
			// currentDx += move_x;
			values[matrix.MTRANS_X] = -(currentScale * bmWith - dwidth);
			matrix.setValues(values);
		}

		// mImageView.setImageMatrix(matrix);
		matrix.getValues(values);
		currentScale = values[matrix.MSCALE_X];
		currentDx = values[matrix.MTRANS_X];
		currentDy = values[matrix.MTRANS_Y];

		if (currentScale * bmHeight < dheight) {
			if (currentDy > (dheight - currentScale * bmHeight)) {
				done = false;
				// currentDy -= move_x;
				values[matrix.MTRANS_Y] = (dheight - currentScale * bmHeight);
				matrix.setValues(values);
			} else if (currentDy < 0) {
				done = false;
				values[matrix.MTRANS_Y] = 0;
				matrix.setValues(values);
			}
		} else {

			if (currentDy < -(currentScale * bmHeight - dheight)) {
				done = false;
				// currentDy -= move_x;
				values[matrix.MTRANS_Y] = -(currentScale * bmHeight - dheight);
				matrix.setValues(values);
			} else if (currentDy > 0) {
				done = false;
				values[matrix.MTRANS_Y] = 0;
				matrix.setValues(values);
			}
		}
		mImageView.setImageMatrix(matrix);

	}

	private boolean directionTo() {
		boolean direct = false;
		matrix.getValues(values);
		currentScale = values[matrix.MSCALE_X];
		currentDx = values[matrix.MTRANS_X];
		currentDy = values[matrix.MTRANS_Y];
		boolean diretToleft = false;
		if (currentDx > 0 + directDistance) {
			direct = true;
			diretToleft = true;
			BaseApp.showToast("show previours---->");

		} else if (currentDx < -(currentScale * bmWith - dwidth)
				- directDistance) {
			direct = true;
			diretToleft = false;
			BaseApp.showToast("show next---->");
		}

		return false;
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		super.onConfigurationChanged(newConfig);
		initScaleBitmap(mBitmap, true);
	}

	private Runnable runResetMatrix = new Runnable() {
		public void run() {
			// TODO Auto-generated method stub
			resetMatrix();
		}
	};

	/**
	 * 计算拖动的距离
	 * 
	 * @param event
	 * @return
	 */
	private float spacing(MotionEvent event) {

		float x = event.getX(0) - event.getX(1);
		float y = event.getY(0) - event.getY(1);
		return FloatMath.sqrt(x * x + y * y);
	}

	/**
	 * 计算两点的之间的中间点
	 * 
	 * @param point
	 * @param event
	 */

	private void midPoint(PointF point, MotionEvent event) {
		float x = event.getX(0) + event.getX(1);
		float y = event.getY(0) + event.getY(1);
		point.set(x / 2, y / 2);
	}

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub

	}
}
