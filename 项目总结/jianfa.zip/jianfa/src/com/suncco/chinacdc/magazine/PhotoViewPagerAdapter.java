package com.suncco.chinacdc.magazine;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.JournalPhotoDetailBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageLoader;
import com.suncco.chinacdc.utils.ImageUtils;
import com.suncco.chinacdc.utils.LogUtil;

/**
 * 
 * @author suncco 10036 2012-10-22
 */
public class PhotoViewPagerAdapter extends PagerAdapter {

	public ArrayList<View> mTemplateViews;
	private Context mContext;
	private JournalPhotoDetailBean mJournalPhotoDetailBean;
	private OnClickListener mOnClickListener;
	private String mPath;

	public PhotoViewPagerAdapter(Context context, JournalPhotoDetailBean beans,
			String path, OnClickListener listener) {
		this.mContext = context;
		this.mJournalPhotoDetailBean = beans;
		this.mPath = path;
		this.mOnClickListener = listener;
		mTemplateViews = new ArrayList<View>();
	}

	private View getTemplateView() {
		View convertView = LayoutInflater.from(mContext).inflate(
				R.layout.article_photo_item, null);
		ImageView img = (ImageView) convertView.findViewById(R.id.phto);
		img.setOnClickListener(mOnClickListener);
		return convertView;
	}

	private void setValues(View convertView, int position) {
		ImageView img = (ImageView) convertView.findViewById(R.id.phto);
//		Bitmap bm = ImageLoader.getInstance().loadBitmapByPath(
//				getItem(position));
		Bitmap bm = BitmapLoader.getInstance().loadBitmapByPath(getItem(position), BaseApp.sScreenWidth, BaseApp.sScreenHeight);
		if(bm == null){
//			System.gc();
//			ImageLoader.getInstance().clearCache();
			LogUtil.e("mBitmap full null---->" + Runtime.getRuntime().freeMemory() + "");
			bm = BitmapLoader.getInstance().loadBitmapByPath(getItem(position), BaseApp.sScreenWidth/2, BaseApp.sScreenHeight/2);
			if(bm == null){
				LogUtil.e("mBitmap half null---->" + Runtime.getRuntime().freeMemory() + "");
				bm = ImageUtils.getFitSizeImg(getItem(position));
			}
		}
		
		if(bm != null)
		img.setImageBitmap(bm);
	}
	
	public void checkPageContent(int position){
		Bitmap bm = ImageLoader.getInstance().loadBitmapOrgByPath(
				getItem(position));
		if(bm == null || bm.getWidth() <=0){
			notifyDataSetChanged();
		}
	}

	public String getItem(int position) {
		String value = mJournalPhotoDetailBean.mPhones.get(position);
		if (value.startsWith(".")) {
			value = value.substring(1);
		}
		return mPath + "/" + value;
	}

	@Override
	public void destroyItem(View arg0, int arg1, Object arg2) {
		View view = (View) arg2;
		((ViewPager) arg0).removeView(view);
		mTemplateViews.add(view);
	}

	@Override
	public void finishUpdate(View arg0) {
	}

	@Override
	public int getCount() {
		return mJournalPhotoDetailBean == null ? 0
				: mJournalPhotoDetailBean.mPhones.size();
	}

	@Override
	public Object instantiateItem(View view, int position) {
		ViewPager viewPager = (ViewPager) view;
		View convertView;
		if (mTemplateViews.size() == 0) {
			convertView = getTemplateView();
		} else {
			convertView = mTemplateViews.get(0);
			mTemplateViews.remove(0);
		}
		setValues(convertView, position);
		viewPager.addView(convertView);
		return convertView;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == (arg1);
	}

	@Override
	public void restoreState(Parcelable arg0, ClassLoader arg1) {
	}

	@Override
	public Parcelable saveState() {
		return null;
	}

	@Override
	public void startUpdate(View arg0) {
	}

	@Override
	public int getItemPosition(Object object) {
		return POSITION_NONE;
	}
}
