package com.suncco.chinacdc.magazine;

import java.io.File;
import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.ArticleBean;
import com.suncco.chinacdc.bean.DownloadBean;
import com.suncco.chinacdc.bean.DownloadListBean;
import com.suncco.chinacdc.bean.JournalBean;
import com.suncco.chinacdc.bean.JournalListBean;
import com.suncco.chinacdc.utils.BitmapLoader;
import com.suncco.chinacdc.utils.ImageLoader;

public class JournalAdapter extends BaseAdapter {

	private Context mContext;
	private ArrayList<JournalBean> mList;
	// 每页显示的Item个数
		public static final int SIZE = 6;

	public JournalAdapter(Context context, JournalListBean bean,int page) {
		this.mContext = context;
		int i = page * SIZE;
		int iEnd = i + SIZE;
		mList = new ArrayList<JournalBean>();
		while ((i < bean.mJournalBeans.size()) && (i < iEnd)) {
			mList.add(bean.mJournalBeans.get(i));
			i++;
		}
	}

	public int getCount() {
		return mList.size();
	}

	public JournalBean getItem(int position) {
		return mList.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void stopAllDownload() {
		for (JournalBean bean : mList) {
			if (bean.fileDownloader != null) {
				bean.fileDownloader.cancel();
				DownloadListBean.getInstance().removeDownload(bean.id);
			}
		}
	}

	static class ViewHolder {
		ImageView logo;
		RatingBar bar;
		TextView name;
		ImageView state;
		View downloaded;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.download_item, null);
			holder = new ViewHolder();
			holder.logo = (ImageView) convertView.findViewById(R.id.logo);
			holder.bar = (RatingBar) convertView
					.findViewById(R.id.progress_bar);
			holder.downloaded = convertView.findViewById(R.id.downloaded_tag);
			holder.name = (TextView) convertView.findViewById(R.id.name);
			holder.state = (ImageView) convertView.findViewById(R.id.state);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		JournalBean bean = getItem(position);
		convertView.setTag(R.id.journal_title, bean);
		
		DownloadBean download = DownloadListBean.getInstance().getDownloadBean(
				bean.id);
		if (download == null) {
			holder.bar.setVisibility(View.INVISIBLE);
			holder.state
			.setImageResource(R.drawable.download_start_tag);
			holder.state.setVisibility(View.VISIBLE);
			holder.downloaded.setVisibility(View.INVISIBLE);
		} else {
			holder.bar.setVisibility(View.VISIBLE);
			holder.bar.setRating(download.initProgress());
			holder.state.setVisibility(View.VISIBLE);
			if (download.isFinish()) {
				holder.downloaded.setVisibility(View.VISIBLE);
				holder.bar.setVisibility(View.INVISIBLE);
				holder.state.setVisibility(View.INVISIBLE);
			} else {
				holder.state.setVisibility(View.VISIBLE);
				holder.downloaded.setVisibility(View.INVISIBLE);
				if (bean.fileDownloader == null) {
					holder.state
							.setImageResource(R.drawable.download_start_tag);
				} else {
					bean.fileDownloader.regiestProgressBar(holder.bar);
					holder.state
							.setImageResource(R.drawable.download_pause_tag);
				}
			}
		}
		
		
//		Bitmap bm = ImageLoader.getInstance().loadBitmapByUrl(bean.surfaceImg);
		Bitmap bm = BitmapLoader.getInstance().loadBitmapByPath(bean.surfaceImg, BaseApp.sScreenWidth/3, BaseApp.sScreenHeight/5);
		if (bm != null) {
			holder.logo.setImageBitmap(bm);
		} else {
//			holder.logo.setImageResource(R.drawable.magazine_dufault_img);
		}

		holder.name.setText(bean.name);

		return convertView;
	}
}
