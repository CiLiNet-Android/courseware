package com.suncco.chinacdc.magazine;

import java.io.File;
import java.util.HashMap;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.DownloadBean;
import com.suncco.chinacdc.bean.DownloadListBean;
import com.suncco.chinacdc.bean.JournalBean;
import com.suncco.chinacdc.bean.JournalListBean;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.downloader.DownloadException;
import com.suncco.chinacdc.downloader.DownloadedListener;
import com.suncco.chinacdc.downloader.FileDownloader;
import com.suncco.chinacdc.downloader.ThreadPoolHelper;
import com.suncco.chinacdc.information.ArticleDetailActivity;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.ImageLoader;
import com.suncco.chinacdc.utils.ImagesThread;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.NetUtils;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.utils.ZipUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;
import com.suncco.chinacdc.widget.ScrollLayout;
import com.suncco.chinacdc.widget.ScrollLayout.PageListener;
import com.umeng.analytics.MobclickAgent;

import dalvik.system.VMRuntime;

public class JournalActivity extends BaseActivity implements OnClickListener,
		OnItemClickListener, PageListener {

	private static final int HANDLER_JOURNAL_WHAT = 100;
	private static final int HANDLER_JOURNAL_IMG_WHAT = 101;
	private static final int HANDLER_ADAPTER_NOTIFYDATESETCHANGE = 102;
	private static final int HANDLER_UN_ZIP_WHAT = 103;
	private final HashMap<Integer, String> mDownloadedStatusMapping = new HashMap<Integer, String>();
	private LoadingProgressDialog mProgress;
	private JournalAdapter mJournalAdapter;
	private String mName;
	private int type = 0;
	private String journalTypeId = "";

	JournalTabActivity mParent;

	JournalListBean mListBean;
	JournalAdapter[] mAdapters;

	/** 总页数. */
	private int PageCount;
	/** 当前页码. */
	private int PageCurrent;
	/** 每页显示的数量，Adapter保持一致. */
	private static final float PAGE_SIZE = 6.0f;
	/** GridView. */
	private GridView gridView;
	/** 自定义的左右滑动. */
	private ScrollLayout curPage;
	TextView mPageText;
	
	float TARGET_HEAP_UTILIZATION = 0.75f;
	  private final static int CWJ_HEAP_SIZE = 6* 1024* 1024 ;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		VMRuntime.getRuntime()
		.setTargetHeapUtilization(TARGET_HEAP_UTILIZATION);
		VMRuntime.getRuntime().setMinimumHeapSize(CWJ_HEAP_SIZE);
		setContentView(R.layout.download_activity);
		mName = getIntent().getStringExtra("name");
		type = getIntent().getIntExtra("type", 1);
		journalTypeId = getIntent().getStringExtra("id");
		HashMap<String, String> maps = new HashMap<String, String>();
		maps.put("杂志名",mName+"");
		maps.put("杂志id", journalTypeId+"");
		MobclickAgent.onEvent(this, UmengEvent.intoMagazineCategoryEvent, maps);
//		DownloadListBean.getInstance().mDownloadlist.clear();
		prepareView();
		File file = new File(Constans.DOWNLOAD_DIR);
		if (!file.isDirectory()) {
			file.mkdirs();
		}
		getJournalList();
		mDownloadedStatusMapping.put(DownloadedListener.DOWNLOAD_PAUSE,
				getString(R.string.appmanager_download_finish_status_cancel));
		mDownloadedStatusMapping.put(DownloadedListener.DOWNLOAD_BREAK_OFF,
				getString(R.string.appmanager_download_finish_status_breek_of));
		mDownloadedStatusMapping.put(
				DownloadedListener.DOWNLOAD_FIALED_NETWORK,
				getString(R.string.appmanager_download_finish_status_failure));
		mDownloadedStatusMapping
				.put(DownloadedListener.DOWNLOAD_FIALED_SD_UNABLE,
						getString(R.string.appmanager_download_finish_status_failure_sd_unable));
		mDownloadedStatusMapping
				.put(DownloadedListener.DOWNLOAD_FIALED_SD_MEMORY_LACK,
						getString(R.string.appmanager_download_finish_status_failure_sd_memory_lack));
		mDownloadedStatusMapping.put(DownloadedListener.DOWNLOAD_SUCCEED,
				getString(R.string.appmanager_download_finish_status_succeed));
	}

	private void prepareView() {
		mProgress = new LoadingProgressDialog(this);
		mParent = (JournalTabActivity) getParent();
		mPageText = (TextView) findViewById(R.id.title_page_text);
		curPage = (ScrollLayout) findViewById(R.id.journal_scroll);
		curPage.getLayoutParams().height = BaseApp.sScreenHeight * 4 / 5;
		curPage.setPageListener(this);
	}

	private void getJournalList() {
		mProgress.show();
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		utils.addNameAndValue("journalTypeId", getIntent().getStringExtra("id"));
		new ChinacdcThread(JournalListBean.class, utils.formatParams(),
				mHandler, HANDLER_JOURNAL_WHAT).start();
	}

	@Override
	protected void onDestroy() {
		if (mAdapters != null) {
			finishDownload();
		}
		super.onDestroy();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		// page(PageCurrent);
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		ImageLoader.getInstance().clearCache();
	}

	private void download(final JournalBean journalBean) {
		File file = new File(Constans.DOWNLOAD_DIR + mName + "_"
				+ journalBean.name + ".zip");
		deleteFile(file);
		file = new File(Constans.DOWNLOAD_DIR + journalBean.id
				+ journalBean.name.hashCode());
		deleteFile(file);
		DownloadBean bean = DownloadListBean.getInstance().getDownloadBean(
				journalBean.id);
		if (bean == null) {
			bean = new DownloadBean(journalBean.id, mName + "_"
					+ journalBean.name, journalBean.zipUrl);
			DownloadListBean.getInstance().addDownload(bean);
			DownloadListBean.save();
		}
		final FileDownloader fileDownloader = new FileDownloader(bean);
		journalBean.fileDownloader = fileDownloader;
		ThreadPoolHelper.execute(new Runnable() {
			public void run() {
				try {
					if (fileDownloader.isCancel()) {
						journalBean.fileDownloader = null;
						mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
						return;
					}
					journalBean.fileDownloader.getFileMessage();
					if (fileDownloader.isCancel()) {
						journalBean.fileDownloader = null;
						mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
						return;
					}
					if (journalBean.fileDownloader != null)
						journalBean.fileDownloader
								.download(new DownloadedListener() {

									public void onDownloadFinish(
											final int status) {
										if (journalBean.fileDownloader != null)
											journalBean.fileDownloader = null;
										// openZipFile(journalBean);
										if(status !=  DownloadedListener.DOWNLOAD_SUCCEED){
											BaseApp.showToast(journalBean.name
													+ mDownloadedStatusMapping
													.get(status));
											deleteBadDownoad(journalBean);
											mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
											String[] name = new String[]{"标准版","简版"};
											String journalTypeName = name[0];
											try {
												journalTypeName = name[Integer.valueOf(journalBean.contentType)];
											} catch (NumberFormatException e) {
												e.printStackTrace();
											}
											HashMap<String, String> downMagazine = new HashMap<String, String>();
											downMagazine.put("杂志名",journalTypeName + "_" +"_"+mName);
											downMagazine.put("杂志id", journalTypeId+"");
											downMagazine.put("期数名称", journalTypeName + "_"+journalBean.name);
											downMagazine.put("期数id", journalTypeName + "_"+journalBean.name+"_"+journalBean.id);
											
											MobclickAgent.onEvent(JournalActivity.this, UmengEvent.downMagazineEvent, downMagazine);
											return;
										}
										new Thread(new Runnable() {
											public void run() {
												// TODO Auto-generated method stub
												try {
													ZipUtils.decompress(
															Constans.DOWNLOAD_DIR
																	+ mName
																	+ "_"
																	+ journalBean.name
																	+ ".zip",
															Constans.DOWNLOAD_DIR
																	+ journalBean.id
																	+ journalBean.name.hashCode());
													BaseApp.showToast(journalBean.name
															+ mDownloadedStatusMapping
																	.get(status));
													mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
												} catch (Exception e) {
													BaseApp.showToast("解压文件出错");
													deleteBadDownoad(journalBean);
													mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
													e.printStackTrace();
												}
											}
										}).start();
									}
								});
				} catch (DownloadException e) {
					e.printStackTrace();
					BaseApp.showToast(journalBean.name + "下载失败");
					journalBean.fileDownloader = null;
					mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
				}
			}
		});
	}

	private void openZipFile(final JournalBean bean) {
		mProgress.show();
		new Thread(new Runnable() {

			public void run() {
				Message msg = new Message();
				msg.obj = bean;
				msg.what = HANDLER_UN_ZIP_WHAT;
				try {
					ZipUtils.decompress(Constans.DOWNLOAD_DIR + mName + "_"
							+ bean.name + ".zip", Constans.DOWNLOAD_DIR
							+ bean.id + bean.name.hashCode());
					msg.arg1 = 1;
				} catch (Exception e) {
					e.printStackTrace();
					msg.arg1 = 0;
				}
				mHandler.sendMessage(msg);
			}
		}).start();
	}

	// 4建发通讯01
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {

		final JournalBean bean = (JournalBean) view.getTag(R.id.journal_title);
		DownloadBean download = DownloadListBean.getInstance().getDownloadBean(
				bean.id);
		if (download != null && download.isFinish()) {
			File dir = new File(Constans.DOWNLOAD_DIR + bean.id + bean.name.hashCode());
			if (dir.exists()) {
				File file = findBuildFile(dir, "build.xml");
				if (file != null) {
					if (bean.contentType.equals("1")) {
						Intent intent = new Intent(this,
								JournalDetailActivity.class);
						intent.putExtra("name", bean.name);
						intent.putExtra("path", file.getParent());

						startActivity(intent);
					} else {
						Intent intent = new Intent(this,
								JournalPhotoDetailActivity.class);
						intent.putExtra("path", file.getParent());
						intent.putExtra("belong", bean.name + "");
						startActivity(intent);
					}
				} else {
					openZipFile(bean);
					// BaseApp.showToast("杂志解压失败");
					// deleteFile(dir);
				}
			} else {
				openZipFile(bean);
			}
		} else {
			if (bean.fileDownloader == null) {
				if (NetUtils.isWifiConnected(JournalActivity.this)) {
					download(bean);
				} else {
					AlertDialog.Builder builder = new AlertDialog.Builder(
							JournalActivity.this);
					builder.setTitle("警告");
					builder.setMessage("您未使用WIFI，请确认是否下载文件");
					DialogInterface.OnClickListener l = new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							if (which == DialogInterface.BUTTON_POSITIVE) {
								download(bean);
							}
						}
					};
					builder.setPositiveButton("下载", l);
					builder.setNegativeButton("取消", null);
					builder.create().show();
				}

			} else {
				bean.fileDownloader.cancel();
//				deleteBadDownoad(bean);
				// File file = new File(Constans.DOWNLOAD_DIR
				// + mName + "_" + bean.name + ".zip");
				// deleteFile(file);
				// file = new File(Constans.DOWNLOAD_DIR + bean.id
				// + bean.name);
				// deleteFile(file);
				// DownloadListBean.getInstance().removeDownload(bean.id);
				mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
			}
			// mJournalAdapter.notifyDataSetChanged();
			setAdapterNotify();
		}
	}

	private void open(JournalBean bean) {
		File dir = new File(Constans.DOWNLOAD_DIR + bean.id + bean.name.hashCode());
		File file = findBuildFile(dir, "build.xml");
		if (dir.exists() && file != null) {
			if (bean.contentType.equals("1")) {
				Intent intent = new Intent(this, JournalDetailActivity.class);
				intent.putExtra("name", bean.name);
				intent.putExtra("path", file.getParent());
				LogUtil.i(file.getPath());
				startActivity(intent);
			} else {
				Intent intent = new Intent(this,
						JournalPhotoDetailActivity.class);
				intent.putExtra("path", file.getParent());
				intent.putExtra("belong", bean.name + "");
				LogUtil.i(file.getPath());
				startActivity(intent);
			}
			String[] name = new String[]{"标准版","简版"};
			String journalTypeName = name[0];
			try {
				journalTypeName = name[Integer.valueOf(bean.contentType)];
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
			HashMap<String, String> maps = new HashMap<String, String>();
			maps.put("期数名称",journalTypeName + "_"+bean.name+"");
			maps.put("期数id",journalTypeName + "_"+bean.name+"_"+ bean.id+"");
			maps.put("杂志id", journalTypeId+"");
			maps.put("杂志名", journalTypeName + "_"+mName+"");
			MobclickAgent.onEvent(JournalActivity.this, UmengEvent.intoMagazineTermEvent, maps);
		} else {
			openZipFile(bean);
			// BaseApp.showToast("解压失败");
			// deleteFile(dir);
		}
	}

	public void onClick(View v) {
		finish();
	}

	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_JOURNAL_WHAT) {
				mProgress.dismiss();
				JournalListBean bean = (JournalListBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_load_exc);
				} else {
					if (bean.code == 0) {
						mListBean = new JournalListBean();
						for (int i = 0, l = bean.mJournalBeans.size(); i < l; i++) {
							if (Integer
									.valueOf(bean.mJournalBeans.get(i).contentType) == type) {
								mListBean.mJournalBeans.add(bean.mJournalBeans
										.get(i));
							}
						}
						// mListBean = bean;
						setGrid();
						new ImagesThread(mHandler, bean.getImageUrls(),
								HANDLER_JOURNAL_IMG_WHAT).start();
					} else {
						// BaseApp.showToast(bean.message);
						BaseApp.showSessionnDialog(JournalActivity.this, bean);
					}
				}
			} else if (msg.what == HANDLER_JOURNAL_IMG_WHAT) {
				// mJournalAdapter.notifyDataSetChanged();
				setAdapterNotify();
			} else if (msg.what == HANDLER_ADAPTER_NOTIFYDATESETCHANGE) {
				// mJournalAdapter.notifyDataSetChanged();
				setAdapterNotify();
			} else if (msg.what == HANDLER_UN_ZIP_WHAT) {
				mProgress.dismiss();
				JournalBean bean = (JournalBean) msg.obj;
				if (msg.arg1 == 0) {
					onUpZipFailed(bean);
				} else {
					open(bean);
				}
			}
		};
	};

	private void onUpZipFailed(final JournalBean bean) {
		new AlertDialog.Builder(this)
				.setTitle(R.string.app_prompt)
				.setMessage(bean.name + " 文件解压失败。")
				.setPositiveButton("删除下载",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								deleteBadDownoad(bean);
								// File file = new File(Constans.DOWNLOAD_DIR
								// + mName + "_" + bean.name + ".zip");
								// deleteFile(file);
								// file = new File(Constans.DOWNLOAD_DIR +
								// bean.id
								// + bean.name);
								// deleteFile(file);
								// DownloadListBean.getInstance().removeDownload(bean.id);
								mHandler.sendEmptyMessage(HANDLER_ADAPTER_NOTIFYDATESETCHANGE);
							}
						}).setNegativeButton("取消", null).create().show();
	}

	private void deleteFile(File file) {
		if (file.exists()) {
			if (file.isFile()) {
				file.delete();
			} else if (file.isDirectory()) {
				File files[] = file.listFiles();
				for (int i = 0; i < files.length; i++) {
					this.deleteFile(files[i]);
				}
			}
			file.delete();
		} else {
			System.out.println("所删除的文件不存在！" + '\n');
		}
	}

	/**
	 * build.xml
	 * 
	 * @param file
	 * @param name
	 * @return
	 */
	private File findBuildFile(File file, String name) {
		if (!file.exists()) {
			return null;
		}
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			for (File f : files) {
				File mark = findBuildFile(f, name);
				if (mark != null) {
					return mark;
				}
			}
		} else {
			return file.getName().equals(name) ? file : null;
		}
		return null;
	}

	/**
	 * 添加GridView
	 */
	private void setGrid() {

		PageCount = (int) Math.ceil(mListBean.mJournalBeans.size() / PAGE_SIZE);
		if (gridView != null) {
			curPage.removeAllViews();
		}
		mAdapters = new JournalAdapter[PageCount];
		for (int i = 0; i < PageCount; i++) {
			gridView = new GridView(this);
			mAdapters[i] = new JournalAdapter(this, mListBean, i);
			gridView.setAdapter(mAdapters[i]);
			gridView.setNumColumns(3);
			gridView.setHorizontalSpacing(20);
			gridView.setVerticalSpacing(30);
			// gridView.setColumnWidth(BaseApp.sScreenWidth/3);
			gridView.setPadding(15, 0, 15, 0);
			// 去掉点击时的黄色背景
			gridView.setSelector(R.drawable.transparent);
			gridView.setOnItemClickListener(this);
			curPage.addView(gridView);
		}
		page(0);
	}

	private void setAdapterNotify() {
		for (int i = 0, l = mAdapters.length; i < l; i++) {
			mAdapters[i].notifyDataSetChanged();
		}

	}

	private void finishDownload() {
		for (int i = 0, l = mAdapters.length; i < l; i++) {
			mAdapters[i].stopAllDownload();
		}

	}

	@Override
	public void page(int page) {
		// TODO Auto-generated method stub
		PageCurrent = page;
		// mJournalAdapter = mAdapters[PageCurrent];
		if (PageCount > 1) {
			mPageText.setText(PageCurrent + 1 + "");
			mPageText.setVisibility(View.VISIBLE);
		} else {
			mPageText.setVisibility(View.INVISIBLE);
		}

	}

	private void deleteBadDownoad(JournalBean bean) {
		File file = new File(Constans.DOWNLOAD_DIR + mName + "_" + bean.name
				+ ".zip");
		deleteFile(file);
		file = new File(Constans.DOWNLOAD_DIR + bean.id + bean.name.hashCode());
		deleteFile(file);
		DownloadListBean.getInstance().removeDownload(bean.id);

	}

}
