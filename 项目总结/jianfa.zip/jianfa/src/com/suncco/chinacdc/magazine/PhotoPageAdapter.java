package com.suncco.chinacdc.magazine;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.suncco.chinacdc.R;

public class PhotoPageAdapter extends BaseAdapter {

	private Context mContext;
	private ArrayList<HashMap<String, String>> mValues;

	public PhotoPageAdapter(Context context,
			ArrayList<HashMap<String, String>> values) {
		this.mContext = context;
		this.mValues = values;
	}

	public int getCount() {
		return mValues == null ? 0 : mValues.size();
	}

	public HashMap<String, String> getItem(int position) {
		return mValues.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	static class ViewHolder {
		TextView title;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.photo_page_item, null);
			holder.title = (TextView) convertView.findViewById(R.id.page_title);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.title.setText(getItem(position).get("title"));
		return convertView;
	}

}
