package com.suncco.chinacdc.magazine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.xmlpull.v1.XmlPullParserException;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.JournalArticleBean;
import com.suncco.chinacdc.bean.JournalDetailBean;
import com.suncco.chinacdc.information.ArticleDetailActivity;
import com.suncco.chinacdc.utils.UmengEvent;
import com.suncco.chinacdc.widget.ViewPagerIndicator;
import com.umeng.analytics.MobclickAgent;

public class JournalDetailActivity extends BaseActivity implements
		OnClickListener, OnPageChangeListener {

	private JournalDetailBean mJournalDetailBean;
	private ViewPager mViewPager;
	private ViewPagerAdapter mViewPagerAdapter;
	private ViewPagerIndicator mViewPagerIndicator;
	private String mPath;
	private String mTitleName;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journal_detail_activity);
		prepareView();
		if (mJournalDetailBean != null) {
			mViewPagerAdapter = new ViewPagerAdapter(this,
					mJournalDetailBean.mPageList, this);
			mViewPager.setAdapter(mViewPagerAdapter);
			mViewPager.setOnPageChangeListener(this);
			mViewPagerIndicator.setPageCount(mViewPagerAdapter.getCount());
		} else {
			openFailed();
		}
		
	}

	private void openFailed() {
		new AlertDialog.Builder(this).setTitle(R.string.app_warn)
				.setMessage(R.string.magazine_open_exc)
				.setOnCancelListener(new DialogInterface.OnCancelListener() {

					public void onCancel(DialogInterface dialog) {
						finish();
					}
				}).show();
	}

	private void prepareView() {
//		String name = getIntent().getStringExtra("name");
		mTitleName = getIntent().getStringExtra("name") + "";
		mPath = getIntent().getStringExtra("path");
		TextView title = (TextView) findViewById(R.id.journal_title);
		title.setText(mTitleName);
		mViewPagerIndicator = (ViewPagerIndicator) findViewById(R.id.viewpager_indicator);
		findViewById(R.id.back).setOnClickListener(this);
		mViewPager = (ViewPager) findViewById(R.id.aritcle_Pager);
		try {
			mJournalDetailBean = JournalDetailBean.parseJournalDetailBean(mPath
					+ "/build.xml");
		} catch (XmlPullParserException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		} else {
			int index = Integer.valueOf(v.getTag().toString());
			ArrayList<JournalArticleBean> beans = mJournalDetailBean.mPageList
					.get(mViewPager.getCurrentItem());
			if (index < beans.size()) {
				JournalArticleBean bean = beans.get(index);
				Intent intent = new Intent(this, JournalArticleActivity2.class);
				intent.putExtra("title", bean.title);
				intent.putExtra("detail", bean.detail);
				intent.putExtra("path", mPath);
				intent.putExtra("belong", mTitleName);
				HashMap<String, String> maps = new HashMap<String, String>();
				maps.put("杂志新闻名",bean.title+"");
				maps.put("杂志新闻id", bean.articleId+"");
				maps.put("杂志id", mJournalDetailBean.journalId+"");
				maps.put("杂志名", mJournalDetailBean.journalName+"");
				MobclickAgent.onEvent(JournalDetailActivity.this, UmengEvent.intoMagazineNewEvent, maps);
				startActivity(intent);
			}
		}
	}

	public void onPageScrollStateChanged(int arg0) {
		// TODO Auto-generated method stub

	}

	public void onPageScrolled(int arg0, float arg1, int arg2) {
		// TODO Auto-generated method stub
		mViewPagerIndicator.onSroll(arg0, arg1);
	}

	public void onPageSelected(int arg0) {
		// TODO Auto-generated method stub

	}
}
