/**
 * 
 */
package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

/**
 * 
 * @author suncco 10036 2012-10-21
 */
public class DownloadListBean extends BaseBean implements Serializable {

	private static final long serialVersionUID = 1478743301856620295L;

	private static DownloadListBean sDownloadListBean;

	public ArrayList<DownloadBean> mDownloadlist = new ArrayList<DownloadBean>();

	private DownloadListBean() {
	}

	/**
	 * 获得单例的 DownloadListBean
	 * 
	 * @return
	 */
	public synchronized static DownloadListBean getInstance() {
		if (sDownloadListBean == null) {
			sDownloadListBean = (DownloadListBean) ObjectCacheUtils
					.readObject(Constans.CACHE_DIR
							+ DownloadListBean.class.getSimpleName().hashCode());
			if (sDownloadListBean == null) {
				sDownloadListBean = new DownloadListBean();
			}
		}
		return sDownloadListBean;
	}

	public DownloadBean getDownloadBean(String id) {
		for (DownloadBean bean : mDownloadlist) {
			if (bean.id.equals(id)) {
				return bean;
			}
		}
		return null;
	}

	public void addDownload(DownloadBean bean) {
		if (!isOnDownloadList(bean.id)) {
			mDownloadlist.add(bean);
		}
	}
	
	public boolean removeDownload(String id) {
		for (DownloadBean bean : mDownloadlist) {
			if (bean.id.equals(id)) {
				return mDownloadlist.remove(bean);
			}
		}
		save();
		return false;
	}

	public boolean isOnDownloadList(String id) {
		for (DownloadBean bean : mDownloadlist) {
			if (bean.id.equals(id)) {
				return true;
			}
		}
		return false;
	}
	
	

	public boolean isDownloaded(String id) {
		for (DownloadBean bean : mDownloadlist) {
			if (bean.id.equals(id)) {
				return bean.isDownloaded();
			}
		}
		return false;
	}

	public static void save() {
		ObjectCacheUtils.cacheObject(Constans.CACHE_DIR
				+ DownloadListBean.class.getSimpleName().hashCode(),
				sDownloadListBean);
	}
}
