package com.suncco.chinacdc.bean;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.FileUtils;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class OrganizationListBean extends WebServiceBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8896605874761556176L;
	public static final String methodName = "getMembersAndOrgByOrgId";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	public static final String FILE_CACHE = Constans.DIR + "organization/";

	public String id = "0";
	public String name = "建发集团";
	public String parentId;
	public String type="1";

	public ArrayList<OrganizationBean> mOrganizationBeans = new ArrayList<OrganizationBean>();
	public ArrayList<UserBean> mUserBeans = new ArrayList<UserBean>();

	public static OrganizationListBean parseOrganizationListBean(SoapObject obj) {

		OrganizationListBean bean = new OrganizationListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");

			if (obj.hasProperty("group")) {
				SoapObject group = (SoapObject) obj.getProperty("group");
				LogUtil.e(group.toString() + "");
				if (group.hasProperty("id")) {
					bean.id = getString(group.getProperty("id").toString());
					bean.name = getString(group.getProperty("name").toString());
					bean.parentId = getString(group.getProperty("parentId")
							.toString());
					bean.type =  getString(group.getProperty("type")
							.toString());
				}
			}

			if (obj.hasProperty("child_users")) {
				SoapObject users = (SoapObject) obj.getProperty("child_users");
				// LogUtil.i(users.toString());
				int len = users.getPropertyCount();
				for (int i = 0; i < len; i++) {
					UserBean user = UserBean.parseUserBean((SoapObject) users
							.getProperty(i));
					if (user != null) {
						user.orgType = bean.type;
						bean.mUserBeans.add(user);
					}
				}
			}
			if (obj.hasProperty("child_groups")) {
				SoapObject groups = (SoapObject) obj
						.getProperty("child_groups");
				int len = groups.getPropertyCount();
				for (int i = 0; i < len; i++) {
					OrganizationBean organization = OrganizationBean
							.parseOrganizationBean((SoapObject) groups
									.getProperty(i));
					if (organization != null) {
						bean.mOrganizationBeans.add(organization);
					}
				}
			}
		}
		return bean;
	}

	public boolean save() {
		try {
			if(!new File(FILE_CACHE).isDirectory()){
				new File(FILE_CACHE).mkdirs();
			}
			return ObjectCacheUtils.cacheObject(
					FILE_CACHE
							+ (LoginBean.getInstance().userId +this.type+ this.id + "")
									.hashCode(), this);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void clear(String orgId,String type) {
		
		File file = new File(FILE_CACHE + (LoginBean.getInstance().userId
				+ type + orgId + "").hashCode());
		if (file.exists()) {
			file.delete();
		}
	}
	
	public static void deleteAll(){
		FileUtils.deleteFile(new File(FILE_CACHE));
	}

	public static OrganizationListBean getOrgListBean(String orgID ,String type) {
		OrganizationListBean listBean;
		listBean = (OrganizationListBean) ObjectCacheUtils
				.readObject(FILE_CACHE +( LoginBean.getInstance().userId + type + orgID
						+ "").hashCode());
		return listBean;
	}

}
