package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class FavourListBeanOffice extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 215888775260150036L;
	
	public static int TYPE_ARTICLE = 0;
	public static int TYPE_MARKET = 2;
	public static int TYPE_OFFICE = 3;

	private static FavourListBeanOffice sFavourListBean;
	private ArrayList<FavourArticleBean> mFavourArticleBeans = new ArrayList<FavourArticleBean>();
//	private ArrayList<FavourJournalBean> mFavourMagazineBeans = new ArrayList<FavourJournalBean>();
//	private ArrayList<FavourArticleBean> mFavourArticleBeansMarket = new ArrayList<FavourArticleBean>();
//	private ArrayList<FavourArticleBean> mFavourArticleBeansOffice = new ArrayList<FavourArticleBean>();

	private FavourListBeanOffice() {
	}

	public boolean hasArticleBean(String id) {
		for (FavourArticleBean bean : mFavourArticleBeans) {
			if (bean.id.equals(id)) {
				return true;
			}
		}
		return false;
	}
	


	public static void save() {
		ObjectCacheUtils.cacheObject(FavourListBean.FILE_CACHE
				+ FavourListBeanOffice.class.getSimpleName().hashCode(),
				sFavourListBean);
	}

	public static FavourListBeanOffice getInstance() {
//		if (sFavourListBean == null) {
			sFavourListBean = (FavourListBeanOffice) ObjectCacheUtils
					.readObject(FavourListBean.FILE_CACHE
							+ FavourListBeanOffice.class.getSimpleName().hashCode());
			if (sFavourListBean == null) {
				sFavourListBean = new FavourListBeanOffice();
			}
//		}
		return sFavourListBean;
	}

	public ArrayList<FavourArticleBean> getFavourArticleBeans() {
		return mFavourArticleBeans;
	}

	public void addFavourArticleBean(ArticleDetailBean detail) {
		if (!hasArticleBean(detail.id)) {
			FavourArticleBean bean = new FavourArticleBean(detail);
			mFavourArticleBeans.add(bean);
			save();
		}
	}

	public void removeFavourArticleBean(String id) {
		FavourArticleBean favourArticleBean = null;
		for (FavourArticleBean bean : mFavourArticleBeans) {
			if (bean.id.equals(id)) {
				favourArticleBean = bean;
			}
		}
		mFavourArticleBeans.remove(favourArticleBean);
		save();
	}
	
	public void removeFavourArticleBean(ArrayList<FavourArticleBean> beans) {
//		FavourArticleBean favourArticleBean = null;
		for (FavourArticleBean bean : beans) {
				removeFavourArticleBean(bean.id);
		}
		save();
	}


	
}
