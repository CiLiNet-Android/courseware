package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.HashMap;

import android.text.TextUtils;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class SettingsBean extends WebServiceBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4605028877760633285L;

	private static SettingsBean sSettingsBean;
	private HashMap<String, String> mSettingsMap = new HashMap<String, String>();

	private SettingsBean() {
	}

	public synchronized static SettingsBean getInstance() {
		if (sSettingsBean == null) {
			sSettingsBean = (SettingsBean) ObjectCacheUtils
					.readObject(Constans.CACHE_DIR
							+ SettingsBean.class.getSimpleName().hashCode());
			if (sSettingsBean == null) {
				sSettingsBean = new SettingsBean();
			}
		}
		return sSettingsBean;
	}

	public String getSettingValueByName(String name) {
		return mSettingsMap.get(name);
	}

	public int getSettingValueByName(String name, int defaultValue) {
		String value = mSettingsMap.get(name);
		if (TextUtils.isEmpty(value)) {
			return defaultValue;
		}
		return Integer.valueOf(value);
	}

	public void putSettingValue(String name, String value) {
		LogUtil.i(name + ",  " + value);
		if (mSettingsMap.containsKey(name)) {
			mSettingsMap.remove(name);
			LogUtil.i(name + "已经存在  out value : " + value);
		}
		mSettingsMap.put(name, value);
		LogUtil.i("保存 :" + mSettingsMap.get(name));
	}

	public void delSettingValue(String name) {
		if (mSettingsMap.containsKey(name)) {
			mSettingsMap.remove(name);
		}
	}

	public static void save() {
		ObjectCacheUtils.cacheObject(Constans.CACHE_DIR
				+ SettingsBean.class.getSimpleName().hashCode(), sSettingsBean);
	}
}
