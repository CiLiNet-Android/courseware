package com.suncco.chinacdc.bean;


public class ClearFileBean extends BaseBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6964405326675859701L;
	public String name;
	public String path;
	public String size;
	public boolean isClear = false;
	public ClearFileBean(String name, String path) {
		super();
		this.name = name;
		this.path = path;
	}

}
