package com.suncco.chinacdc.bean;

import java.io.File;
import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class OrganizationCustomListBean extends OrganizationListBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8896605874761556176L;
	public static final String methodName = "getCustomMembersAndOrgByOrgId";
	public static final String serverUrl = Constans.CUSTOMORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

//	public static final String FILE_CACHE = Constans.CACHE_DIR + "organization";

//	public String id = "0";
//	public String name = "建发集团";
//	public String parentId;
//	public int type;
	
//	public ArrayList<OrganizationBean> mOrganizationBeans = new ArrayList<OrganizationBean>();
//	public ArrayList<UserBean> mUserBeans = new ArrayList<UserBean>();

	public static OrganizationCustomListBean parseOrganizationCustomListBean(SoapObject obj) {

		OrganizationCustomListBean bean = new OrganizationCustomListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");

			if (obj.hasProperty("group")) {
				SoapObject group = (SoapObject) obj.getProperty("group");
				LogUtil.e(group.toString() + "");
				if (group.hasProperty("id")) {
					bean.id = getString(group.getProperty("id").toString());
					bean.name = getString(group.getProperty("name").toString());
					bean.parentId = getString(group.getProperty("parentId")
							.toString());
					
					bean.type =  getString(group.getProperty("type")
							.toString());

				}
			}

			if (obj.hasProperty("child_users")) {
				SoapObject users = (SoapObject) obj.getProperty("child_users");
				// LogUtil.i(users.toString());
				int len = users.getPropertyCount();
				for (int i = 0; i < len; i++) {
					UserBean user = UserBean.parseUserBean((SoapObject) users
							.getProperty(i));
					if (user != null) {
						user.orgType = bean.type;
						bean.mUserBeans.add(user);
					}
				}
			}
			if (obj.hasProperty("child_groups")) {
				SoapObject groups = (SoapObject) obj
						.getProperty("child_groups");
				int len = groups.getPropertyCount();
				for (int i = 0; i < len; i++) {
					OrganizationBean organization = OrganizationBean
							.parseOrganizationBean((SoapObject) groups
									.getProperty(i));
					if (organization != null) {
						bean.mOrganizationBeans.add(organization);
					}
				}
			}
		}
		return bean;
	}

}
