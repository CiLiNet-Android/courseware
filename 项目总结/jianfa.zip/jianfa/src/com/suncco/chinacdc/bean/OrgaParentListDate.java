package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.utils.SoapUtil;

public class OrgaParentListDate extends BaseBean {

	public String id = "0";
	public String name = "";

	public static OrgaParentListDate parseOrgaParentListDate(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		OrgaParentListDate bean = new OrgaParentListDate();
		bean.id = obj.getProperty("id").toString();
		bean.name = obj.getProperty("name").toString();
//		if (obj.hasProperty("parentId")) {
//			bean.parentId = obj.getProperty("parentId").toString();
//		}
//		bean.count = Integer.valueOf(obj.getProperty("count").toString());
		return bean;
	}

}
