package com.suncco.chinacdc.bean;

import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;

public class OrgaParentListBean extends WebServiceBean {

/**
	 * 
	 */
	private static final long serialVersionUID = -1538873510164104789L;
	//	public static final String methodName = "getCustomParentOrganizationList";
	public static final String methodName = "getParentOrganizationList";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;
	
	
	public ArrayList<OrgaParentListDate> mList = new ArrayList<OrgaParentListDate>();
	
	public static OrgaParentListBean parseOrgaParentListBean(
			SoapObject obj) {

		OrgaParentListBean bean = new OrgaParentListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			if(obj.hasProperty("groups")){
				SoapObject group = (SoapObject) obj
						.getProperty("groups");
				for(int i = 0, len = group.getPropertyCount(); i < len ; i++){
					OrgaParentListDate date = OrgaParentListDate
							.parseOrgaParentListDate((SoapObject) group
									.getProperty(i));
					if (date != null) {
						bean.mList.add(date);
					}
				}
			}
			
		}
		return bean;
	}
}
