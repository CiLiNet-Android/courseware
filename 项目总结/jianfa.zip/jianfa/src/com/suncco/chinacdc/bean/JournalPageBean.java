package com.suncco.chinacdc.bean;

public class JournalPageBean {

}
