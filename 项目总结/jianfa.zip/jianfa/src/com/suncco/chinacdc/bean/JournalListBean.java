package com.suncco.chinacdc.bean;

import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;

public class JournalListBean extends WebServiceBean {

	public static final String methodName = "getPeriodsList";
	public static final String serverUrl = Constans.JOURNAL_SERVICE;
	public static final String nameSpace = Constans.NAME_SPACE;

	public ArrayList<JournalBean> mJournalBeans = new ArrayList<JournalBean>();

	public String[] getImageUrls() {
		int len = mJournalBeans.size();
		String[] urls = new String[len];
		for (int i = 0; i < len; i++) {
			urls[i] = mJournalBeans.get(i).surfaceImg;
		}
		return urls;
	}

	public static JournalListBean parseJournalListBean(SoapObject obj) {
		JournalListBean bean = new JournalListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			if (obj.hasProperty("periods")) {
				obj = (SoapObject) obj.getProperty("periods");
				int len = obj.getPropertyCount();
				for (int i = 0; i < len; i++) {
					JournalBean journal = JournalBean
							.parseJournalBean((SoapObject) obj.getProperty(i));
					if (journal != null) {
						bean.mJournalBeans.add(journal);
					}
				}
			}
		}
		return bean;
	}

}
