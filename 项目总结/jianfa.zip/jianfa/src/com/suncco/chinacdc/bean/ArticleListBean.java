package com.suncco.chinacdc.bean;

import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;

public class ArticleListBean extends WebServiceBean {

	public static final String methodName = "getArticleList";
	public static final String serverUrl = Constans.ARTICLE_SERVICE;
	public static final String nameSpace = Constans.NAME_SPACE;

	public int total;
	public ArrayList<ArticleBean> mArticleBeans = new ArrayList<ArticleBean>();

	public static ArticleListBean parseArticleListBean(SoapObject obj) {
		ArticleListBean bean = new ArticleListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			bean.total = Integer.valueOf(obj.getProperty("total").toString());
			int count = obj.getPropertyCount() - 1;
			for (int i = 0; i < count; i++) {
				ArticleBean article = ArticleBean
						.parseArticleBean((SoapObject) obj.getProperty(i));
				if (article != null) {
					bean.mArticleBeans.add(article);
				}
			}
		}
		return bean;
	}

	public void addPage(ArticleListBean bean) {
		this.total = bean.total;
		this.mArticleBeans.addAll(bean.mArticleBeans);
	}

	public int getCurrentPage() {
		return total % mArticleBeans.size() == 0 ? total / mArticleBeans.size()
				: (total / mArticleBeans.size() + 1);
	}

	public boolean hasNextPage() {
		LogUtil.i(mArticleBeans.size() + ", " + total);
		return mArticleBeans.size() < total && mArticleBeans.size() != 0;
	}
	
	public String[] getImages(){
		String[] imgs = new String[mArticleBeans.size()];
		for( int i = 0 , l = mArticleBeans.size(); i < l ; i ++){
			imgs[i] = mArticleBeans.get(i).titleImg;
		}
		return imgs;
	}

}
