package com.suncco.chinacdc.bean;


public class JournalArticleBean extends BaseBean {

	public String articleId;
	public String title;
	public String date;
	public String hasImage;
	public String imgPath;
	public String detail;

}
