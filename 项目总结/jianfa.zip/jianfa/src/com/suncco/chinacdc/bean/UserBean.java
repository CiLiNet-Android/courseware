package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.text.MessageFormat;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.utils.SoapUtil;

public class UserBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3174800056940702515L;

	public String id;
	public String name;
	public String phone1;
	public String phone2;
	public String job;
	public String email;
	public String telephone;
	public String photo;
	public String orgId;
	public String orgName;
	
	public String orgType = "1";
	
	public boolean isLoadedPhoto = false;

	public static UserBean parseUserBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		UserBean bean = new UserBean();
		bean.id = obj.getProperty("id").toString();
		bean.name = getString(obj.getProperty("name").toString());
		bean.phone1 = getString(obj.getProperty("phone1").toString());
		bean.phone2 = getString(obj.getProperty("phone2").toString());
		bean.job = getString(obj.getProperty("job").toString());
		bean.email = getString(obj.getProperty("email").toString());
		bean.telephone = getString(obj.getProperty("telephone").toString());
		if(obj.hasProperty("photo")){
			bean.photo = getString(obj.getProperty("photo").toString());
		}
		bean.orgId = getString(obj.getProperty("orgId").toString());
		bean.orgName = getString(obj.getProperty("orgName").toString());
		return bean;
	}

	public String parseToCard() {
		return MessageFormat.format(
				BaseApp.sContext.getString(R.string.contact_card_template),
				name, orgName, job, phone1, telephone, email);
	}
}
