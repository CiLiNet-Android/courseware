package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class CareListBean extends WebServiceBean implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 4390221036373187898L;
	private static CareListBean mCareListBean;
	public ArrayList<UserBean> mUserBeans = new ArrayList<UserBean>();
 
	public static final String FILE_CACHE = Constans.CACHE_DIR + "care";
 
	public synchronized static CareListBean getInstance() {
		if (mCareListBean == null) {
			mCareListBean = (CareListBean) ObjectCacheUtils
					.readObject(FILE_CACHE + (LoginBean.getInstance().userId+"").hashCode());
			if (mCareListBean == null) {  
				mCareListBean = new CareListBean();
			}
		}
		return mCareListBean;
	}

	public void save() {
		ObjectCacheUtils.cacheObject(FILE_CACHE
				+ (LoginBean.getInstance().userId+"").hashCode(), mCareListBean);
	}

	public static boolean isFavourite(UserBean bean) {
		boolean isFav = false;
		mCareListBean = getInstance();
		for (int i = 0, l = mCareListBean.mUserBeans.size(); i < l; i++) {
			if (bean.id.equals(mCareListBean.mUserBeans.get(i).id)) {
				isFav = true;
				break;
			}
		}
		return isFav;
	}

	public boolean changeFavourite(UserBean bean) {
		boolean isFav = false;
		for (int i = 0, l = mCareListBean.mUserBeans.size(); i < l; i++) {
			if (bean.id.equals(mCareListBean.mUserBeans.get(i).id)) {
				mCareListBean.mUserBeans.remove(i);
				isFav = false;
				mCareListBean.save();
				return false;
			}
		}
		mCareListBean.mUserBeans.add(bean);
		isFav = true;
		mCareListBean.save();
		return isFav;
	}

	public void cancelCare(ArrayList<UserBean> beans) {
		for (int i = 0, l = mCareListBean.mUserBeans.size(); i < l; i++) {
			for (int j = 0, k = beans.size(); j < k; j++) {
				if (beans.get(j).id.equals(mCareListBean.mUserBeans.get(i).id)) {
					mCareListBean.mUserBeans.remove(i);
					mCareListBean.save();
					cancelCare(beans);
					return;
				}

			}
		}
		mCareListBean.save();
	}

}
