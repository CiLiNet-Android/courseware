package com.suncco.chinacdc.bean;

import java.io.Serializable;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.utils.SoapUtil;

public class ArticleBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7668352288899955790L;

	public String id;
	public String title;
	public String descript;
	public String time;
	public String titleImg;
	public String belong;

	public static ArticleBean parseArticleBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		ArticleBean bean = new ArticleBean();
		bean.id = getString(obj.getProperty("id").toString());
		bean.title = getString(obj.getProperty("title").toString());
		if(obj.hasProperty("descript")){
			bean.descript = getString(obj.getProperty("descript").toString());
		}
		bean.time = getString(obj.getProperty("showTime").toString());
		
		if(obj.hasProperty("titleImg"))
			bean.titleImg = getString(obj.getProperty("titleImg").toString());
		return bean;
	}
}
