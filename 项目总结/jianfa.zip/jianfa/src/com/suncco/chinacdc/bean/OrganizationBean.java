package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.utils.SoapUtil;

public class OrganizationBean extends BaseBean {

	public String id;
	public String name;
	public String parentId;
	public int count;
	public String type;

	public static OrganizationBean parseOrganizationBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		OrganizationBean bean = new OrganizationBean();
		bean.id = obj.getProperty("id").toString();
		bean.name = obj.getProperty("name").toString();
		if (obj.hasProperty("parentId")) {
			bean.parentId = obj.getProperty("parentId").toString();
		}
		bean.count = Integer.valueOf(obj.getProperty("count").toString());
		bean.type = getString(obj.getProperty("type")
				.toString());
		return bean;
	}

}
