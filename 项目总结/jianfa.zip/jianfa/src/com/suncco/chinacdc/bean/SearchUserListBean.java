package com.suncco.chinacdc.bean;

import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;

public class SearchUserListBean extends WebServiceBean {

//	public static final String methodName = "getMembersByKeyword";
	public static final String methodName = "getNorCusMembersByKeyword";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	public int total;
	public ArrayList<UserBean> mUserBeans = new ArrayList<UserBean>();

	public static SearchUserListBean parseSearchUserListBean(SoapObject obj) {
		SearchUserListBean bean = new SearchUserListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if(bean.code != 0){
			return bean;
		}
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			bean.total = Integer.valueOf(obj.getProperty("total").toString());
			if (obj.hasProperty("users")) {
				obj = (SoapObject) obj.getProperty("users");
				int count = obj.getPropertyCount();
				for (int i = 0; i < count; i++) {
					UserBean user = UserBean.parseUserBean((SoapObject) obj
							.getProperty(i));
					if (user != null) {
						bean.mUserBeans.add(user);
					}
				}
			}
		}
		return bean;
	}

	public void addPage(SearchUserListBean bean) {
		this.total = bean.total;
		this.mUserBeans.addAll(bean.mUserBeans);
	}

	public int getCurrentPage() {
		return mUserBeans.size() % Constans.PAGE_SIZE == 0 ? mUserBeans.size()
				/ Constans.PAGE_SIZE
				: (mUserBeans.size() / Constans.PAGE_SIZE + 1);
	}

	public boolean hasNextPage() {
		LogUtil.i(mUserBeans.size() + ", " + total);
		return mUserBeans.size() < total;
	}

}
