package com.suncco.chinacdc.bean;

import java.io.File;
import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class OrgRootListBean extends OrganizationListBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8896605874761556176L;
	public static final String methodName = "getNorCusOrgRoot";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;


//	public String id = "0";
//	public String name = "建发集团";
//	public String parentId;

//	public ArrayList<OrganizationBean> mOrganizationBeans = new ArrayList<OrganizationBean>();
//	public ArrayList<UserBean> mUserBeans = new ArrayList<UserBean>();

	
	
	public static OrgRootListBean parseOrgRootListBean(SoapObject obj) {

		OrgRootListBean bean = new OrgRootListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");

//			if (obj.hasProperty("group")) {
//				SoapObject group = (SoapObject) obj.getProperty("group");
//				LogUtil.e(group.toString() + "");
//				if (group.hasProperty("id")) {
//					bean.id = getString(group.getProperty("id").toString());
//					bean.name = getString(group.getProperty("name").toString());
//					bean.parentId = getString(group.getProperty("parentId")
//							.toString());
//				}
//			}

//			if (obj.hasProperty("child_users")) {
//				SoapObject users = (SoapObject) obj.getProperty("child_users");
//				int len = users.getPropertyCount();
//				for (int i = 0; i < len; i++) {
//					UserBean user = UserBean.parseUserBean((SoapObject) users
//							.getProperty(i));
//					if (user != null) {
//						bean.mUserBeans.add(user);
//					}
//				}
//			}
			
			if (obj.hasProperty("groups")) {
				SoapObject groups = (SoapObject) obj
						.getProperty("groups");
				int len = groups.getPropertyCount();
				for (int i = 0; i < len; i++) {
					OrganizationBean organization = OrganizationBean
							.parseOrganizationBean((SoapObject) groups
									.getProperty(i));
					if (organization != null) {
						bean.mOrganizationBeans.add(organization);
					}
				}
			}
		}
		return bean;
	}
}
