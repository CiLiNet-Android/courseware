package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FavourJournalBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5856529286963850514L;

	/**
	 * 0: 文字 非 0: 图片
	 */
	private int type;

	// 文字类型需要的信息
	public String title = "";
	public String path = "";
	public String time = "";
	public String detail = "";
	public String belong = "";
	public int index = 0;

	public int getType() {
		return type;
	}

	public FavourJournalBean(String title, String detail, String path,String belong) {
		this.type = 0;
		this.title = title;
		this.detail = detail;
		this.path = path;
		this.belong = belong;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		this.time = formatter.format(new Date());
	}

	public FavourJournalBean(String title, String path,String belong,int index) {
		this.type = 1;
		this.title = title;
		this.path = path;
		this.belong = belong;
		this.index = index;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		this.time = formatter.format(new Date());
	}

}
