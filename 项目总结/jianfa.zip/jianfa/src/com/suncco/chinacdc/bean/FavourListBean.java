package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.ArrayList;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class FavourListBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 215888775260150036L;
	
	public static final String FILE_CACHE = Constans.CACHE_DIR+"favour";
	
	public static int TYPE_ARTICLE = 0;
	public static int TYPE_MARKET = 2;
	public static int TYPE_OFFICE = 3;
 
	private static FavourListBean sFavourListBean;
	private ArrayList<FavourArticleBean> mFavourArticleBeans = new ArrayList<FavourArticleBean>();
	private ArrayList<FavourJournalBean> mFavourMagazineBeans = new ArrayList<FavourJournalBean>();
//	private ArrayList<FavourArticleBean> mFavourArticleBeansMarket = new ArrayList<FavourArticleBean>();
//	private ArrayList<FavourArticleBean> mFavourArticleBeansOffice = new ArrayList<FavourArticleBean>();

	private FavourListBean() {
	}

	public boolean hasArticleBean(String id) {
		for (FavourArticleBean bean : mFavourArticleBeans) {
			if (bean.id.equals(id)) {
				return true;
			}
		}
		return false;
	}
	

	public boolean hasJournalBean(int type, String title, String path) {
		for (FavourJournalBean bean : mFavourMagazineBeans) {
			if (type == bean.getType()) {
				if (bean.title.equals(title) && bean.path.equals(path)) {
					return true;
				}
			}
		}
		return false;
	}

	public static void save() {
		ObjectCacheUtils.cacheObject(FILE_CACHE
				+ FavourListBean.class.getSimpleName().hashCode(),
				sFavourListBean);
	}

	public static FavourListBean getInstance() {
//		if (sFavourListBean == null) {
			sFavourListBean = (FavourListBean) ObjectCacheUtils
					.readObject(FILE_CACHE
							+ FavourListBean.class.getSimpleName().hashCode());
			if (sFavourListBean == null) {
				sFavourListBean = new FavourListBean();
			}
//		}
		return sFavourListBean;
	}

	public ArrayList<FavourArticleBean> getFavourArticleBeans() {
		return mFavourArticleBeans;
	}

	public void addFavourArticleBean(ArticleDetailBean detail) {
		if (!hasArticleBean(detail.id)) {
			FavourArticleBean bean = new FavourArticleBean(detail);
			mFavourArticleBeans.add(bean);
			save();
		}
	}

	public void removeFavourArticleBean(String id) {
		FavourArticleBean favourArticleBean = null;
		for (FavourArticleBean bean : mFavourArticleBeans) {
			if (bean.id.equals(id)) {
				favourArticleBean = bean;
			}
		}
		mFavourArticleBeans.remove(favourArticleBean);
		save();
	}
	
	public void removeFavourArticleBean(ArrayList<FavourArticleBean> beans) {
//		FavourArticleBean favourArticleBean = null;
		for (FavourArticleBean bean : beans) {
				removeFavourArticleBean(bean.id);
		}
		save();
	}

	public ArrayList<FavourJournalBean> getFavourMagazineBeans() {
		return mFavourMagazineBeans;
	}

	public void addFavourMagazineBean(FavourJournalBean bean) {
		if (!hasJournalBean(bean.getType(), bean.title, bean.path)) {
			mFavourMagazineBeans.add(bean);
		}
	}

	public void removeFavourMaazineBean(int type, String title, String path) {
		FavourJournalBean favourJournalBean = null;
		for (FavourJournalBean bean : mFavourMagazineBeans) {
			if (type == bean.getType()) {
				if (bean.title.equals(title) && bean.path.equals(path)) {
					favourJournalBean = bean;
				}
			}
		}
		mFavourMagazineBeans.remove(favourJournalBean);
		save();
	}
	
	public void removeFavourMaazineBean(ArrayList<FavourJournalBean> beans) {
//		FavourArticleBean favourArticleBean = null;
		for (FavourJournalBean bean : beans) {
			removeFavourMaazineBean(bean.getType(),bean.title,bean.path);
		}
		save();
	}
	
}
