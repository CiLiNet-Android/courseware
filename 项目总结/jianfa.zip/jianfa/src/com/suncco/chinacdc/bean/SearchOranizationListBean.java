package com.suncco.chinacdc.bean;

import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;

public class SearchOranizationListBean extends WebServiceBean {

//	public static final String methodName = "getOrgListByKeywords";
	public static final String methodName = "getNorCusOrgListByKeywords";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	public ArrayList<OrganizationBean> mOrganizationBeans = new ArrayList<OrganizationBean>();
	public int total;

	public static SearchOranizationListBean parseSearchOranizationListBean(
			SoapObject obj) {
		SearchOranizationListBean bean = new SearchOranizationListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if(bean.code != 0){
			return bean;
		}
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			if(obj.hasProperty("total")){
				bean.total = Integer.valueOf(obj.getProperty("total").toString());
			}
			if (obj.hasProperty("groups")) {
				obj = (SoapObject) obj.getProperty("groups");
				int len = obj.getPropertyCount();
				for (int i = 0; i < len; i++) {
					OrganizationBean organization = OrganizationBean
							.parseOrganizationBean((SoapObject) obj
									.getProperty(i));
					if (organization != null) {
						bean.mOrganizationBeans.add(organization);
					}
				}
			}
		}
		return bean;
	}

	public void addPage(SearchOranizationListBean bean) {
		this.total = bean.total;
		this.mOrganizationBeans.addAll(bean.mOrganizationBeans);
	}

	public int getCurrentPage() {
		return mOrganizationBeans.size() % Constans.PAGE_SIZE == 0 ? mOrganizationBeans
				.size() / Constans.PAGE_SIZE
				: (mOrganizationBeans.size() / Constans.PAGE_SIZE + 1);
	}

	public boolean hasNextPage() {
		LogUtil.i(mOrganizationBeans.size() + ", " + total);
		return mOrganizationBeans.size() < total;
	}
}
