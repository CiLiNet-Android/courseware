package com.suncco.chinacdc.bean;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.text.TextUtils;
import android.util.Xml;

public class JournalPhotoDetailBean extends BaseBean {

	public String magazineId;
	public String magazineName;
	public String magazineDate;
	public String journalId;
	public String journalName;
	public String journalDate;
	public String type;
	public ArrayList<String> mPhones = new ArrayList<String>();
	public ArrayList<HashMap<String, String>> mPageList = new ArrayList<HashMap<String, String>>();

	public static JournalPhotoDetailBean parseJournalPhotoDetailBean(String path)
			throws XmlPullParserException, IOException {
		JournalPhotoDetailBean photoDetailBean = new JournalPhotoDetailBean();
		InputStream inputStream = new FileInputStream(path);
		XmlPullParser parser = Xml.newPullParser();
		parser.setInput(inputStream, "utf-8");
		int eventType = parser.getEventType();
		HashMap<String, String> page = null;
		while (eventType != XmlPullParser.END_DOCUMENT) {
			String name = parser.getName();
			switch (eventType) {
			case XmlPullParser.START_DOCUMENT:
				break;
			case XmlPullParser.START_TAG:
				if ("magazineId".equalsIgnoreCase(name)) {
					photoDetailBean.magazineId = parser.nextText();
				} else if ("termId".equalsIgnoreCase(name)) {
					photoDetailBean.journalId = parser.nextText();
				} else if ("type".equalsIgnoreCase(name)) {
					photoDetailBean.type = parser.nextText();
				} else if ("name".equalsIgnoreCase(name)) {
					if (TextUtils.isEmpty(photoDetailBean.magazineName)) {
						photoDetailBean.magazineName = parser.nextText();
					} else {
						photoDetailBean.journalName = parser.nextText();
					}
				} else if ("date".equalsIgnoreCase(name)) {
					if (TextUtils.isEmpty(photoDetailBean.magazineDate)) {
						photoDetailBean.magazineDate = parser.nextText();
					} else {
						photoDetailBean.journalDate = parser.nextText();
					}
				} else if ("pagePath".equalsIgnoreCase(name)) {
					photoDetailBean.mPhones.add(parser.nextText());
				} else if ("page".equalsIgnoreCase(name)) {
					page = new HashMap<String, String>();
				} else if (page != null) {
					if ("title".equalsIgnoreCase(name)) {
						page.put("title", parser.nextText());
					} else if ("index".equalsIgnoreCase(name)) {
						page.put("index", parser.nextText());
					}
				}
				break;
			case XmlPullParser.END_TAG:
				if ("page".equalsIgnoreCase(name)) {
					if (page != null && !TextUtils.isEmpty(page.get("title"))
							&& !TextUtils.isEmpty(page.get("index"))) {
						photoDetailBean.mPageList.add(page);
					}
				}
				break;
			}
			eventType = parser.next();
		}
		return photoDetailBean;

	}
}
