package com.suncco.chinacdc.bean;

import java.io.Serializable;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.SoapUtil;

public class PhotoBean extends WebServiceBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2759459272505531503L;
	public static final String methodName = "getMemberPhotoById";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	public String photo;
	public String id;

	public static PhotoBean parsePhotoBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		PhotoBean bean = new PhotoBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			if(obj.hasProperty("photo"))
			bean.photo = obj.getProperty("photo").toString();
			if(obj.hasProperty("id")){
				bean.id = obj.getProperty("id").toString();
			}
		}
		return bean;
	}
}
