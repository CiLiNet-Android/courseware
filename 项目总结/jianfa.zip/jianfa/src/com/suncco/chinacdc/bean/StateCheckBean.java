package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;

public class StateCheckBean extends WebServiceBean {

	public static final String methodName = "loading";
	public static final String serverUrl = Constans.SETTING_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	public int status;

	public static StateCheckBean parseStateCheckBean(SoapObject obj) {
		StateCheckBean bean = new StateCheckBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			bean.status = Integer.valueOf(obj.getProperty("status").toString());
			LogUtil.i(bean.toString());
			return bean;
		} else {
			LogUtil.e("loading 'data' parse error");
		}
		return null;
	}

}
