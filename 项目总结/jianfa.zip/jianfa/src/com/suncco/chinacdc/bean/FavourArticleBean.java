package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.utils.LogUtil;

public class FavourArticleBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -584118082756506393L;

	public String id;
	public String title;
	public String descript;
	public String time;
	public String belong = "";

	public FavourArticleBean(ArticleDetailBean bean) {
		this.id = bean.id;
		this.title = bean.title;
		this.descript = bean.descript;
		this.belong = bean.belong;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		this.time = formatter.format(new Date());
	}

}
