package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.SoapUtil;

public class ArticleDetailBean extends WebServiceBean {

	public static final String methodName = "getArticleDetail";
	public static final String serverUrl = Constans.ARTICLE_SERVICE;
	public static final String nameSpace = Constans.NAME_SPACE;

	public String id;
	public String descript;
	public String title;
	public String content;
	public String belong;

	public static ArticleDetailBean parseArticleDetailBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		ArticleDetailBean bean = new ArticleDetailBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			bean.id = getString(obj.getProperty("id").toString());
			if(obj.hasProperty("descript"))
			bean.descript = getString(obj.getProperty("descript").toString());
			bean.title = getString(obj.getProperty("title").toString());
			bean.content = getString(obj.getProperty("content").toString());
		}
		return bean;
	}

}
