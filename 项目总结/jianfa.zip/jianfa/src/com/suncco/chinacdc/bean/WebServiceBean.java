package com.suncco.chinacdc.bean;

public class WebServiceBean extends BaseBean {

	public int code;
	public String message;
}
