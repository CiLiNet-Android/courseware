package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class MagazineListBean extends WebServiceBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5631395757820027339L;
	public static final String methodName = "getJournalType";
	public static final String serverUrl = Constans.JOURNAL_SERVICE;
	public static final String nameSpace = Constans.NAME_SPACE;

	public static final String FILE_CACHE_SUB = Constans.CACHE_DIR + "magezine";

	public ArrayList<MagazineBean> mMagazineBeans = new ArrayList<MagazineBean>();

	public String[] getImageUrls() {
		int len = mMagazineBeans.size();
		String[] urls = new String[len];
		for (int i = 0; i < len; i++) {
			urls[i] = mMagazineBeans.get(i).logoImg;
		}
		return urls;
	}

	public static MagazineListBean parseMagazineListBean(SoapObject obj) {
		MagazineListBean bean = new MagazineListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			if (obj.hasProperty("types")) {
				obj = (SoapObject) obj.getProperty("types");
				int len = obj.getPropertyCount();
				for (int i = 0; i < len; i++) {
					MagazineBean magazine = MagazineBean
							.parseMagazineBean((SoapObject) obj.getProperty(i));
					if (magazine != null) {
						bean.mMagazineBeans.add(magazine);
					}
				}
			}
		}
		return bean;
	}

	public static MagazineListBean getSubMagazingList(MagazineListBean bean) {
		MagazineListBean subHistoryBean = getHistory();
		for (int i = 0, l = bean.mMagazineBeans.size(); i < l; i++) {
			if (bean.mMagazineBeans.get(i).isSubscribe) {
				bean.mMagazineBeans.get(i).isOrder = true;
			} else {
				if (subHistoryBean != null) {

					for (int j = 0, k = subHistoryBean.mMagazineBeans.size(); j < k; j++) {
						if (bean.mMagazineBeans.get(i).id
								.equals(subHistoryBean.mMagazineBeans.get(j).id)) {
							bean.mMagazineBeans.get(i).isOrder = subHistoryBean.mMagazineBeans
									.get(j).isOrder;
						}
					}
				}

			}

		}

		return bean;
	}

	// private ChannelListBean deleteAlongDeploy(ChannelListBean bean) {
	// for (int i = 0, l = bean.mChannelBeans.size(); i < l; i++) {
	// if (bean.mChannelBeans.get(i).isAloneDeploy) {
	// bean.mChannelBeans.remove(i);
	// return deleteAlongDeploy(bean);
	// }
	// }
	// return bean;
	// }
	public static MagazineListBean getSubNowListBean(MagazineListBean bean) {
		bean = getSubMagazingList(bean);
		MagazineListBean subBean = new MagazineListBean();
		for (int i = 0, l = bean.mMagazineBeans.size(); i < l; i++) {
			if (bean.mMagazineBeans.get(i).isOrder) {
				subBean.mMagazineBeans.add(bean.mMagazineBeans.get(i));
			}
		}
		return subBean;

	}

	public synchronized static MagazineListBean getHistory() {
		MagazineListBean bean;
		bean = (MagazineListBean) ObjectCacheUtils.readObject(FILE_CACHE_SUB
				+ ("" + LoginBean.getInstance().userId).hashCode());
		return bean;
	}

	public synchronized static void saveSub(MagazineListBean bean) {
		ObjectCacheUtils.cacheObject(
				FILE_CACHE_SUB
						+ ("" + LoginBean.getInstance().userId).hashCode(),
				bean);
	}

}
