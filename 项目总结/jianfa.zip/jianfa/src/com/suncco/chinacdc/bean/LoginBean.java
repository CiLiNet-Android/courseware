package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;

public class LoginBean extends WebServiceBean {

	public static final String methodName = "memberLogin";
	public static final String serverUrl = Constans.ORGANIZATION_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	private static LoginBean sLoginBean;

	public String sessionId;
	public String userId;
	public String name;
	public String phone1;
	public String phone2;
	public String job;
	public String photoId;
	public String orgId;
	public String orgName;
	public int showId;
	
	public String xphoneUrl;//邮件系统wap网址
	
	public String portalUrl;//流程管理系统网址
	public String helpUrl;//用户指南

	private LoginBean() {
	}

	public synchronized static LoginBean getInstance() {
		if (sLoginBean == null) {
			sLoginBean = new LoginBean();
		}
		return sLoginBean;
	}

	public static LoginBean parseLoginBean(SoapObject obj) {
		sLoginBean = new LoginBean();
		LogUtil.i("parse " + obj.getProperty("code").toString());
		sLoginBean.code = Integer.valueOf(obj.getProperty("code").toString());
		sLoginBean.message =obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			sLoginBean.sessionId = obj.getProperty("sessionId").toString();
			sLoginBean.userId = obj.getProperty("id")
					.toString();
			sLoginBean.name = obj.getProperty("name").toString();
			sLoginBean.phone1 = obj.getProperty("phone1").toString();
			sLoginBean.phone2 = obj.getProperty("phone2").toString();
			sLoginBean.job = obj.getProperty("job").toString();
			sLoginBean.photoId = obj.getProperty("photo").toString();
			sLoginBean.orgId = obj.getProperty("orgId")
					.toString();
			sLoginBean.orgName = obj.getProperty("orgName").toString();
			if(obj.hasProperty("showId")){
				sLoginBean.showId = Integer.valueOf(obj.getProperty("showId").toString());
			}
			
			if(obj.hasProperty("xphoneUrl"))
			sLoginBean.xphoneUrl = obj.getProperty("xphoneUrl").toString();
			if(obj.hasProperty("portalUrl"))
			sLoginBean.portalUrl = obj.getProperty("portalUrl").toString();
			if(obj.hasProperty("helpUrl"))
				sLoginBean.helpUrl = obj.getProperty("helpUrl").toString();
		}
		return sLoginBean;
	}
}
