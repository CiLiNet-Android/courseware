package com.suncco.chinacdc.bean;

import java.io.Serializable;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.utils.SoapUtil;

public class ChannelBean extends BaseBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6205211972100233834L;
	public String id;
	public String name;
	public String imgUrl;
	
	public boolean isSubscribe;
	public boolean isAloneDeploy;
	public String updateNum;
	
	public boolean isOrder = true;

	public static ChannelBean parseChannelBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		ChannelBean bean = new ChannelBean();
		bean.id = obj.getProperty("id").toString();
		bean.name = obj.getProperty("name").toString();
		bean.imgUrl = obj.getProperty("titleImg").toString();
		String sub = obj.getProperty("isSubscribe").toString();
		bean.isSubscribe = sub.equals("1");
		String along = obj.getProperty("isAloneDeploy").toString();
		bean.isAloneDeploy = along.equals("1");
		bean.updateNum = obj.getProperty("updateNum").toString();
		
		return bean;
	}
}
