package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;

public class UpdateVersionBean extends WebServiceBean {

	public static final String methodName = "updateAndroidVersion";
	public static final String serverUrl = Constans.SETTING_SERVICE_URL;
	public static final String nameSpace = Constans.NAME_SPACE;

	public String versionName;
	public String info;
	public String url;

	public static UpdateVersionBean parseUpdateVersionBean(SoapObject obj) {

		UpdateVersionBean bean = new UpdateVersionBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			bean.versionName = obj.getProperty("number").toString();
			bean.info = getString(obj.getProperty("info").toString());
			bean.url = obj.getProperty("url").toString();
			return bean;
		}
		return null;
	}

}
