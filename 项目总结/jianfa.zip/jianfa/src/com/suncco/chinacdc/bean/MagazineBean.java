package com.suncco.chinacdc.bean;

import java.io.Serializable;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.utils.SoapUtil;

public class MagazineBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4085920597193224648L;
	public String id;
	public String name;
	public String logoImg;
	public String company;
	
	public boolean isSubscribe;
	public boolean isOrder = true;
	

	public static MagazineBean parseMagazineBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		MagazineBean bean = new MagazineBean();
		bean.id = getString(obj.getProperty("id").toString());
		bean.name = getString(obj.getProperty("name").toString());
		bean.logoImg = getString(obj.getProperty("logoImg").toString());
		bean.company = getString(obj.getProperty("company").toString());
		
		String sub = obj.getProperty("isSubscribe").toString();
		bean.isSubscribe = sub.equals("1");
		return bean;
	}
}
