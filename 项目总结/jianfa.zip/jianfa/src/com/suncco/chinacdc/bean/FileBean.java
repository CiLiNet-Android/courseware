package com.suncco.chinacdc.bean;

import java.io.File;

import android.text.format.Formatter;

import com.suncco.chinacdc.BaseApp;

public class FileBean extends BaseBean {

	public String name;
	public String path;
	public String size;
	public boolean isClear;

	public static FileBean parseFileBean(File file) {
		if (file.exists()) {
			FileBean bean = new FileBean();
			bean.name = file.getName();
			bean.path = file.getPath();
			bean.size = Formatter.formatFileSize(BaseApp.sContext,
					computerFileSize(file));
			return bean;
		}
		return null;
	}

	private static long computerFileSize(File file) {
		if (file.exists()) {
			if (file.isDirectory()) {
				long size = 0;
				for (File f : file.listFiles()) {
					size += computerFileSize(f);
				}
				return size;
			} else {
				return file.length();
			}
		}
		return 0;
	}

}
