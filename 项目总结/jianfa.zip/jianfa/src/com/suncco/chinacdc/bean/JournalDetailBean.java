package com.suncco.chinacdc.bean;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.text.TextUtils;
import android.util.Xml;

public class JournalDetailBean extends BaseBean {

	public ArrayList<ArrayList<JournalArticleBean>> mPageList = new ArrayList<ArrayList<JournalArticleBean>>();
	public String magazineId;
	public String magazineName;
	public String magazineDate;
	public String journalId;
	public String journalName;
	public String journalDate;
	public String type;

	public static JournalDetailBean parseJournalDetailBean(String path)
			throws XmlPullParserException, IOException {
		JournalDetailBean journalDetailBean = null;
		InputStream inputStream = new FileInputStream(path);
		XmlPullParser parser = Xml.newPullParser();
		parser.setInput(inputStream, "utf-8");
		int eventType = parser.getEventType();
		ArrayList<JournalArticleBean> articleBeans = null;
		JournalArticleBean article = null;
		while (eventType != XmlPullParser.END_DOCUMENT) {
			String name = parser.getName();
			switch (eventType) {
			case XmlPullParser.START_DOCUMENT:
				journalDetailBean = new JournalDetailBean();
				break;
			case XmlPullParser.START_TAG:
				if ("magazineId".equalsIgnoreCase(name)) {
					journalDetailBean.magazineId = parser.nextText();
				} else if ("termId".equalsIgnoreCase(name)) {
					journalDetailBean.journalId = parser.nextText();
				} else if ("type".equalsIgnoreCase(name)) {
					journalDetailBean.type = parser.nextText();
				} else if ("page".equalsIgnoreCase(name)) {
					articleBeans = new ArrayList<JournalArticleBean>();
				} else if ("article".equalsIgnoreCase(name)) {
					article = new JournalArticleBean();
				} else if ("name".equalsIgnoreCase(name)) {
					if (TextUtils.isEmpty(journalDetailBean.magazineName)) {
						journalDetailBean.magazineName = parser.nextText();
					} else {
						journalDetailBean.journalName = parser.nextText();
					}
				} else if ("date".equalsIgnoreCase(name)) {
					if (article != null) {
						article.date = parser.nextText();
					} else {
						if (TextUtils.isEmpty(journalDetailBean.magazineDate)) {
							journalDetailBean.magazineDate = parser.nextText();
						} else {
							journalDetailBean.journalDate = parser.nextText();
						}
					}
				} else if (article != null) {
					if ("title".equalsIgnoreCase(name)) {
						article.title = parser.nextText();
					} else if ("isImage".equalsIgnoreCase(name)) {
						article.hasImage = parser.nextText();
					} else if ("imageUrl".equalsIgnoreCase(name)) {
						article.imgPath = parser.nextText();
					} else if ("detail".equalsIgnoreCase(name)) {
						article.detail = parser.nextText();
					}
				}
				break;
			case XmlPullParser.END_TAG:
				if ("article".equalsIgnoreCase(name)) {
					if (articleBeans != null && article != null) {
						articleBeans.add(article);
					}
					article = null;
				} else if ("page".equalsIgnoreCase(name)) {
					if (journalDetailBean != null && articleBeans != null) {
						journalDetailBean.mPageList.add(articleBeans);
					}
					articleBeans = null;
				}
				break;
			}
			eventType = parser.next();
		}
		return journalDetailBean;

	}
}
