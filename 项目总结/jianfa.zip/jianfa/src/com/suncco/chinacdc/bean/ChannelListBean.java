package com.suncco.chinacdc.bean;

import java.io.Serializable;
import java.util.ArrayList;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.utils.ObjectCacheUtils;

public class ChannelListBean extends WebServiceBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5126208722629827990L;

	// public static final String FILE_CACHE = Constans.CACHE_DIR + "chanel/";
	public static final String FILE_CACHE_SUB = Constans.CACHE_DIR + "channel";

	public static final String methodName = "getChannelList";
	public static final String serverUrl = Constans.CHANNEL_SERVICE;
	public static final String nameSpace = Constans.NAME_SPACE;

	public ArrayList<ChannelBean> mChannelBeans = new ArrayList<ChannelBean>();

	public String[] getImageUrls() {
		int len = mChannelBeans.size();
		String[] urls = new String[len];
		for (int i = 0; i < len; i++) {
			urls[i] = mChannelBeans.get(i).imgUrl;
		}
		return urls;
	}

	public static ChannelListBean parseChannelListBean(SoapObject obj) {
		ChannelListBean bean = new ChannelListBean();
		bean.code = Integer.valueOf(obj.getProperty("code").toString());
		bean.message = obj.getProperty("msg").toString();
		if (obj.hasProperty("data")) {
			obj = (SoapObject) obj.getProperty("data");
			int count = obj.getPropertyCount();
			for (int i = 0; i < count; i++) {
				ChannelBean channel = ChannelBean
						.parseChannelBean((SoapObject) obj.getProperty(i));
				if (channel != null) {
					bean.mChannelBeans.add(channel);
				}
			}
			return bean;
		}
		return bean;
	}

	public static ChannelListBean getSubChannelList(ChannelListBean bean) {
		ChannelListBean subHistoryBean = getSubhistory();
		for (int i = 0, l = bean.mChannelBeans.size(); i < l; i++) {
			if (bean.mChannelBeans.get(i).isSubscribe) {
				bean.mChannelBeans.get(i).isOrder = true;
				LogUtil.e("" + bean.mChannelBeans.get(i).name);
			} else {
				if (subHistoryBean != null) {

					for (int j = 0, k = subHistoryBean.mChannelBeans.size(); j < k; j++) {
						if (bean.mChannelBeans.get(i).id
								.equals(subHistoryBean.mChannelBeans.get(j).id)) {
							bean.mChannelBeans.get(i).isOrder = subHistoryBean.mChannelBeans
									.get(j).isOrder;
						}
					}
				}

			}

		}

		bean = bean.deleteAlongDeploy(bean);
		// LogUtil.e("get subChanneListBean---->" + bean.mChannelBeans.size());
		return bean;
	}

	private ChannelListBean deleteAlongDeploy(ChannelListBean bean) {
		for (int i = 0, l = bean.mChannelBeans.size(); i < l; i++) {
			if (bean.mChannelBeans.get(i).isAloneDeploy) {
				bean.mChannelBeans.remove(i);
				return deleteAlongDeploy(bean);
			}
		}
		return bean;
	}

	public static ChannelListBean getSubNowListBean(ChannelListBean bean) {
		bean = getSubChannelList(bean);
		ChannelListBean subBean = new ChannelListBean();
		for (int i = 0, l = bean.mChannelBeans.size(); i < l; i++) {
			if (bean.mChannelBeans.get(i).isOrder) {
				subBean.mChannelBeans.add(bean.mChannelBeans.get(i));
			}
		}
		return subBean;

	}

	public synchronized static ChannelListBean getSubhistory() {
		ChannelListBean bean;
		bean = (ChannelListBean) ObjectCacheUtils.readObject(FILE_CACHE_SUB
				+ ("" + LoginBean.getInstance().userId).hashCode());
		return bean;
	}

	public synchronized static void saveSub(ChannelListBean bean) {
		ObjectCacheUtils.cacheObject(
				FILE_CACHE_SUB
						+ ("" + LoginBean.getInstance().userId).hashCode(),
				bean);
	}

}
