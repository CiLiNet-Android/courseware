/**
 * 
 */
package com.suncco.chinacdc.bean;

import java.io.File;
import java.io.Serializable;

import com.suncco.chinacdc.Constans;
import com.suncco.chinacdc.utils.LogUtil;

/**
 * 
 * @author suncco 10036 2012-10-21
 */
public class DownloadBean extends BaseBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3833284653098894193L;

	public String id;
	public String name;
	public String url;
	public long fileSize;
	public long downloadedSize;
	public boolean isLoadFailed;

	public DownloadBean(String id, String name, String url) {
		this.id = id;
		this.name = name;
		this.url = url;
	}

	public void initDownloadedSize() {
		downloadedSize = getLoadedFileSize();
	}

	public float getProgress() {
		LogUtil.i(fileSize + "/ " + downloadedSize);
		return fileSize == 0 ? 0 : ((float) downloadedSize / (float) fileSize);
	}

	public float initProgress() {
		File file = new File(Constans.DOWNLOAD_DIR + name + ".zip");
		if (file.exists()) {
			return getProgress();
		} else {
			return 0;
		}
	}

	public boolean isFinish() {
		File file = new File(Constans.DOWNLOAD_DIR + name + ".zip");
		if (file.exists() && fileSize != 0) {
			return file.length() >= fileSize;
		}
		return false;
	}

	public long getLoadedFileSize() {
		File file = new File(Constans.DOWNLOAD_DIR + name + ".zip");
		if (file.exists()) {
			return file.length();
		}
		return 0;
	}

	public boolean isDownloaded() {
		return (fileSize != 0 && fileSize >= getLoadedFileSize());
	}

	public void updateDownloadedSize(int size) {
		downloadedSize += size;
	}
}
