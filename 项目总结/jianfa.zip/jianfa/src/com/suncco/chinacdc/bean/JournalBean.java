package com.suncco.chinacdc.bean;

import org.ksoap2.serialization.SoapObject;

import com.suncco.chinacdc.downloader.FileDownloader;
import com.suncco.chinacdc.utils.SoapUtil;

public class JournalBean extends BaseBean {

	public String id;
	public String name;
	public String contentType;
	public String surfaceImg;
	public String zipUrl;

	public FileDownloader fileDownloader;

	public static JournalBean parseJournalBean(SoapObject obj) {
		if (SoapUtil.isEmpty(obj)) {
			return null;
		}
		JournalBean bean = new JournalBean();
		bean.id = obj.getProperty("id").toString();
		bean.name = obj.getProperty("name").toString();
		bean.contentType = obj.getProperty("contentType").toString();
		bean.surfaceImg = obj.getProperty("surfaceImg").toString();
		bean.zipUrl = obj.getProperty("zipUrl").toString();
		return bean;
	}

}
