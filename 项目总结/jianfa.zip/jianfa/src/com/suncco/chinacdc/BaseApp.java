package com.suncco.chinacdc;

import java.io.File;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.view.Display;
import android.view.WindowManager;
import android.widget.Toast;

import com.suncco.chinacdc.bean.WebServiceBean;
import com.suncco.chinacdc.login.LoginActivity;

public class BaseApp extends Application {

	public static Context sContext;
	private static Handler sHandler;
	public static int sScreenHeight, sScreenWidth;
	public static String sOnlyMark;

	public boolean isProgramExit = false;

	@Override
	public void onCreate() {
		super.onCreate();
		sContext = getBaseContext();
		sHandler = new Handler();
		final WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		final Display display = windowManager.getDefaultDisplay();
		boolean isPortrait = display.getWidth() < display.getHeight();
		sScreenWidth = isPortrait ? display.getWidth() : display.getHeight();
		sScreenHeight = isPortrait ? display.getHeight() : display.getWidth();
		if (sScreenWidth == 0) {
			sScreenWidth = 480;
			sScreenHeight = 854;
		}

		TelephonyManager tm = (TelephonyManager) this
				.getSystemService(Context.TELEPHONY_SERVICE);
		sOnlyMark = tm.getDeviceId();
		if (sOnlyMark == null) {
			// pad标识
			sOnlyMark = Secure.getString(this.getContentResolver(),
					Secure.ANDROID_ID);
		}
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		mkDirs();
	}

	public static void showToast(final int resId) {
		sHandler.post(new Runnable() {

			public void run() {
				if (mToast == null) {
					mToast = Toast
							.makeText(sContext, resId, Toast.LENGTH_SHORT);
				} else {
					mToast.setText(resId);
				}
				mToast.show();
			}
		});
	}

	private static Toast mToast;

	public static void showToast(final String text) {
		sHandler.post(new Runnable() {
			public void run() {
				if (mToast == null) {
					mToast = Toast.makeText(sContext, text, Toast.LENGTH_SHORT);
				} else {
					mToast.setText(text);
				}
				mToast.show();
			}
		});
	}

	@Override
	public void onTerminate() {
		// TODO Auto-generated method stub
		super.onTerminate();
		sContext = null;
		sHandler = null;
		sOnlyMark = null;
	}

	private void mkDirs() {
		File file = new File(Constans.DIR);
		if (!file.isDirectory()) {
			file.mkdir();
		}
		file = new File(Constans.IMG_DIR);
		if (!file.isDirectory()) {
			file.mkdirs();
		}
		file = new File(Constans.DOWNLOAD_DIR);
		if (!file.isDirectory()) {
			file.mkdirs();
		}
	}

	public void setIsProgramExist(boolean isExist) {
		isProgramExit = isExist;
	}

	public boolean getIsProgramExist() {
		return isProgramExit;
	}

	public static void showSessionnDialog(final Context context,
			WebServiceBean bean) {
		if (bean.code == 2) {
			AlertDialog.Builder builder = new AlertDialog.Builder(context);
			builder.setMessage(bean.message);
			DialogInterface.OnClickListener l = new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					if (which == DialogInterface.BUTTON_POSITIVE) {
						Intent intent = new Intent(context, LoginActivity.class);
						context.startActivity(intent);
						((Activity) context).finish();
					}
				}
			};
			builder.setPositiveButton("重新登录", l);
			builder.setNegativeButton("取消", l);
			if (!((Activity) context).isFinishing())
				builder.create().show();
		} else {
			BaseApp.showToast(bean.message);
		}

	}

}
