package com.suncco.chinacdc.favour;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.FavourArticleBean;
import com.suncco.chinacdc.bean.FavourJournalBean;
import com.suncco.chinacdc.bean.FavourListBean;
import com.suncco.chinacdc.bean.FavourListBeanMarket;
import com.suncco.chinacdc.bean.FavourListBeanOffice;
import com.suncco.chinacdc.information.ArticleDetailActivity;
import com.suncco.chinacdc.magazine.JournalArticleActivity2;
import com.suncco.chinacdc.magazine.JournalPhotoDetailActivity;
import com.suncco.chinacdc.utils.LogUtil;
import com.suncco.chinacdc.widget.MyListView;

public class FavourActivity extends BaseActivity implements OnClickListener,
		OnItemClickListener, OnCheckedChangeListener {
	
	CheckBox mCheckBox;
	boolean selectMode = false;
	Button mTitleButton2;
	Button mTitleButton1;
	View viewSelectAll;
	MyListView mListView;
	int type;
	TextView title;
	
	FavourJournalAdapter mFavourJournalAdapter;
	FavourArticleAdapter mFavourArticleAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.favour_activity);
		prepareView();
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (mFavourArticleAdapter != null) {
			mFavourArticleAdapter.notifyDataSetChanged();
		} else if (mFavourJournalAdapter != null) {
			mFavourJournalAdapter.notifyDataSetChanged();
		}
		mTitleButton2.setText("编辑");
		selectMode = false;
		setListView();
		setSeletView();
	}

	private void prepareView() {
		type = getIntent().getIntExtra("type", FavourListBean.TYPE_ARTICLE);
		 title = (TextView) findViewById(R.id.title_text);
		mTitleButton2 = (Button) findViewById(R.id.title_but2);
		mTitleButton1 = (Button) findViewById(R.id.title_but1);
		mListView = (MyListView) findViewById(R.id.favour_list);
		mListView.setOnItemClickListener(this);
		viewSelectAll = findViewById(R.id.fav_selectall_view);
		viewSelectAll.setOnClickListener(this);
		mCheckBox = ((CheckBox) findViewById(R.id.fav_selectall_check));
		mCheckBox.setOnCheckedChangeListener(this);
		setListView();
		findViewById(R.id.title_but1).setOnClickListener(this);
		findViewById(R.id.title_but2).setOnClickListener(this);
		
	}

	public void onClick(View v) {
		switch(v.getId()){
		case R.id.title_but1:
			if(selectMode){
				selectMode = false;
				setSeletView();
			}else{
				finish();
			}
			break;
		case R.id.title_but2:
			if(selectMode){
				switch(type){
				case 0:
					ArrayList<FavourArticleBean> list = mFavourArticleAdapter.getSelectItems();
					if(list.size() == 0){
						BaseApp.showToast("未选择");
						return;
					}
					FavourListBean.getInstance().removeFavourArticleBean(list);
					break;
				case 1:
					ArrayList<FavourJournalBean> listJ = mFavourJournalAdapter.getSelectItems();
					if(listJ.size() == 0){
						BaseApp.showToast("未选择");
						return;
					}
					FavourListBean.getInstance().removeFavourMaazineBean(listJ);
					break;
				case 2:
					ArrayList<FavourArticleBean> list2 = mFavourArticleAdapter.getSelectItems();
					if(list2.size() == 0){
						BaseApp.showToast("未选择");
						return;
					}
					FavourListBeanMarket.getInstance().removeFavourArticleBean(list2);
					break;
				case 3:
					ArrayList<FavourArticleBean> list3 = mFavourArticleAdapter.getSelectItems();
					if(list3.size() == 0){
						BaseApp.showToast("未选择");
						return;
					}
					FavourListBeanOffice.getInstance().removeFavourArticleBean(list3);
					break;
				default:break;
				}
				selectMode = false;
				setListView();
				setSeletView();
			}else{
				switch(type){
				case 0:
				case 2:
				case 3:
					if(mFavourArticleAdapter.getCount() <= 0){
						BaseApp.showToast("您还没有任何收藏");
						return;
					}
					break;
				case 1:
					if(mFavourJournalAdapter.getCount() <= 0){
						BaseApp.showToast("您还没有任何收藏");
						return;
					}
					break;
				default:break;
				}
				selectMode = true;
				setSeletView();
			}
			break;
		case R.id.fav_selectall_view:
			mCheckBox.performClick();
			break;
		default:break;
		}
	}

	

	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
//		int type = getIntent().getIntExtra("type", 0);
		if (type == 0 || type == 2 || type ==3) {
			if(selectMode){
				mFavourArticleAdapter.setSelect(position); 
			}else{
				FavourArticleBean bean = mFavourArticleAdapter.getItem(position);
				Intent intent = new Intent(this, ArticleDetailActivity.class);
				intent.putExtra("id", bean.id);
				if(type == 2){
					intent.putExtra("channelId", "6");
				}else if(type == 3){
					intent.putExtra("channelId", "11");
				}
				startActivity(intent);
			}
		} else {
			if(selectMode){
				mFavourJournalAdapter.setSelect(position);
			}else{
				
				FavourJournalBean bean = mFavourJournalAdapter.getItem(position);
				Intent intent;
				if (bean.getType() == 0) {
					intent = new Intent(this, JournalArticleActivity2.class);
					intent.putExtra("title", bean.title);
					intent.putExtra("detail", bean.detail);
					intent.putExtra("path", bean.path);
					intent.putExtra("belong", bean.belong);
					LogUtil.i(bean.title + bean.path + bean.detail);
				} else {
					intent = new Intent(this, JournalPhotoDetailActivity.class);
					intent.putExtra("path", bean.path);
					intent.putExtra("belong", bean.belong);
					intent.putExtra("index", bean.index);
				}
				startActivity(intent);
			}
		}
	}
	
	private void setListView(){
		if (type == 0) {
			title.setText(R.string.favour_information);
			mFavourArticleAdapter = new FavourArticleAdapter(this,FavourListBean.getInstance().getFavourArticleBeans());
			mListView.setAdapter(mFavourArticleAdapter);
		}else if (type == 2) {
			title.setText("内部商场");
			mFavourArticleAdapter = new FavourArticleAdapter(this,FavourListBeanMarket.getInstance().getFavourArticleBeans());
			mListView.setAdapter(mFavourArticleAdapter);
		} else if (type == 3) {
			title.setText("办事指南");
			mFavourArticleAdapter = new FavourArticleAdapter(this,FavourListBeanOffice.getInstance().getFavourArticleBeans());
			mListView.setAdapter(mFavourArticleAdapter);
		}else {
			title.setText(R.string.favour_magazine);
			mFavourJournalAdapter = new FavourJournalAdapter(this);
			mListView.setAdapter(mFavourJournalAdapter);
		}
		
	}
	
	private void setSeletView() {
		if (selectMode) {
			viewSelectAll.setVisibility(View.VISIBLE);
			mTitleButton2.setText("删除");
			mTitleButton1.setText("取消");
		} else {
			viewSelectAll.setVisibility(View.GONE);
			// head.setVisibility(View.GONE);
			mTitleButton2.setText("编辑");
			mTitleButton1.setText("返回");
		}
		mCheckBox.setChecked(false);
		switch(type){
		case 0:
		case 2:
		case 3:
			mFavourArticleAdapter.selectMode = selectMode;
			mFavourArticleAdapter.setSeletAll(false);
			mFavourArticleAdapter.notifyDataSetChanged();
			break;
		case 1:
			mFavourJournalAdapter.selectMode = selectMode;
			mFavourJournalAdapter.setSeletAll(false);
			mFavourJournalAdapter.notifyDataSetChanged();
			break;
		default:break;
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch(type){
		case 0:
		case 2:
		case 3:
			mFavourArticleAdapter.setSeletAll(isChecked);
			break;
		case 1 :
			mFavourJournalAdapter.setSeletAll(isChecked);
			break;
		default:break;
		
		}
	}
	
}
