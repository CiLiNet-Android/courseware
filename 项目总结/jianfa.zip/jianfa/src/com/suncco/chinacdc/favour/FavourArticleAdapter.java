package com.suncco.chinacdc.favour;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.suncco.chinacdc.R;
import com.suncco.chinacdc.bean.FavourArticleBean;

public class FavourArticleAdapter extends BaseAdapter {

	private Context mContext;
	public boolean selectMode = false;
	private boolean[] checks;
	ArrayList<FavourArticleBean> list;

	public FavourArticleAdapter(Context context,ArrayList<FavourArticleBean> list) {
		this.mContext = context;
		this.list = list;
		this.checks = new boolean[list.size()];
	}

	public int getCount() {
		return list.size();
	}

	public FavourArticleBean getItem(int position) {
		return list.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean setSelect(int position) {

		checks[position] = !checks[position];
		notifyDataSetChanged();
		return checks[position];
	}

	public boolean setSeletAll(boolean isSelect) {
		for (int i = 0, l = checks.length; i < l; i++) {
			checks[i] = isSelect;
		}
		notifyDataSetChanged();
		return isSelect;
	}
	
	public ArrayList<FavourArticleBean> getSelectItems(){
		ArrayList<FavourArticleBean> list = new ArrayList<FavourArticleBean>();
		for(int i = 0 , l = checks.length ; i < l ; i++){
			if(checks[i]){
				list.add(getItem(i));
			}
		}
		return list;
	}

	static class ViewHolder {
		TextView title;
		TextView desc;
		TextView date;
		CheckBox check;
		ImageView tag;
		TextView belong;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(
					R.layout.favour_item, null);
			convertView.setTag(holder);
			holder.title = (TextView) convertView
					.findViewById(R.id.favour_title);
			holder.desc = (TextView) convertView
					.findViewById(R.id.favour_descript);
			holder.date = (TextView) convertView.findViewById(R.id.favour_date);
			holder.belong = (TextView) convertView.findViewById(R.id.favour_belong);

			holder.check = (CheckBox) convertView
					.findViewById(R.id.fav_checkbox);
			holder.check.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					int pos = (Integer) buttonView.getTag();
					checks[pos] = isChecked;
					notifyDataSetChanged();
				}
			});
			holder.tag = (ImageView) convertView.findViewById(R.id.fav_tag);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		FavourArticleBean bean = (FavourArticleBean) getItem(position);
		holder.title.setText(bean.title);
		holder.date.setText(bean.time);
		holder.belong.setText(bean.belong);
		holder.check.setTag(position);

		if(bean.descript == null || bean.descript.equals("")){
			holder.desc.setVisibility(View.GONE);
		}else{
			holder.desc.setVisibility(View.VISIBLE);
			holder.desc.setText(bean.descript);
		}
		if (selectMode) {
			holder.check.setVisibility(View.VISIBLE);
			holder.tag.setVisibility(View.GONE);
			holder.check.setChecked(checks[position]);

		} else {
			holder.check.setVisibility(View.GONE);
			holder.tag.setVisibility(View.VISIBLE);
		}

		return convertView;
	}

}
