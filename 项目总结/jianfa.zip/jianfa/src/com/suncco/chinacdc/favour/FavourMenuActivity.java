package com.suncco.chinacdc.favour;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.R;

public class FavourMenuActivity extends BaseActivity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.favour_menu_activity);
		prepareView();
	}
  
	private void prepareView() {
		findViewById(R.id.favour_infomation).setOnClickListener(this);
		findViewById(R.id.favour_magazine).setOnClickListener(this);
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.favour_maket).setOnClickListener(this);
		findViewById(R.id.favour_office).setOnClickListener(this);

	}

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		} else {
			Intent intent = new Intent(this, FavourActivity.class);
			switch(v.getId()){
			case R.id.favour_infomation:
				intent.putExtra("type", 0);
				break;
			case R.id.favour_magazine:
				intent.putExtra("type", 1);
				break;
			case R.id.favour_maket:
				intent.putExtra("type", 2);
				break;
			case R.id.favour_office:
				intent.putExtra("type", 3);
				break;
				default:break;
			}
			startActivity(intent);
		}
	}

}
