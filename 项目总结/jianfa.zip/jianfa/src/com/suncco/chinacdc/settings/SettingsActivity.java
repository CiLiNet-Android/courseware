package com.suncco.chinacdc.settings;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.BaseApp;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.UpdataLoaderService;
import com.suncco.chinacdc.bean.LoginBean;
import com.suncco.chinacdc.bean.UpdateVersionBean;
import com.suncco.chinacdc.utils.ChinacdcThread;
import com.suncco.chinacdc.utils.WebServiceParamsUtils;
import com.suncco.chinacdc.widget.LoadingProgressDialog;

/**
 * 
 * @author suncco 10036 2012-10-11
 */
public class SettingsActivity extends BaseActivity implements OnClickListener,
		OnCancelListener {

	private static final int HANDLER_WHAT_VERSION = 100;
	private LoadingProgressDialog mProgress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_activity);
		prepareView();
	}

	public void onClick(View v) {
		if (v.getId() == R.id.back) {
			finish();
		} else if (v.getId() == R.id.settings_update) {
			checkVersion();
			mProgress.show();
		} else if (v.getId() == R.id.settings_logout) {
			showLogoutDialog();
		} else if (v.getId() == R.id.settings_about) {
			Intent intent = new Intent(this, UserHelpActivity.class);
			startActivity(intent);
//			Intent intent = new Intent(Intent.ACTION_DEFAULT);
//			intent.setData(Uri.parse(LoginBean.getInstance().helpUrl+""));
			startActivity(intent);
		}
	}

	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		findViewById(R.id.settings_update).setOnClickListener(this);
		findViewById(R.id.settings_logout).setOnClickListener(this);
		findViewById(R.id.settings_about).setOnClickListener(this);
		mProgress = new LoadingProgressDialog(this);
		mProgress.setOnCancelListener(this);
	}

	private String getVersionName() {
		try {
			PackageManager packageManager = getPackageManager();
			PackageInfo packInfo = packageManager.getPackageInfo(
					getPackageName(), 0);
			String version = packInfo.versionName;
			return version;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return "1.0.0";
	}

	private ChinacdcThread mChinacdcThread;

	private void checkVersion() {
		WebServiceParamsUtils utils = new WebServiceParamsUtils();
		utils.addNameAndValue("sessionId", LoginBean.getInstance().sessionId);
		mChinacdcThread = new ChinacdcThread(UpdateVersionBean.class,
				utils.formatParams(), mHandler, HANDLER_WHAT_VERSION);
		mChinacdcThread.start();
	}

	private void showUpdateDialog(final UpdateVersionBean bean) {
		DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if (which == DialogInterface.BUTTON_NEGATIVE) {
				} else {
					startUpdate(bean);
				}
			}
		};
		new AlertDialog.Builder(this).setTitle(R.string.app_prompt)
				.setMessage(Html.fromHtml(bean.info))
				.setPositiveButton(R.string.app_update, listener)
				.setNegativeButton(R.string.app_Ignore_update, listener).show();
	}

	private void showLogoutDialog() {
		new AlertDialog.Builder(this)
				.setTitle(R.string.app_prompt)
				.setMessage(R.string.settings_logout_message)
				.setPositiveButton(R.string.app_ok,
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								setResult(1);
								finish();
							}
						}).setNegativeButton(R.string.app_cancel, null).show();
	}

	Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			super.handleMessage(msg);
			if (msg.what == HANDLER_WHAT_VERSION) {
				mProgress.dismiss();
				UpdateVersionBean bean = (UpdateVersionBean) msg.obj;
				if (bean == null) {
					BaseApp.showToast(R.string.app_load_exc);
				} else {
					if (bean.code == 0) {
						String version = getVersionName();
						if (!version.equals(bean.versionName)) {
							showUpdateDialog(bean);
						} else {
							BaseApp.showToast("您的i建发已经是最新版本");
						}
					} else {
						BaseApp.showToast(bean.message);
					}
				}
			}
		};
	};

	public void onCancel(DialogInterface dialog) {
		if (mChinacdcThread != null) {
			mChinacdcThread.cancel();
		}
	}

	private void startUpdate(UpdateVersionBean bean) {
		Intent intent = new Intent(this, UpdataLoaderService.class);
		intent.putExtra("url", bean.url);
		intent.putExtra("version", bean.versionName);
		startService(intent);
	}
	
}
