package com.suncco.chinacdc.settings;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.widget.CompoundButton.OnCheckedChangeListener;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.R;
import com.suncco.chinacdc.utils.LogUtil;

public class UserHelpActivity extends BaseActivity implements
		OnClickListener{

	private View mTitleBar;
	private String mDetail;
	private String mPath;
	WebView mWebView;
	WebSettings mWebSettings;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_help_activity);
			prepareView();
	}



	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		mWebView = (WebView)findViewById(R.id.help_webview);
		mWebView.requestFocus();
		mWebView.loadUrl("file:///android_asset/help/test.html");
		mWebSettings = mWebView.getSettings();
		mWebSettings.setDefaultTextEncodingName("UTF-8") ;
		mWebSettings.setLoadWithOverviewMode(true);
//		mWebSettings.setUseWideViewPort(true);
		mWebSettings.setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
//		mWebView.loadDataWithBaseURL("file://android_asset/help/",
//				null,
//				"text/html", "utf-8", null);
	}


	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.back:
			finish();
			break;
		default:
			break;
		}

	}
}
