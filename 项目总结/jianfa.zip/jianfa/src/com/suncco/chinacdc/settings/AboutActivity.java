package com.suncco.chinacdc.settings;

import java.text.MessageFormat;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.suncco.chinacdc.BaseActivity;
import com.suncco.chinacdc.R;

public class AboutActivity extends BaseActivity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_activity);
		prepareView();
	}

	private void prepareView() {
		findViewById(R.id.back).setOnClickListener(this);
		TextView version = (TextView) findViewById(R.id.about_app_version);
		version.setText(MessageFormat.format(
				getString(R.string.settings_app_version_template),
				getVersionName()));
	}

	private String getVersionName() {
		try {
			PackageManager packageManager = getPackageManager();
			PackageInfo packInfo = packageManager.getPackageInfo(
					getPackageName(), 0);
			String version = packInfo.versionName;
			return version;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return "1.0.0";
	}

	public void onClick(View v) {
		finish();
	}

}
