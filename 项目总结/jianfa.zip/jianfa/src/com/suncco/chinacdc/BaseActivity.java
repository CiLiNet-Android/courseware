package com.suncco.chinacdc;

import android.app.Activity;

import com.umeng.analytics.MobclickAgent;

/**
 * 
 * @author suncco 10036 2012-10-11
 */
public class BaseActivity extends Activity {

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		BaseApp mBaseApp = (BaseApp) getApplication();
		if (mBaseApp.isProgramExit) {
			finish();
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		MobclickAgent.onResume(this);
		BaseApp mBaseApp = (BaseApp) getApplication();
		if (mBaseApp.getIsProgramExist()) {
			finish();
		}
	}

	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

}
