Change Log
==========

Version 1.2.1 *(2011-10-20)*
----------------------------

Maven 3 is now required when building from the command line.

 * Update to support ADT 14.


Version 1.2.0 *(2011-10-04)*
----------------------------

 * Move to `com.directionalviewpager` package.
 * Change maven group and artifact to `com.directionalviewpager:library`.


Version 1.1.0 *(2011-09-28)*
----------------------------

 * Extend from `ViewPager` so it can be used with other APIs which require an
   instance of `ViewPager`.
 * Move to `com.jakewharton.android.view` package.


Version 1.0.0 *(2011-08-24)*
----------------------------

Initial release.
